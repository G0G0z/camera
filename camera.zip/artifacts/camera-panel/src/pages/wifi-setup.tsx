import { useState, useRef } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { QRCodeSVG } from "qrcode.react"
import { useAuthStore } from "@/store/auth"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import {
  Wifi, QrCode, Trash2, Download, Eye, EyeOff,
  Plus, Loader2, CheckCircle2, BookmarkPlus, Info
} from "lucide-react"

const BASE  = import.meta.env.BASE_URL.replace(/\/$/, "")
const auth  = () => ({ Authorization: `Bearer ${useAuthStore.getState().token}` })
const apiFetch = async (method: string, path: string, body?: object) => {
  const r = await fetch(`${BASE}/api${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...auth() },
    body: body ? JSON.stringify(body) : undefined,
  })
  if (r.status === 204) return null
  const d = await r.json()
  if (!r.ok) throw new Error(d.error || "Hata")
  return d
}

// ── Form şeması ───────────────────────────────────────────────────────────────
const schema = z.object({
  name:     z.string().min(1, "Profil adı gerekli"),
  ssid:     z.string().min(1, "WiFi ağ adı gerekli"),
  password: z.string().optional(),
  security: z.enum(["WPA", "WEP", "NOPASS"]),
  hidden:   z.boolean(),
})
type FormValues = z.infer<typeof schema>

// ── QR Önizleme bileşeni ──────────────────────────────────────────────────────
function QrPreview({ qrString, ssid, onClose }: { qrString: string; ssid: string; onClose: () => void }) {
  const svgRef   = useRef<HTMLDivElement>(null)
  const { toast } = useToast()

  const downloadSVG = () => {
    const svg = svgRef.current?.querySelector("svg")
    if (!svg) return
    const blob = new Blob([svg.outerHTML], { type: "image/svg+xml" })
    const a    = document.createElement("a")
    a.href     = URL.createObjectURL(blob)
    a.download = `wifi-qr-${ssid.replace(/\s+/g, "_")}.svg`
    a.click()
    toast({ title: "QR kodu indirildi", description: `${ssid}.svg` })
  }

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-background rounded-2xl shadow-2xl p-8 max-w-sm w-full" onClick={e => e.stopPropagation()}>
        <div className="text-center space-y-5">
          <div>
            <h2 className="text-xl font-bold">WiFi QR Kodu</h2>
            <p className="text-muted-foreground text-sm mt-1">{ssid}</p>
          </div>

          {/* QR kod — beyaz arka plan, geniş quiet zone */}
          <div
            ref={svgRef}
            className="flex items-center justify-center bg-white rounded-xl p-6 mx-auto"
            style={{ width: 240, height: 240 }}
          >
            <QRCodeSVG
              value={qrString}
              size={192}
              level="M"
              includeMargin={false}
              imageSettings={{
                src: "",
                excavate: false,
                height: 0,
                width: 0,
              }}
            />
          </div>

          <div className="bg-muted rounded-lg p-3 text-left">
            <p className="text-xs text-muted-foreground font-medium mb-1">Nasıl kullanılır?</p>
            <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
              <li>Kamerayı bu ekrana doğrultun</li>
              <li>OpenIPC otomatik olarak WiFi'ye bağlanır</li>
              <li>Kamera IP'sini router admin panelinden bulun</li>
            </ol>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={onClose}>Kapat</Button>
            <Button className="flex-1" onClick={downloadSVG}>
              <Download className="w-4 h-4 mr-2" />İndir
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Kayıtlı profil kartı ──────────────────────────────────────────────────────
function ProfileCard({ profile, onShowQR, onDelete }: { profile: any; onShowQR: () => void; onDelete: () => void }) {
  return (
    <div className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:bg-muted/30 transition-colors">
      <div className="w-10 h-10 bg-primary/10 text-primary rounded-lg flex items-center justify-center shrink-0">
        <Wifi className="w-5 h-5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{profile.name}</p>
        <div className="flex items-center gap-2 mt-0.5">
          <p className="text-xs text-muted-foreground truncate">{profile.ssid}</p>
          <Badge variant="secondary" className="text-[10px] h-4 px-1.5 shrink-0">{profile.security}</Badge>
          {profile.hidden && <Badge variant="outline" className="text-[10px] h-4 px-1.5 shrink-0">Gizli</Badge>}
          {profile.hasPassword && <Badge variant="outline" className="text-[10px] h-4 px-1.5 shrink-0">Şifreli</Badge>}
        </div>
      </div>
      <div className="flex gap-1.5 shrink-0">
        <Button size="icon" variant="ghost" className="w-8 h-8" onClick={onShowQR} title="QR Göster">
          <QrCode className="w-4 h-4" />
        </Button>
        <Button size="icon" variant="ghost" className="w-8 h-8 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={onDelete} title="Sil">
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}

// ── Ana sayfa ─────────────────────────────────────────────────────────────────
export default function WifiSetupPage() {
  const [showPass,   setShowPass]   = useState(false)
  const [activeQR,   setActiveQR]   = useState<{ qrString: string; ssid: string } | null>(null)
  const [liveQR,     setLiveQR]     = useState<string>("")
  const { toast }                   = useToast()
  const qc                          = useQueryClient()

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", ssid: "", password: "", security: "WPA", hidden: false },
  })

  const ssidVal  = form.watch("ssid")
  const passVal  = form.watch("password")
  const secVal   = form.watch("security")
  const hidVal   = form.watch("hidden")

  // Canlı QR önizleme (kaydetmeden)
  const updateLiveQR = () => {
    const ssid = ssidVal?.trim()
    if (!ssid) { setLiveQR(""); return }
    const esc  = (v: string) => v.replace(/([\\;,":])/, "\\$1")
    const sec  = secVal === "NOPASS" ? "nopass" : secVal
    let str    = `WIFI:T:${sec};S:${esc(ssid)}`
    if (passVal && secVal !== "NOPASS") str += `;P:${esc(passVal)}`
    if (hidVal)                         str += ";H:true"
    str += ";;"
    setLiveQR(str)
  }

  // Kayıtlı profiller
  const { data: profiles = [] } = useQuery({
    queryKey: ["wifi-profiles"],
    queryFn:  () => apiFetch("GET", "/wifi"),
  })

  // Profil kaydet
  const saveMutation = useMutation({
    mutationFn: (v: FormValues) => apiFetch("POST", "/wifi", v),
    onSuccess: () => {
      toast({ title: "Profil kaydedildi" })
      qc.invalidateQueries({ queryKey: ["wifi-profiles"] })
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  // Profil sil
  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiFetch("DELETE", `/wifi/${id}`),
    onSuccess: () => {
      toast({ title: "Profil silindi" })
      qc.invalidateQueries({ queryKey: ["wifi-profiles"] })
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  // Kayıtlı profilin QR'ını göster (şifreyi çöz)
  const showSavedQR = async (profile: any) => {
    // Profil kayıtlı ama şifre yok → sadece SSID ile QR
    const qr = await apiFetch("POST", "/wifi/qr-string", {
      ssid:     profile.ssid,
      security: profile.security,
      hidden:   profile.hidden,
      // Şifre backend'de base64 saklı; yeni bir endpoint yazmak yerine
      // kaydedilen profili doğrudan kullanıyoruz — şifresiz QR'a izin ver
    })
    setActiveQR({ qrString: qr.qrString, ssid: profile.ssid })
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">WiFi Kurulum QR</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Kameranızı sıfırladıktan sonra WiFi ağına bağlanması için QR kodu oluşturun
        </p>
      </div>

      {/* Açıklama */}
      <div className="flex gap-3 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
        <Info className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
        <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
          <p className="font-medium">Nasıl çalışır?</p>
          <p>OpenIPC yüklü kameranızı fabrika ayarlarına sıfırladığınızda, ilk açılışta bu QR kodu kamera görüntüsüne göstererek WiFi ağ bilgilerini otomatik okutabilirsiniz. Kamera QR'ı okuyunca ağa bağlanır ve IP alır.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ── Sol: Form ── */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Plus className="w-4 h-4" /> QR Kodu Oluştur
            </CardTitle>
            <CardDescription>Hızlı oluştur veya profilinizi kaydedin</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form
                className="space-y-4"
                onSubmit={e => e.preventDefault()}
                onChange={updateLiveQR}
              >
                <FormField control={form.control} name="ssid" render={({ field }) => (
                  <FormItem>
                    <FormLabel>WiFi Ağ Adı (SSID)</FormLabel>
                    <FormControl>
                      <Input placeholder="Ev_Wifim" {...field} onChange={e => { field.onChange(e); updateLiveQR() }} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <FormField control={form.control} name="security" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Güvenlik Tipi</FormLabel>
                    <Select value={field.value} onValueChange={v => { field.onChange(v); updateLiveQR() }}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="WPA">WPA / WPA2 / WPA3</SelectItem>
                        <SelectItem value="WEP">WEP (Eski)</SelectItem>
                        <SelectItem value="NOPASS">Şifresiz (Açık)</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />

                {form.watch("security") !== "NOPASS" && (
                  <FormField control={form.control} name="password" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Şifre</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            type={showPass ? "text" : "password"}
                            placeholder="WiFi şifresi"
                            {...field}
                            onChange={e => { field.onChange(e); updateLiveQR() }}
                          />
                          <button
                            type="button"
                            onClick={() => setShowPass(p => !p)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                          >
                            {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}

                <FormField control={form.control} name="hidden" render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <FormLabel className="text-sm">Gizli Ağ</FormLabel>
                      <p className="text-xs text-muted-foreground">SSID broadcast kapalıysa işaretleyin</p>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={v => { field.onChange(v); updateLiveQR() }} />
                    </FormControl>
                  </FormItem>
                )} />

                <div className="flex gap-2 pt-2">
                  <Button
                    type="button"
                    className="flex-1"
                    disabled={!liveQR}
                    onClick={() => liveQR && setActiveQR({ qrString: liveQR, ssid: ssidVal })}
                  >
                    <QrCode className="w-4 h-4 mr-2" />QR Göster
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    disabled={saveMutation.isPending || !ssidVal}
                    onClick={() => form.handleSubmit(v => saveMutation.mutate(v))()}
                  >
                    {saveMutation.isPending
                      ? <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      : <BookmarkPlus className="w-4 h-4 mr-2" />
                    }
                    Kaydet
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* ── Sağ: Canlı önizleme ── */}
        <div className="space-y-4">
          <Card className="flex-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <QrCode className="w-4 h-4" /> Anlık Önizleme
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center bg-white rounded-xl p-5 min-h-[200px]">
                {liveQR ? (
                  <QRCodeSVG value={liveQR} size={180} level="M" includeMargin={false} />
                ) : (
                  <div className="text-center text-muted-foreground">
                    <Wifi className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">WiFi adını girin</p>
                  </div>
                )}
              </div>
              {liveQR && (
                <p className="text-center text-xs text-muted-foreground mt-3">
                  <CheckCircle2 className="w-3 h-3 inline mr-1 text-green-500" />
                  QR hazır — kameraya gösterin
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ── Kayıtlı Profiller ── */}
      {profiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Wifi className="w-4 h-4" /> Kayıtlı WiFi Profilleri
            </CardTitle>
            <CardDescription>Tekrar QR oluşturmak için bir profile tıklayın</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {profiles.map((p: any) => (
              <ProfileCard
                key={p.id}
                profile={p}
                onShowQR={() => showSavedQR(p)}
                onDelete={() => deleteMutation.mutate(p.id)}
              />
            ))}
          </CardContent>
        </Card>
      )}

      {/* QR modal */}
      {activeQR && (
        <QrPreview
          qrString={activeQR.qrString}
          ssid={activeQR.ssid}
          onClose={() => setActiveQR(null)}
        />
      )}
    </div>
  )
}
