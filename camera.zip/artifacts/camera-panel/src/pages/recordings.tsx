import { useState } from "react"
import { useGetRecordings, useDeleteRecording } from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Video, Trash2, Download, Play, Clock, HardDrive, Calendar } from "lucide-react"
import { format } from "date-fns"
import { useToast } from "@/hooks/use-toast"

export default function RecordingsPage() {
  const [page, setPage] = useState(1)
  const limit = 20
  
  const { data, isLoading, refetch } = useGetRecordings({ page, limit })
  const deleteMutation = useDeleteRecording()
  const { toast } = useToast()

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this recording?")) {
      deleteMutation.mutate({ id }, {
        onSuccess: () => {
          toast({ title: "Recording deleted", description: "The recording has been removed from storage." })
          refetch()
        },
        onError: () => {
          toast({ title: "Error", description: "Failed to delete recording.", variant: "destructive" })
        }
      })
    }
  }

  const formatDuration = (seconds?: number | null) => {
    if (!seconds) return "--"
    const h = Math.floor(seconds / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    const s = Math.floor(seconds % 60)
    if (h > 0) return `${h}h ${m}m ${s}s`
    return `${m}m ${s}s`
  }

  const formatSize = (bytes?: number | null) => {
    if (!bytes) return "--"
    const mb = bytes / (1024 * 1024)
    if (mb > 1024) return `${(mb / 1024).toFixed(2)} GB`
    return `${mb.toFixed(1)} MB`
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Recordings</h1>
          <p className="text-muted-foreground mt-1">Archive of camera video recordings</p>
        </div>
        <Card>
          <CardContent className="p-0">
            <div className="h-[400px] animate-pulse bg-muted/50"></div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Recordings</h1>
          <p className="text-muted-foreground mt-1">Archive of camera video recordings</p>
        </div>
      </div>

      <Card className="border-border/50 shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead>Camera</TableHead>
              <TableHead>Start Time</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Size</TableHead>
              <TableHead>Trigger</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {!data?.items?.length ? (
              <TableRow>
                <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                  No recordings found
                </TableCell>
              </TableRow>
            ) : (
              data.items.map(rec => (
                <TableRow key={rec.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Video className="w-4 h-4 text-muted-foreground" />
                      {rec.cameraName || `Camera #${rec.cameraId}`}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="text-sm">{format(new Date(rec.startTime), "MMM d, yyyy")}</span>
                      <span className="text-xs text-muted-foreground">{format(new Date(rec.startTime), "HH:mm:ss")}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5 text-muted-foreground text-sm">
                      <Clock className="w-3.5 h-3.5" />
                      {formatDuration(rec.duration)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5 text-muted-foreground text-sm">
                      <HardDrive className="w-3.5 h-3.5" />
                      {formatSize(rec.fileSize)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="capitalize">
                      {rec.trigger || 'manual'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {rec.status === 'completed' ? (
                      <Badge className="bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 border-emerald-500/20">Completed</Badge>
                    ) : rec.status === 'recording' ? (
                      <Badge className="bg-red-500/10 text-red-600 hover:bg-red-500/20 border-red-500/20 animate-pulse">Recording</Badge>
                    ) : (
                      <Badge variant="destructive">Failed</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="icon" disabled={rec.status !== 'completed'} title="Play">
                        <Play className="w-4 h-4 text-primary" />
                      </Button>
                      <Button variant="ghost" size="icon" disabled={rec.status !== 'completed'} title="Download">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(rec.id)} title="Delete">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        
        {data && data.total > limit && (
          <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/20">
            <span className="text-sm text-muted-foreground">
              Showing {(page - 1) * limit + 1} to {Math.min(page * limit, data.total)} of {data.total}
            </span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
              <Button variant="outline" size="sm" disabled={page * limit >= data.total} onClick={() => setPage(p => p + 1)}>Next</Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
