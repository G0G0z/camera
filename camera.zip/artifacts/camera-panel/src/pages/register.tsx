import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Link, useLocation } from "wouter"
import { useAuthStore } from "@/store/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { Camera, Loader2 } from "lucide-react"
import { useMutation } from "@tanstack/react-query"

const schema = z.object({
  companyName: z.string().min(2, "Şirket adı en az 2 karakter"),
  name:        z.string().min(2, "Ad soyad en az 2 karakter"),
  email:       z.string().email("Geçersiz e-posta"),
  phone:       z.string().optional(),
  password:    z.string().min(6, "Şifre en az 6 karakter"),
  confirm:     z.string(),
}).refine(d => d.password === d.confirm, {
  message: "Şifreler eşleşmiyor",
  path: ["confirm"],
})

type FormValues = z.infer<typeof schema>

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "")

export default function RegisterPage() {
  const [, setLocation] = useLocation()
  const setToken        = useAuthStore(s => s.setToken)
  const { toast }       = useToast()

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { companyName: "", name: "", email: "", phone: "", password: "", confirm: "" },
  })

  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const r = await fetch(`${BASE}/api/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      })
      const data = await r.json()
      if (!r.ok) throw new Error(data.error || "Kayıt başarısız")
      return data
    },
    onSuccess: (data) => {
      setToken(data.token)
      toast({ title: "Hesap oluşturuldu!", description: `Hoş geldiniz, ${data.user.name}` })
      setLocation("/")
    },
    onError: (e: any) => {
      toast({ title: "Hata", description: e.message, variant: "destructive" })
    },
  })

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-lg shadow-lg border-border/50">
        <CardHeader className="space-y-3 pb-6 text-center">
          <div className="mx-auto w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-2">
            <Camera className="w-6 h-6 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">Hesap Oluştur</CardTitle>
          <CardDescription>Kamera yönetim sisteminize başlayın</CardDescription>
        </CardHeader>

        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(v => mutation.mutate(v))} className="space-y-4">

              <FormField control={form.control} name="companyName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Şirket / Kurum Adı</FormLabel>
                  <FormControl><Input placeholder="Güvenlik A.Ş." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ad Soyad</FormLabel>
                    <FormControl><Input placeholder="Ahmet Yılmaz" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telefon <span className="text-muted-foreground text-xs">(opsiyonel)</span></FormLabel>
                    <FormControl><Input placeholder="0212 555 0101" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>E-posta</FormLabel>
                  <FormControl><Input type="email" placeholder="admin@sirketiniz.com" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="password" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Şifre</FormLabel>
                    <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="confirm" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Şifre Tekrar</FormLabel>
                    <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <Button type="submit" className="w-full mt-2" disabled={mutation.isPending}>
                {mutation.isPending ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Oluşturuluyor...</> : "Hesap Oluştur"}
              </Button>

              <p className="text-center text-sm text-muted-foreground pt-2">
                Zaten hesabınız var mı?{" "}
                <Link href="/login" className="text-primary hover:underline font-medium">Giriş yapın</Link>
              </p>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
