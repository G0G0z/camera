import { useState, useRef } from "react"
import { useParams } from "wouter"
import { 
  useGetCamera, 
  useGetCameraStream, 
  useSendPtzCommand, 
  useGetPtzPresets, 
  useGotoPtzPreset,
  useGetEvents
} from "@workspace/api-client-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight, 
  ZoomIn, ZoomOut, MoveDiagonal, MonitorStop, 
  MapPin, Clock, Camera as CameraIcon, Activity
} from "lucide-react"
import { format } from "date-fns"

export default function CameraDetail() {
  const params = useParams()
  const id = Number(params.id)
  
  const { data: camera, isLoading: isLoadingCamera } = useGetCamera(id, {
    query: { enabled: !!id, queryKey: ['camera', id] }
  })
  
  const { data: streamInfo, isLoading: isLoadingStream } = useGetCameraStream(id, {
    query: { enabled: !!id, queryKey: ['stream', id] }
  })
  
  const { data: presets } = useGetPtzPresets(id, {
    query: { enabled: !!id && !!camera?.ptzEnabled, queryKey: ['presets', id] }
  })
  
  const { data: events } = useGetEvents({ cameraId: id, limit: 10 }, {
    query: { enabled: !!id, queryKey: ['events', id] }
  })

  const ptzMutation = useSendPtzCommand()
  const gotoPresetMutation = useGotoPtzPreset()

  const handlePtz = (action: 'up' | 'down' | 'left' | 'right' | 'zoom_in' | 'zoom_out' | 'stop' | 'home') => {
    ptzMutation.mutate({ id, data: { action, speed: 0.5 } })
  }

  const handleGotoPreset = (presetId: number) => {
    gotoPresetMutation.mutate({ id, presetId })
  }

  if (isLoadingCamera) {
    return <div className="animate-pulse space-y-6">
      <div className="h-8 bg-muted w-64 rounded"></div>
      <div className="aspect-video bg-muted rounded-xl"></div>
    </div>
  }

  if (!camera) return <div>Camera not found</div>

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold tracking-tight text-foreground">{camera.name}</h1>
            <Badge variant={camera.status === 'online' ? 'default' : 'destructive'} 
              className={camera.status === 'online' ? 'bg-emerald-500 hover:bg-emerald-600' : ''}>
              {camera.status}
            </Badge>
          </div>
          <p className="text-muted-foreground mt-1 flex items-center gap-2 text-sm">
            <MapPin className="w-4 h-4" /> {camera.location || 'No location set'} &middot; {camera.ip}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="overflow-hidden border-border/50 shadow-md bg-black relative aspect-video flex items-center justify-center">
            {streamInfo?.webrtcUrl ? (
               // In a real app, we'd use a WebRTC or HLS player here. 
               // For this mock, we'll render a video tag placeholder.
              <video 
                src={streamInfo.webrtcUrl} 
                autoPlay 
                muted 
                controls 
                className="w-full h-full object-contain"
                poster={`/api/cameras/${id}/snapshot`}
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-muted-foreground">
                <CameraIcon className="w-12 h-12 mb-4 opacity-20" />
                <p>Live stream initializing...</p>
              </div>
            )}
            
            {/* Overlay recording indicator if needed */}
            {camera.recordingEnabled && (
              <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/60 px-3 py-1.5 rounded-full text-xs font-medium text-white backdrop-blur-sm">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" /> REC
              </div>
            )}
          </Card>

          {/* Event History */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Recent Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {!events?.items?.length ? (
                  <div className="text-center py-6 text-muted-foreground text-sm">No recent events</div>
                ) : (
                  events.items.map(event => (
                    <div key={event.id} className="flex items-center gap-4 py-2 border-b border-border/50 last:border-0">
                      <div className="w-16 h-12 bg-muted rounded overflow-hidden flex-shrink-0 relative">
                        {event.snapshotUrl ? (
                          <img src={event.snapshotUrl} alt={event.type} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-muted/50"><Activity className="w-4 h-4 opacity-30" /></div>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm capitalize">{event.type} Detected</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" />
                          {format(new Date(event.timestamp), "MMM d, HH:mm:ss")}
                        </p>
                      </div>
                      <div className="text-xs font-medium bg-muted px-2 py-1 rounded">
                        {event.confidence ? `${Math.round(event.confidence * 100)}%` : '--'}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {camera.ptzEnabled && (
            <Card className="border-border/50">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">PTZ Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex justify-center">
                  <div className="grid grid-cols-3 gap-2 p-4 bg-muted/30 rounded-full w-48 h-48 relative shadow-inner">
                    <div className="col-start-2">
                      <Button variant="secondary" size="icon" className="w-full h-full rounded-t-full rounded-b-sm shadow-sm" onPointerDown={() => handlePtz('up')} onPointerUp={() => handlePtz('stop')} onPointerLeave={() => handlePtz('stop')}>
                        <ArrowUp className="w-5 h-5" />
                      </Button>
                    </div>
                    <div className="col-start-1 row-start-2">
                      <Button variant="secondary" size="icon" className="w-full h-full rounded-l-full rounded-r-sm shadow-sm" onPointerDown={() => handlePtz('left')} onPointerUp={() => handlePtz('stop')} onPointerLeave={() => handlePtz('stop')}>
                        <ArrowLeft className="w-5 h-5" />
                      </Button>
                    </div>
                    <div className="col-start-2 row-start-2 flex items-center justify-center">
                      <Button variant="ghost" size="icon" className="w-10 h-10 rounded-full hover:bg-primary/20 text-primary" onClick={() => handlePtz('home')}>
                        <MoveDiagonal className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="col-start-3 row-start-2">
                      <Button variant="secondary" size="icon" className="w-full h-full rounded-r-full rounded-l-sm shadow-sm" onPointerDown={() => handlePtz('right')} onPointerUp={() => handlePtz('stop')} onPointerLeave={() => handlePtz('stop')}>
                        <ArrowRight className="w-5 h-5" />
                      </Button>
                    </div>
                    <div className="col-start-2 row-start-3">
                      <Button variant="secondary" size="icon" className="w-full h-full rounded-b-full rounded-t-sm shadow-sm" onPointerDown={() => handlePtz('down')} onPointerUp={() => handlePtz('stop')} onPointerLeave={() => handlePtz('stop')}>
                        <ArrowDown className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="flex flex-col gap-1 h-14" onPointerDown={() => handlePtz('zoom_out')} onPointerUp={() => handlePtz('stop')} onPointerLeave={() => handlePtz('stop')}>
                    <ZoomOut className="w-4 h-4" />
                    <span className="text-[10px]">Zoom Out</span>
                  </Button>
                  <Button variant="outline" className="flex flex-col gap-1 h-14 text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/20" onClick={() => handlePtz('stop')}>
                    <MonitorStop className="w-4 h-4" />
                    <span className="text-[10px]">Stop All</span>
                  </Button>
                  <Button variant="outline" className="flex flex-col gap-1 h-14" onPointerDown={() => handlePtz('zoom_in')} onPointerUp={() => handlePtz('stop')} onPointerLeave={() => handlePtz('stop')}>
                    <ZoomIn className="w-4 h-4" />
                    <span className="text-[10px]">Zoom In</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {camera.ptzEnabled && (
            <Card className="border-border/50">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Presets</CardTitle>
              </CardHeader>
              <CardContent>
                {presets?.length ? (
                  <div className="grid grid-cols-2 gap-2">
                    {presets.map(preset => (
                      <Button 
                        key={preset.id} 
                        variant="secondary" 
                        className="justify-start truncate" 
                        onClick={() => handleGotoPreset(preset.id)}
                        disabled={gotoPresetMutation.isPending}
                      >
                        <MapPin className="w-3 h-3 mr-2 opacity-50 flex-shrink-0" />
                        <span className="truncate">{preset.name}</span>
                      </Button>
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground text-center py-4">No presets defined</div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
