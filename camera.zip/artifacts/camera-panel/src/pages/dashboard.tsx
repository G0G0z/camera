import { useGetDashboardStats } from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Camera, Users, Video, Activity, AlertTriangle, UserIcon, Car, ActivitySquare, Ban } from "lucide-react"
import { format } from "date-fns"

const EventIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'person': return <UserIcon className="w-4 h-4 text-blue-500" />
    case 'vehicle': return <Car className="w-4 h-4 text-orange-500" />
    case 'face': return <UserIcon className="w-4 h-4 text-indigo-500" />
    case 'tamper': return <Ban className="w-4 h-4 text-red-500" />
    case 'motion':
    default: return <ActivitySquare className="w-4 h-4 text-emerald-500" />
  }
}

export default function Dashboard() {
  const { data: stats, isLoading } = useGetDashboardStats()

  if (isLoading || !stats) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard Overview</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 animate-pulse">
          {[1,2,3,4].map(i => <div key={i} className="h-32 bg-muted rounded-xl"></div>)}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-1">System status and recent activities</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Cameras</CardTitle>
            <Camera className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalCameras}</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-emerald-500 flex items-center"><div className="w-2 h-2 rounded-full bg-emerald-500 mr-1" /> {stats.onlineCameras} online</span>
              <span className="text-xs text-red-500 flex items-center"><div className="w-2 h-2 rounded-full bg-red-500 mr-1" /> {stats.offlineCameras} offline</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recordings</CardTitle>
            <Video className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalRecordings}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <span className="text-primary font-medium">{stats.activeRecordings}</span> active now
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Events Today</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.todayEvents}</div>
            <p className="text-xs text-muted-foreground mt-1">AI & motion triggers</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.customers}</div>
            <p className="text-xs text-muted-foreground mt-1">Active accounts</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-2 lg:col-span-1 border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Recent Events
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {!stats.recentEvents?.length && (
                <div className="text-sm text-muted-foreground text-center py-6">No recent events</div>
              )}
              {stats.recentEvents?.map(event => (
                <div key={event.id} className="flex items-start gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors border border-transparent hover:border-border/50">
                  <div className="w-16 h-12 bg-muted rounded overflow-hidden flex-shrink-0 relative">
                    {event.snapshotUrl ? (
                      <img src={event.snapshotUrl} alt="Snapshot" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        <Camera className="w-4 h-4 opacity-30" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <EventIcon type={event.type} />
                      <span className="text-sm font-medium capitalize">{event.type}</span>
                      {event.confidence && (
                        <span className="text-xs text-muted-foreground ml-auto">
                          {Math.round(event.confidence * 100)}%
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">{event.cameraName || `Camera #${event.cameraId}`}</div>
                    <div className="text-xs text-muted-foreground mt-1 opacity-70">
                      {format(new Date(event.timestamp), "MMM d, HH:mm:ss")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
