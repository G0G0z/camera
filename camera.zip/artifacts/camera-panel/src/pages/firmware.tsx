import { useState } from "react"
import { useQuery, useMutation } from "@tanstack/react-query"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import {
  Cpu, Terminal, Wifi, CheckCircle2, XCircle, Loader2,
  Download, ChevronRight, AlertTriangle, Settings2, RefreshCw, Zap
} from "lucide-react"

// ── API helpers ───────────────────────────────────────────────────────────────
import { useAuthStore } from "@/store/auth"

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "")
const token = () => useAuthStore.getState().token || ""
const apiFetch = async (path: string, body: object) => {
  const r = await fetch(`${BASE}/api${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token()}` },
    body: JSON.stringify(body),
  })
  if (!r.ok) throw new Error((await r.json()).error || "İstek başarısız")
  return r.json()
}
const apiGet = async (path: string) => {
  const r = await fetch(`${BASE}/api${path}`, {
    headers: { Authorization: `Bearer ${token()}` },
  })
  if (!r.ok) throw new Error((await r.json()).error || "İstek başarısız")
  return r.json()
}

// ── Step göstergesi ───────────────────────────────────────────────────────────
function Step({ n, label, active, done }: { n: number; label: string; active: boolean; done: boolean }) {
  return (
    <div className={`flex items-center gap-2 text-sm ${active ? "text-foreground font-medium" : done ? "text-emerald-500" : "text-muted-foreground"}`}>
      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold border
        ${active ? "border-primary bg-primary text-primary-foreground" : done ? "border-emerald-500 bg-emerald-500 text-white" : "border-border"}`}>
        {done ? <CheckCircle2 className="w-3 h-3" /> : n}
      </div>
      {label}
    </div>
  )
}

// ── Komut kutusu ──────────────────────────────────────────────────────────────
function CommandBox({ commands, title }: { commands: string[]; title: string }) {
  const { toast } = useToast()
  const copy = () => {
    navigator.clipboard.writeText(commands.join("\n"))
    toast({ title: "Kopyalandı" })
  }
  return (
    <div className="rounded-md border border-border bg-muted/30 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/50">
        <span className="text-xs font-mono text-muted-foreground">{title}</span>
        <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={copy}>Kopyala</Button>
      </div>
      <pre className="p-3 text-xs font-mono text-emerald-400 overflow-x-auto leading-relaxed">
        {commands.map((c, i) => <div key={i}><span className="text-muted-foreground select-none">$ </span>{c}</div>)}
      </pre>
    </div>
  )
}

// ── Ana bileşen ───────────────────────────────────────────────────────────────
export default function FirmwarePage() {
  const { toast } = useToast()
  const [step, setStep] = useState(1) // 1=SoC seç, 2=Flash komutları, 3=Erişim testi, 4=Oto-kurulum

  // Flash formu
  const [socId, setSocId]       = useState("xm530")
  const [serverIp, setServerIp] = useState("192.168.1.100")
  const [cameraIp, setCameraIp] = useState("192.168.1.200")
  const [manual, setManual]     = useState(false)

  // Erişim testi formu
  const [testIp,   setTestIp]   = useState("192.168.1.200")
  const [testPass, setTestPass] = useState("12345")

  // Oto-kurulum formu
  const [setupIp,       setSetupIp]       = useState("")
  const [setupPass,     setSetupPass]     = useState("12345")
  const [newPass,       setNewPass]       = useState("")
  const [staticIp,      setStaticIp]      = useState("")
  const [hostname,      setHostname]      = useState("")
  const [cameraName,    setCameraName]    = useState("")
  const [addToPanel,    setAddToPanel]    = useState(true)

  // ── SoC listesi ──────────────────────────────────────────────────────────
  const { data: socList = [] } = useQuery({
    queryKey: ["soc-list"],
    queryFn: () => apiGet("/firmware/soc"),
  })

  // ── Flash komutları ───────────────────────────────────────────────────────
  const flashMutation = useMutation({
    mutationFn: () => apiFetch("/firmware/flash-commands", { soc: socId, serverIp, cameraIp, manual }),
    onSuccess: () => setStep(2),
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  // ── Erişim testi ──────────────────────────────────────────────────────────
  const checkMutation = useMutation({
    mutationFn: () => apiFetch("/firmware/check-access", { ip: testIp, pass: testPass }),
    onSuccess: (d) => {
      if (d.reachable) {
        toast({ title: "Bağlantı başarılı", description: `Firmware: ${d.info?.firmware || "bilinmiyor"}` })
        setSetupIp(testIp)
        setStep(4)
      } else {
        toast({ title: "Ulaşılamıyor", description: d.message, variant: "destructive" })
      }
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  // ── Oto-kurulum ───────────────────────────────────────────────────────────
  const setupMutation = useMutation({
    mutationFn: () => apiFetch("/firmware/auto-setup", {
      ip: setupIp, currentPass: setupPass,
      hostname, staticIp, newPassword: newPass,
      bitrate: 2048, fps: 20, codec: "h264",
      ntpServer: "pool.ntp.org",
      addToPanel, cameraName,
    }),
    onSuccess: (d) => {
      toast({ title: "Kurulum tamamlandı!", description: d.cameraId ? `Kamera panele eklendi (ID: ${d.cameraId})` : "Ayarlar uygulandı" })
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  const selectedSoc = (socList as any[]).find((s: any) => s.id === socId)

  return (
    <div className="max-w-3xl mx-auto space-y-6">

      {/* Başlık */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Cpu className="w-6 h-6 text-primary" /> Firmware Yönetimi
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          OpenIPC firmware yükleme ve kamera oto-yapılandırma
        </p>
      </div>

      {/* Adım göstergesi */}
      <div className="flex items-center gap-3 flex-wrap">
        <Step n={1} label="SoC & Flash" active={step === 1} done={step > 1} />
        <ChevronRight className="w-3 h-3 text-muted-foreground" />
        <Step n={2} label="U-Boot Komutları" active={step === 2} done={step > 2} />
        <ChevronRight className="w-3 h-3 text-muted-foreground" />
        <Step n={3} label="Erişim Testi" active={step === 3} done={step > 3} />
        <ChevronRight className="w-3 h-3 text-muted-foreground" />
        <Step n={4} label="Oto-Kurulum" active={step === 4} done={false} />
      </div>

      {/* ── ADIM 1: SoC seç & flash hazırlık ── */}
      {step >= 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Cpu className="w-4 h-4" /> 1. SoC ve IP Ayarları
            </CardTitle>
            <CardDescription>Kameranın çipini ve ağ adreslerini seçin</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* SoC grid */}
            <div>
              <Label className="mb-2 block">Kamera SoC (Çip)</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {(socList as any[]).map((s: any) => (
                  <button key={s.id}
                    onClick={() => setSocId(s.id)}
                    className={`text-left p-3 rounded-md border text-sm transition-colors
                      ${socId === s.id ? "border-primary bg-primary/5 text-foreground" : "border-border hover:border-primary/40 text-muted-foreground"}`}>
                    <div className="font-medium">{s.name}</div>
                    <div className="text-xs mt-0.5 text-muted-foreground">{s.flash} flash · {s.sensors.slice(0, 2).join(", ")}</div>
                    {s.id === "xm530" && <Badge className="mt-1 text-[10px] h-4" variant="secondary">Önerilen</Badge>}
                  </button>
                ))}
              </div>
              {selectedSoc?.notes && (
                <p className="text-xs text-muted-foreground mt-2 bg-muted/40 px-3 py-2 rounded-md">
                  {selectedSoc.notes}
                </p>
              )}
            </div>

            {/* IP adresleri */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>TFTP Sunucu IP (bilgisayarınız)</Label>
                <Input value={serverIp} onChange={e => setServerIp(e.target.value)} placeholder="192.168.1.100" className="font-mono text-sm" />
              </div>
              <div className="space-y-1">
                <Label>Kamera IP (geçici)</Label>
                <Input value={cameraIp} onChange={e => setCameraIp(e.target.value)} placeholder="192.168.1.200" className="font-mono text-sm" />
              </div>
            </div>

            {/* Manuel mod */}
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={manual} onChange={e => setManual(e.target.checked)} className="rounded" />
              <span>Manuel flash komutları kullan <span className="text-muted-foreground">(setnor/uknor alias yoksa)</span></span>
            </label>

            <Button onClick={() => flashMutation.mutate()} disabled={flashMutation.isPending} className="w-full">
              {flashMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Terminal className="w-4 h-4 mr-2" />}
              Flash Komutlarını Oluştur
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── ADIM 2: U-Boot komutları ── */}
      {step >= 2 && flashMutation.data && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Terminal className="w-4 h-4" /> 2. U-Boot Flash Komutları
            </CardTitle>
            <CardDescription>
              UART konsolunda U-Boot'u durdurun, aşağıdaki komutları sırayla girin
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">

            {/* TFTP sunucu kurulum notu */}
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-md p-3 text-sm text-amber-200 flex gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                Önce <strong>{flashMutation.data.tftp.serverIp}</strong> adresli bilgisayarınıza TFTP sunucusu kurun ve
                firmware dosyalarını <code className="bg-black/20 px-1 rounded">{flashMutation.data.tftp.directory}</code> dizinine kopyalayın.
              </div>
            </div>

            {/* Dosya indirme linkleri */}
            <div className="space-y-2">
              <Label>Firmware Dosyaları</Label>
              {Object.entries(flashMutation.data.downloads as Record<string, string>).map(([type, url]) => (
                <a key={type} href={url} target="_blank" rel="noreferrer"
                  className="flex items-center justify-between p-2 rounded-md border border-border hover:border-primary/40 text-sm transition-colors">
                  <span className="font-mono text-xs">{flashMutation.data.files[type]}</span>
                  <Download className="w-4 h-4 text-muted-foreground" />
                </a>
              ))}
            </div>

            {/* Komutlar */}
            <CommandBox
              title={`U-Boot — ${flashMutation.data.soc.name} (${flashMutation.data.soc.flash} flash)`}
              commands={flashMutation.data.commands}
            />

            <Button variant="outline" className="w-full" onClick={() => setStep(3)}>
              Flash tamamlandı, erişim testine geç <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── ADIM 3: SSH erişim testi ── */}
      {step >= 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Wifi className="w-4 h-4" /> 3. SSH Erişim Testi
            </CardTitle>
            <CardDescription>OpenIPC yüklendikten sonra kameraya bağlanabildiğinizi doğrulayın</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Kamera IP</Label>
                <Input value={testIp} onChange={e => setTestIp(e.target.value)} placeholder="192.168.1.200" className="font-mono text-sm" />
              </div>
              <div className="space-y-1">
                <Label>SSH Şifresi <span className="text-muted-foreground text-xs">(varsayılan: 12345)</span></Label>
                <Input value={testPass} onChange={e => setTestPass(e.target.value)} type="password" />
              </div>
            </div>

            <Button onClick={() => checkMutation.mutate()} disabled={checkMutation.isPending} className="w-full">
              {checkMutation.isPending
                ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Bağlanıyor...</>
                : <><Wifi className="w-4 h-4 mr-2" />Bağlantı Test Et</>}
            </Button>

            {checkMutation.data && (
              <div className={`rounded-md p-3 text-sm flex items-start gap-2 ${checkMutation.data.reachable ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-300" : "bg-red-500/10 border border-red-500/30 text-red-300"}`}>
                {checkMutation.data.reachable
                  ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  : <XCircle className="w-4 h-4 shrink-0 mt-0.5" />}
                <div>
                  {checkMutation.data.reachable ? (
                    <>
                      <div className="font-medium">Bağlantı başarılı</div>
                      <div className="text-xs mt-1 space-y-0.5 font-mono">
                        {Object.entries(checkMutation.data.info as Record<string, string>).slice(0, 6).map(([k, v]) => v && (
                          <div key={k}><span className="text-muted-foreground">{k}:</span> {v}</div>
                        ))}
                      </div>
                    </>
                  ) : checkMutation.data.message}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── ADIM 4: Oto-kurulum ── */}
      {step >= 4 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Settings2 className="w-4 h-4" /> 4. Otomatik Yapılandırma
            </CardTitle>
            <CardDescription>Kamerayı SSH ile yapılandırın ve panele ekleyin</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Kamera IP</Label>
                <Input value={setupIp} onChange={e => setSetupIp(e.target.value)} className="font-mono text-sm" />
              </div>
              <div className="space-y-1">
                <Label>Mevcut SSH Şifresi</Label>
                <Input value={setupPass} onChange={e => setSetupPass(e.target.value)} type="password" />
              </div>
              <div className="space-y-1">
                <Label>Yeni Şifre <span className="text-muted-foreground text-xs">(12345 değiştirin!)</span></Label>
                <Input value={newPass} onChange={e => setNewPass(e.target.value)} type="password" placeholder="Güçlü şifre..." />
              </div>
              <div className="space-y-1">
                <Label>Statik IP <span className="text-muted-foreground text-xs">(opsiyonel)</span></Label>
                <Input value={staticIp} onChange={e => setStaticIp(e.target.value)} placeholder="192.168.1.50" className="font-mono text-sm" />
              </div>
              <div className="space-y-1">
                <Label>Hostname</Label>
                <Input value={hostname} onChange={e => setHostname(e.target.value)} placeholder="kamera-giris-1" className="font-mono text-sm" />
              </div>
              <div className="space-y-1">
                <Label>Panel Adı</Label>
                <Input value={cameraName} onChange={e => setCameraName(e.target.value)} placeholder="Ana Giriş Kamerası" />
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={addToPanel} onChange={e => setAddToPanel(e.target.checked)} className="rounded" />
              <span>Kurulum sonrası kamerayı panele otomatik ekle</span>
            </label>

            <Button onClick={() => setupMutation.mutate()} disabled={setupMutation.isPending} className="w-full">
              {setupMutation.isPending
                ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Yapılandırılıyor...</>
                : <><Zap className="w-4 h-4 mr-2" />Yapılandırmayı Başlat</>}
            </Button>

            {setupMutation.isSuccess && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-md p-3 text-sm text-emerald-300">
                <div className="font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Kurulum tamamlandı
                </div>
                <div className="text-xs mt-2 font-mono space-y-0.5">
                  {Object.entries(setupMutation.data.results as Record<string, boolean>).map(([k, v]) => (
                    <div key={k}>{v ? "✓" : "✗"} {k}</div>
                  ))}
                </div>
                {setupMutation.data.rtspUrl && (
                  <div className="mt-2 text-xs">
                    RTSP: <code className="bg-black/20 px-1 rounded">{setupMutation.data.rtspUrl}</code>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
