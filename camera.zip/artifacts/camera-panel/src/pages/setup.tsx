import { useState, useEffect, useRef } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useMutation, useQuery } from "@tanstack/react-query"
import { QRCodeSVG } from "qrcode.react"
import { useAuthStore } from "@/store/auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import {
  QrCode, Wifi, Camera, MapPin, CheckCircle2, Clock, RefreshCw,
  Loader2, Eye, EyeOff, Download, ArrowRight, ChevronLeft, XCircle
} from "lucide-react"
import { Link } from "wouter"

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "")
const apiFetch = async (method: string, path: string, body?: object) => {
  const token = useAuthStore.getState().token
  const r = await fetch(`${BASE}/api${path}`, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: body ? JSON.stringify(body) : undefined,
  })
  if (r.status === 204) return null
  const d = await r.json()
  if (!r.ok) throw new Error(d.error || "Hata")
  return d
}

const schema = z.object({
  name:     z.string().min(1, "Kamera adı gerekli"),
  location: z.string().optional(),
  ssid:     z.string().min(1, "WiFi ağ adı gerekli"),
  password: z.string().optional(),
  security: z.enum(["WPA", "WEP", "NOPASS"]),
})
type FormValues = z.infer<typeof schema>

// ─── Adım 1: Form ─────────────────────────────────────────────────────────────
function Step1({ onGenerated }: { onGenerated: (data: any) => void }) {
  const [showPass, setShowPass] = useState(false)
  const { toast } = useToast()

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", location: "", ssid: "", password: "", security: "WPA" },
  })

  const mutation = useMutation({
    mutationFn: (v: FormValues) => apiFetch("POST", "/provision/generate", v),
    onSuccess: (data) => onGenerated(data),
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Yeni Kamera Ekle</h1>
        <p className="text-muted-foreground text-sm mt-1">
          WiFi bilgilerini girin, QR kodu oluşturun ve kameranızın önüne tutun.
        </p>
      </div>

      {/* Adım göstergesi */}
      <div className="flex items-center gap-2 text-sm">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">1</div>
          <span className="font-medium">Bilgileri Gir</span>
        </div>
        <div className="flex-1 h-px bg-border" />
        <div className="flex items-center gap-1.5 opacity-40">
          <div className="w-6 h-6 rounded-full border-2 border-border flex items-center justify-center text-xs font-bold">2</div>
          <span>QR Göster</span>
        </div>
        <div className="flex-1 h-px bg-border" />
        <div className="flex items-center gap-1.5 opacity-40">
          <div className="w-6 h-6 rounded-full border-2 border-border flex items-center justify-center text-xs font-bold">3</div>
          <span>Bağlandı</span>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Camera className="w-4 h-4" /> Kamera Bilgileri
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(v => mutation.mutate(v))} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kamera Adı *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Camera className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input className="pl-9" placeholder="Ana Giriş" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="location" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Konum</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input className="pl-9" placeholder="1. Kat, A Kapı" {...field} />
                      </div>
                    </FormControl>
                  </FormItem>
                )} />
              </div>

              <div className="pt-2 border-t">
                <p className="text-sm font-medium flex items-center gap-2 mb-3">
                  <Wifi className="w-4 h-4" /> WiFi Bağlantısı
                </p>
                <div className="space-y-3">
                  <FormField control={form.control} name="ssid" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ağ Adı (SSID) *</FormLabel>
                      <FormControl><Input placeholder="Ofis_Wifi" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="security" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Güvenlik Tipi</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="WPA">WPA / WPA2 / WPA3</SelectItem>
                          <SelectItem value="WEP">WEP (Eski)</SelectItem>
                          <SelectItem value="NOPASS">Şifresiz (Açık ağ)</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )} />

                  {form.watch("security") !== "NOPASS" && (
                    <FormField control={form.control} name="password" render={({ field }) => (
                      <FormItem>
                        <FormLabel>WiFi Şifresi</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPass ? "text" : "password"}
                              placeholder="WiFi şifresi"
                              {...field}
                            />
                            <button
                              type="button"
                              onClick={() => setShowPass(p => !p)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            >
                              {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </FormControl>
                      </FormItem>
                    )} />
                  )}
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={mutation.isPending}>
                {mutation.isPending
                  ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Oluşturuluyor...</>
                  : <><QrCode className="w-4 h-4 mr-2" />QR Kodu Oluştur<ArrowRight className="w-4 h-4 ml-2" /></>
                }
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Adım 2: QR + Bekleme ─────────────────────────────────────────────────────
function Step2({ token, qrPayload, onConnected, onBack }: {
  token: string
  qrPayload: string
  onConnected: (cameraId: number) => void
  onBack: () => void
}) {
  const svgRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const [elapsed, setElapsed] = useState(0)

  // QR boyutunu büyük tut
  const QR_SIZE = 280

  // Poll: kamera bağlandı mı?
  const { data: statusData } = useQuery({
    queryKey: ["provision-status", token],
    queryFn:  () => apiFetch("GET", `/provision/status/${token}`),
    refetchInterval: 2000,
    enabled: !!token,
  })

  useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 1), 1000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    if (statusData?.status === "connected" && statusData?.cameraId) {
      onConnected(statusData.cameraId)
    }
  }, [statusData, onConnected])

  const downloadQR = () => {
    const svg = svgRef.current?.querySelector("svg")
    if (!svg) return
    const blob = new Blob([svg.outerHTML], { type: "image/svg+xml" })
    const a = document.createElement("a")
    a.href = URL.createObjectURL(blob)
    a.download = `opticsight-setup-qr.svg`
    a.click()
    toast({ title: "QR indirildi" })
  }

  const isExpired = statusData?.status === "expired"
  const mins = Math.floor(elapsed / 60)
  const secs = elapsed % 60

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">QR Kodu Kameraya Gösterin</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Kamera bağlanana kadar bekleyin</p>
        </div>
      </div>

      {/* Adım göstergesi */}
      <div className="flex items-center gap-2 text-sm">
        <div className="flex items-center gap-1.5 opacity-40">
          <div className="w-6 h-6 rounded-full border-2 border-border flex items-center justify-center text-xs font-bold">1</div>
          <span>Bilgileri Gir</span>
        </div>
        <div className="flex-1 h-px bg-primary" />
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">2</div>
          <span className="font-medium">QR Göster</span>
        </div>
        <div className="flex-1 h-px bg-border" />
        <div className="flex items-center gap-1.5 opacity-40">
          <div className="w-6 h-6 rounded-full border-2 border-border flex items-center justify-center text-xs font-bold">3</div>
          <span>Bağlandı</span>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="text-center space-y-5">
            {/* QR — büyük, beyaz arka plan */}
            <div
              ref={svgRef}
              className="inline-flex items-center justify-center bg-white rounded-2xl p-6 shadow-md mx-auto"
            >
              <QRCodeSVG
                value={qrPayload}
                size={QR_SIZE}
                level="M"
                includeMargin={false}
              />
            </div>

            {/* Durum */}
            {isExpired ? (
              <div className="flex items-center justify-center gap-2 text-destructive">
                <XCircle className="w-5 h-5" />
                <span className="font-medium">QR süresi doldu — geri dönüp yeniden oluşturun</span>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2 text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Kamera bağlantısı bekleniyor... {mins}:{secs.toString().padStart(2, "0")}</span>
              </div>
            )}

            {/* Talimat */}
            <div className="bg-muted rounded-xl p-4 text-left space-y-2">
              <p className="text-sm font-medium">Nasıl yapılır:</p>
              <ol className="text-sm text-muted-foreground space-y-1.5 list-decimal list-inside">
                <li>Kamerayı fabrika ayarlarına sıfırlayın</li>
                <li>Kamera açılışını bekleyin (~30 sn)</li>
                <li>Bu QR kodunu kameranın önüne tutun</li>
                <li>Kamera QR'ı okur, WiFi'ye bağlanır ve otomatik kaydolur</li>
              </ol>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={onBack}>
                <ChevronLeft className="w-4 h-4 mr-1" /> Geri
              </Button>
              <Button variant="outline" className="flex-1" onClick={downloadQR}>
                <Download className="w-4 h-4 mr-1" /> İndir
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-center text-xs text-muted-foreground">
        QR kodu 1 saat geçerlidir. Kameranın WiFi menzilinde olduğundan emin olun.
      </p>
    </div>
  )
}

// ─── Adım 3: Başarı ───────────────────────────────────────────────────────────
function Step3({ cameraId }: { cameraId: number }) {
  return (
    <div className="max-w-lg mx-auto">
      {/* Adım göstergesi */}
      <div className="flex items-center gap-2 text-sm mb-6">
        <div className="flex items-center gap-1.5 opacity-40">
          <div className="w-6 h-6 rounded-full border-2 border-border flex items-center justify-center text-xs font-bold">1</div>
          <span>Bilgileri Gir</span>
        </div>
        <div className="flex-1 h-px bg-primary" />
        <div className="flex items-center gap-1.5 opacity-40">
          <div className="w-6 h-6 rounded-full border-2 border-border flex items-center justify-center text-xs font-bold">2</div>
          <span>QR Göster</span>
        </div>
        <div className="flex-1 h-px bg-primary" />
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-bold">✓</div>
          <span className="font-medium">Bağlandı</span>
        </div>
      </div>

      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="pt-8 pb-8 text-center space-y-5">
          <div className="w-20 h-20 bg-emerald-500/15 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10 text-emerald-500" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Kamera Bağlandı!</h2>
            <p className="text-muted-foreground text-sm mt-1">
              Kamera hesabınıza başarıyla kaydedildi ve yönetim panelinde aktif.
            </p>
          </div>
          <div className="flex gap-3 justify-center">
            <Link href={`/cameras/${cameraId}`}>
              <Button>
                <Camera className="w-4 h-4 mr-2" /> Kamerayı Görüntüle
              </Button>
            </Link>
            <Link href="/setup">
              <Button variant="outline">
                <QrCode className="w-4 h-4 mr-2" /> Başka Kamera Ekle
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Ana Sayfa ─────────────────────────────────────────────────────────────────
export default function SetupPage() {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [provToken, setProvToken] = useState("")
  const [qrPayload, setQrPayload] = useState("")
  const [cameraId, setCameraId] = useState<number>(0)

  const handleGenerated = (data: any) => {
    setProvToken(data.token)
    setQrPayload(data.qrPayload)
    setStep(2)
  }

  const handleConnected = (id: number) => {
    setCameraId(id)
    setStep(3)
  }

  return (
    <div className="py-2">
      {step === 1 && <Step1 onGenerated={handleGenerated} />}
      {step === 2 && (
        <Step2
          token={provToken}
          qrPayload={qrPayload}
          onConnected={handleConnected}
          onBack={() => setStep(1)}
        />
      )}
      {step === 3 && <Step3 cameraId={cameraId} />}
    </div>
  )
}
