import { useParams, Link } from "wouter"
import { useGetCustomer, useGetCustomerCameras } from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Building2, Mail, Phone, Calendar, ArrowLeft, Camera, Settings, ExternalLink } from "lucide-react"

export default function CustomerDetail() {
  const params = useParams()
  const id = Number(params.id)

  const { data: customer, isLoading: isLoadingCustomer } = useGetCustomer(id, {
    query: { enabled: !!id, queryKey: ['customer', id] }
  })

  const { data: cameras, isLoading: isLoadingCameras } = useGetCustomerCameras(id, {
    query: { enabled: !!id, queryKey: ['customer-cameras', id] }
  })

  if (isLoadingCustomer) {
    return <div className="p-8 animate-pulse space-y-6">
      <div className="h-8 bg-muted w-48 rounded"></div>
      <div className="h-64 bg-muted rounded-xl"></div>
    </div>
  }

  if (!customer) return <div>Customer not found</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild className="shrink-0">
          <Link href="/customers"><ArrowLeft className="w-4 h-4" /></Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
            {customer.name}
          </h1>
          <p className="text-muted-foreground mt-1 flex items-center gap-2">
            Tenant Account ID: {customer.id}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5 text-primary" /> Company Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-y-4 text-sm">
              <div className="text-muted-foreground flex items-center gap-2">
                <Mail className="w-4 h-4" /> Email
              </div>
              <div className="font-medium">{customer.email || 'Not provided'}</div>
              
              <div className="text-muted-foreground flex items-center gap-2">
                <Phone className="w-4 h-4" /> Phone
              </div>
              <div className="font-medium">{customer.phone || 'Not provided'}</div>
              
              <div className="text-muted-foreground flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Joined
              </div>
              <div className="font-medium">{new Date(customer.createdAt).toLocaleDateString()}</div>
            </div>
            
            <div className="pt-4 mt-4 border-t border-border/50">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Account Quotas</span>
              </div>
              <div className="text-sm flex justify-between items-center p-2 bg-muted/50 rounded-md">
                <span className="text-muted-foreground">Cameras</span>
                <span className="font-semibold">{customer.cameraCount || 0} / 50</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 border-border/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Camera className="w-5 h-5 text-primary" /> Assigned Cameras
            </CardTitle>
            <Button variant="outline" size="sm">
              Manage Allocation
            </Button>
          </CardHeader>
          <CardContent>
            {isLoadingCameras ? (
              <div className="h-32 flex items-center justify-center text-muted-foreground">Loading cameras...</div>
            ) : !cameras?.length ? (
              <div className="py-8 text-center bg-muted/20 rounded-lg border border-dashed border-border mt-2">
                <Camera className="w-8 h-8 opacity-20 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No cameras assigned to this customer</p>
              </div>
            ) : (
              <div className="mt-4 border rounded-md overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="bg-muted/50 text-muted-foreground border-b border-border/50">
                    <tr>
                      <th className="font-medium p-3">Name / Location</th>
                      <th className="font-medium p-3">IP Address</th>
                      <th className="font-medium p-3">Status</th>
                      <th className="font-medium p-3 text-right">View</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {cameras.map(camera => (
                      <tr key={camera.id} className="hover:bg-muted/30">
                        <td className="p-3">
                          <div className="font-medium">{camera.name}</div>
                          <div className="text-xs text-muted-foreground">{camera.location || '--'}</div>
                        </td>
                        <td className="p-3 text-muted-foreground font-mono text-xs">{camera.ip}</td>
                        <td className="p-3">
                          <Badge variant={camera.status === 'online' ? 'default' : 'secondary'} 
                                 className={camera.status === 'online' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : ''}>
                            {camera.status}
                          </Badge>
                        </td>
                        <td className="p-3 text-right">
                          <Button variant="ghost" size="icon" asChild>
                            <Link href={`/cameras/${camera.id}`}><ExternalLink className="w-4 h-4" /></Link>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
