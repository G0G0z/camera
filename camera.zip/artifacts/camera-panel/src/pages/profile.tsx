import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import { useLocation } from "wouter"
import { useGetMe } from "@workspace/api-client-react"
import { useAuthStore } from "@/store/auth"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { User, Lock, Trash2, Loader2, CheckCircle2, ShieldAlert } from "lucide-react"

const BASE   = import.meta.env.BASE_URL.replace(/\/$/, "")
const apiFetch = async (path: string, body: object, token: string) => {
  const r = await fetch(`${BASE}/api${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  })
  const data = await r.json()
  if (!r.ok) throw new Error(data.error || "Hata")
  return data
}

// ── Profil formu ──────────────────────────────────────────────────────────────
const profileSchema = z.object({
  name:  z.string().min(2, "En az 2 karakter"),
  email: z.string().email("Geçersiz e-posta"),
})

function ProfileForm({ user }: { user: any }) {
  const { toast } = useToast()
  const qc        = useQueryClient()
  const token     = useAuthStore(s => s.token) || ""

  const form = useForm({ resolver: zodResolver(profileSchema), values: { name: user.name || "", email: user.email } })

  const mutation = useMutation({
    mutationFn: (v: any) => apiFetch("/auth/profile", v, token),
    onSuccess: () => {
      toast({ title: "Profil güncellendi" })
      qc.invalidateQueries({ queryKey: ["me"] })
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2"><User className="w-4 h-4" /> Profil Bilgileri</CardTitle>
        <CardDescription>Adınızı ve e-postanızı güncelleyin</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center text-lg font-bold">
            {(user.name || user.email).charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="font-medium">{user.name || user.email}</p>
            <Badge variant="secondary" className="text-xs capitalize">{user.role}</Badge>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(v => mutation.mutate(v))} className="space-y-4">
            <FormField control={form.control} name="name" render={({ field }) => (
              <FormItem>
                <FormLabel>Ad Soyad</FormLabel>
                <FormControl><Input {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="email" render={({ field }) => (
              <FormItem>
                <FormLabel>E-posta</FormLabel>
                <FormControl><Input type="email" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <Button type="submit" disabled={mutation.isPending} size="sm">
              {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
              Kaydet
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}

// ── Şifre formu ───────────────────────────────────────────────────────────────
const passSchema = z.object({
  currentPassword: z.string().min(1, "Mevcut şifre gerekli"),
  newPassword:     z.string().min(6, "En az 6 karakter"),
  confirm:         z.string(),
}).refine(d => d.newPassword === d.confirm, { message: "Şifreler eşleşmiyor", path: ["confirm"] })

function PasswordForm() {
  const { toast } = useToast()
  const token     = useAuthStore(s => s.token) || ""

  const form = useForm({ resolver: zodResolver(passSchema), defaultValues: { currentPassword: "", newPassword: "", confirm: "" } })

  const mutation = useMutation({
    mutationFn: (v: any) => apiFetch("/auth/change-password", v, token),
    onSuccess: () => {
      toast({ title: "Şifre güncellendi" })
      form.reset()
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2"><Lock className="w-4 h-4" /> Şifre Değiştir</CardTitle>
        <CardDescription>Güvenliğiniz için şifrenizi düzenli olarak değiştirin</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(v => mutation.mutate(v))} className="space-y-4">
            <FormField control={form.control} name="currentPassword" render={({ field }) => (
              <FormItem>
                <FormLabel>Mevcut Şifre</FormLabel>
                <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid grid-cols-2 gap-4">
              <FormField control={form.control} name="newPassword" render={({ field }) => (
                <FormItem>
                  <FormLabel>Yeni Şifre</FormLabel>
                  <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="confirm" render={({ field }) => (
                <FormItem>
                  <FormLabel>Tekrar</FormLabel>
                  <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <Button type="submit" disabled={mutation.isPending} size="sm">
              {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Lock className="w-4 h-4 mr-2" />}
              Şifreyi Güncelle
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}

// ── Hesabı sil ────────────────────────────────────────────────────────────────
function DeleteAccountSection({ user }: { user: any }) {
  const [open, setOpen]   = useState(false)
  const [pass, setPass]   = useState("")
  const { toast }         = useToast()
  const [, setLocation]   = useLocation()
  const logout            = useAuthStore(s => s.logout)
  const token             = useAuthStore(s => s.token) || ""

  const mutation = useMutation({
    mutationFn: () => apiFetch("/auth/delete-account", { password: pass }, token),
    onSuccess: () => {
      toast({ title: "Hesabınız silindi" })
      logout()
      setLocation("/login")
    },
    onError: (e: any) => toast({ title: "Hata", description: e.message, variant: "destructive" }),
  })

  if (user.role === "superadmin") return null

  return (
    <Card className="border-destructive/30">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2 text-destructive">
          <ShieldAlert className="w-4 h-4" /> Tehlikeli Alan
        </CardTitle>
        <CardDescription>Bu işlemler geri alınamaz</CardDescription>
      </CardHeader>
      <CardContent>
        {!open ? (
          <Button variant="destructive" size="sm" onClick={() => setOpen(true)}>
            <Trash2 className="w-4 h-4 mr-2" /> Hesabımı Sil
          </Button>
        ) : (
          <div className="space-y-3 max-w-sm">
            <p className="text-sm text-muted-foreground">Hesabınızı silmek için şifrenizi girin. Bu işlem geri alınamaz.</p>
            <Input type="password" placeholder="Şifreniz" value={pass} onChange={e => setPass(e.target.value)} />
            <div className="flex gap-2">
              <Button variant="destructive" size="sm" onClick={() => mutation.mutate()} disabled={!pass || mutation.isPending}>
                {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Evet, sil"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => { setOpen(false); setPass("") }}>İptal</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// ── Ana bileşen ───────────────────────────────────────────────────────────────
export default function ProfilePage() {
  const { data: user } = useGetMe()

  if (!user) return (
    <div className="flex items-center justify-center h-48 text-muted-foreground">
      <Loader2 className="w-5 h-5 animate-spin mr-2" /> Yükleniyor...
    </div>
  )

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Hesabım</h1>
        <p className="text-muted-foreground text-sm mt-1">Profil bilgilerinizi ve güvenlik ayarlarınızı yönetin</p>
      </div>
      <ProfileForm user={user} />
      <PasswordForm />
      <DeleteAccountSection user={user} />
    </div>
  )
}
