import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  setAuthenticated: (value: boolean) => void;
  setToken: (token: string | null) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      token: null,
      setAuthenticated: (value) => set({ isAuthenticated: value }),
      setToken: (token) => set({ token, isAuthenticated: !!token }),
      logout: () => set({ isAuthenticated: false, token: null }),
    }),
    { name: 'opticsight-auth', partialize: (s) => ({ token: s.token, isAuthenticated: s.isAuthenticated }) }
  )
);
