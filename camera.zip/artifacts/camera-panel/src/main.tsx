import { createRoot } from 'react-dom/client';
import { setAuthTokenGetter } from '@workspace/api-client-react';
import { useAuthStore } from '@/store/auth';
import App from './App';
import './index.css';

// Token'ı her API isteğine otomatik ekle
setAuthTokenGetter(() => useAuthStore.getState().token);

createRoot(document.getElementById('root')!).render(<App />);
