#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# OpenIPC — XM530 için TFTP sunucu kurulumu (Linux/Ubuntu/Debian)
# Kullanım: sudo bash tftp-setup.sh [soc] [flash_boyutu]
# Örnek   : sudo bash tftp-setup.sh xm530 8m
# ─────────────────────────────────────────────────────────────────────────────

set -e
SOC="${1:-xm530}"
FLASH="${2:-8m}"
TFTP_DIR="/var/lib/tftpboot"

echo "╔═══════════════════════════════════════╗"
echo "║  OpenIPC TFTP Kurulum — $SOC ($FLASH)  ║"
echo "╚═══════════════════════════════════════╝"

# tftpd-hpa kur
if ! command -v in.tftpd &>/dev/null; then
    echo ">> tftpd-hpa ve curl yükleniyor..."
    apt-get update -qq
    apt-get install -y tftpd-hpa curl
fi

# TFTP dizini
mkdir -p "$TFTP_DIR"
chmod 777 "$TFTP_DIR"

# tftpd yapılandır
cat > /etc/default/tftpd-hpa <<EOF
TFTP_USERNAME="tftp"
TFTP_DIRECTORY="$TFTP_DIR"
TFTP_ADDRESS=":69"
TFTP_OPTIONS="--secure"
EOF

systemctl restart tftpd-hpa
systemctl enable tftpd-hpa

# Firmware dosyalarını indir
BASE="https://github.com/OpenIPC/firmware/releases/download/latest"
UBOOT="openipc.${SOC}-br.${FLASH}.uboot"
ROOTFS="openipc.${SOC}-br.${FLASH}.tgz"

echo ""
echo ">> Firmware dosyaları indiriliyor..."
curl -L --progress-bar -o "$TFTP_DIR/$UBOOT"  "$BASE/$UBOOT"
curl -L --progress-bar -o "$TFTP_DIR/$ROOTFS" "$BASE/$ROOTFS"

ls -lh "$TFTP_DIR/"

SERVER_IP=$(hostname -I | awk '{print $1}')

echo ""
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║  TFTP HAZIR — Şimdi kameranın UART konsoluna bağlanın        ║"
echo "╠═══════════════════════════════════════════════════════════════╣"
echo "║  UART Ayarları: 115200 baud, 8N1, akış kontrolü YOK          ║"
echo "║  Araç: minicom / putty / screen                               ║"
echo "╠═══════════════════════════════════════════════════════════════╣"
echo "║  U-Boot'ta şu komutları çalıştırın:                          ║"
echo "║                                                               ║"
echo "║  setenv serverip $SERVER_IP"
echo "║  setenv ipaddr   192.168.1.200                                ║"
echo "║  setenv netmask  255.255.255.0                                ║"
echo "║  run setnor${FLASH}                                                 ║"
echo "║  run uknor${FLASH}                                                  ║"
echo "║                                                               ║"
echo "║  (setnor/uknor alias yoksa: bash tftp-setup.sh $SOC $FLASH manual) ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
