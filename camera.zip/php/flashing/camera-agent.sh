#!/bin/sh
# =============================================================================
# OpticSight Kamera Ajanı — OpenIPC / Majestic
# Kameranın panele olay (hareket, yapay zeka tespiti) ve durum raporlaması
# =============================================================================
# Kurulum:
#   1. Bu dosyayı kameraya kopyalayın (panel otomatik yapar):
#        scp camera-agent.sh root@<KAMERA_IP>:/usr/local/bin/camera-agent.sh
#   2. Çalıştırılabilir yapın ve başlatın:
#        chmod +x /usr/local/bin/camera-agent.sh
#        camera-agent.sh install
# =============================================================================

set -e

AGENT_VERSION="1.0.0"
CONFIG_FILE="/etc/opticsight.conf"
PID_FILE="/var/run/camera-agent.pid"
LOG_FILE="/var/log/camera-agent.log"
MAJESTIC_YAML="/etc/majestic.yaml"

# ─── Renksiz log ─────────────────────────────────────────────────────────────
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

# ─── Config oku ──────────────────────────────────────────────────────────────
load_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        log "HATA: Config dosyası bulunamadı: $CONFIG_FILE"
        log "      Kurulum için: $0 install <PANEL_URL> <CAMERA_TOKEN>"
        exit 1
    fi
    . "$CONFIG_FILE"

    # Zorunlu değerler
    : "${PANEL_URL:?CONFIG_FILE içinde PANEL_URL tanımlanmamış}"
    : "${CAMERA_TOKEN:?CONFIG_FILE içinde CAMERA_TOKEN tanımlanmamış}"
    PANEL_URL="${PANEL_URL%/}"   # sondaki / kaldır
}

# ─── Panel API çağrısı ────────────────────────────────────────────────────────
api_post() {
    # $1 = endpoint (/api/events gibi)
    # $2 = JSON body
    curl -s -S --max-time 8 \
        -H "Content-Type: application/json" \
        -H "X-Camera-Token: ${CAMERA_TOKEN}" \
        -d "$2" \
        "${PANEL_URL}$1" 2>&1
}

# ─── Olay gönder ─────────────────────────────────────────────────────────────
send_event() {
    TYPE="$1"       # motion | person | vehicle | face | tamper
    CONFIDENCE="${2:-}"
    SNAPSHOT_URL="${3:-}"

    BODY="{\"type\":\"${TYPE}\""
    [ -n "$CONFIDENCE" ]   && BODY="${BODY},\"confidence\":${CONFIDENCE}"
    [ -n "$SNAPSHOT_URL" ] && BODY="${BODY},\"snapshotUrl\":\"${SNAPSHOT_URL}\""
    BODY="${BODY}}"

    RESULT=$(api_post "/api/events" "$BODY")
    log "Olay gönderildi: type=$TYPE conf=$CONFIDENCE → $RESULT"
}

# ─── Anlık görüntü URL'i üret ────────────────────────────────────────────────
get_snapshot_url() {
    MY_IP=$(ip addr show eth0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    echo "http://${MY_IP}/image.jpg"
}

# ─── Heartbeat (durum bildirimi) ──────────────────────────────────────────────
send_heartbeat() {
    UPTIME=$(cat /proc/uptime | cut -d. -f1)
    MEM_FREE=$(grep MemFree /proc/meminfo | awk '{print $2}')
    DISK_FREE=$(df / | tail -1 | awk '{print $4}')
    FW_VER=$(cat /etc/openipc_version 2>/dev/null | head -1 || echo "unknown")
    MY_IP=$(ip addr show eth0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)

    BODY="{\"status\":\"online\",\"ip\":\"${MY_IP}\",\"uptime\":${UPTIME},\"memFreeKb\":${MEM_FREE},\"diskFreeKb\":${DISK_FREE},\"firmware\":\"${FW_VER}\"}"

    RESULT=$(api_post "/api/cameras/heartbeat" "$BODY" 2>/dev/null || echo "panel erişilemez")
    log "Heartbeat → $RESULT"
}

# ─── Majestic motion webhook'unu panele yönlendir ────────────────────────────
configure_majestic_webhook() {
    load_config
    WEBHOOK_URL="${PANEL_URL}/api/cameras/majestic-hook?token=${CAMERA_TOKEN}"

    log "Majestic webhook ayarlanıyor: $WEBHOOK_URL"

    # Majestic CLI ile ayarla
    cli -s .motionDetect.enabled true          2>/dev/null || true
    cli -s .motionDetect.threshold 10          2>/dev/null || true
    cli -s .motionDetect.webhookURL "$WEBHOOK_URL" 2>/dev/null || true

    # AI obje tespiti (varsa)
    cli -s .objectDetect.enabled true          2>/dev/null || true
    cli -s .objectDetect.webhookURL "$WEBHOOK_URL" 2>/dev/null || true

    # Majestic yeniden başlat
    killall -1 majestic 2>/dev/null || true
    sleep 2
    log "Majestic yeniden başlatıldı"
}

# ─── Majestic'ten gelen webhook'u dinle (yerel HTTP sunucu) ──────────────────
# Majestic aynı cihazda olduğu için 127.0.0.1:8484'e POST atar,
# ajan bunu alıp panele iletir.
start_webhook_listener() {
    PORT=8484
    log "Webhook dinleyici başlatıldı: 0.0.0.0:$PORT"

    # BusyBox nc ile basit HTTP sunucu döngüsü
    while true; do
        # nc her bağlantıda bir kez çalışır
        RAW=$(echo -e "HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK" | \
              nc -l -p "$PORT" 2>/dev/null)

        # Majestic webhook body'sini ayrıştır
        # Örnek body: {"event":"md","region":0} veya {"event":"ai","class":"person","confidence":0.87}
        BODY=$(echo "$RAW" | awk '/^\r?$/{found=1;next} found{print}' | head -1)
        [ -z "$BODY" ] && continue

        EVENT_TYPE=$(echo "$BODY" | grep -o '"event":"[^"]*"' | cut -d'"' -f4)
        AI_CLASS=$(echo "$BODY"   | grep -o '"class":"[^"]*"'  | cut -d'"' -f4)
        CONFIDENCE=$(echo "$BODY" | grep -o '"confidence":[0-9.]*' | cut -d: -f2)

        SNAP=$(get_snapshot_url)

        case "$EVENT_TYPE" in
            md|motion)
                send_event "motion" "" "$SNAP"
                ;;
            ai)
                case "$AI_CLASS" in
                    person|human)   send_event "person"  "$CONFIDENCE" "$SNAP" ;;
                    vehicle|car)    send_event "vehicle" "$CONFIDENCE" "$SNAP" ;;
                    face)           send_event "face"    "$CONFIDENCE" "$SNAP" ;;
                    *)              send_event "motion"  "$CONFIDENCE" "$SNAP" ;;
                esac
                ;;
            tamper)
                send_event "tamper" "" "$SNAP"
                ;;
        esac
    done
}

# ─── Heartbeat döngüsü ────────────────────────────────────────────────────────
start_heartbeat_loop() {
    INTERVAL="${HEARTBEAT_INTERVAL:-60}"
    log "Heartbeat döngüsü başlatıldı (her ${INTERVAL}s)"
    while true; do
        send_heartbeat
        sleep "$INTERVAL"
    done
}

# ─── Kurulum ─────────────────────────────────────────────────────────────────
cmd_install() {
    PANEL_URL_ARG="$1"
    TOKEN_ARG="$2"
    CAMERA_NAME_ARG="${3:-OpenIPC Kamera}"

    if [ -z "$PANEL_URL_ARG" ] || [ -z "$TOKEN_ARG" ]; then
        echo "Kullanım: $0 install <PANEL_URL> <CAMERA_TOKEN> [KAMERA_ADI]"
        echo "Örnek  : $0 install https://panel.sirketim.com abc123token 'Ana Giriş'"
        exit 1
    fi

    # Config dosyası oluştur
    cat > "$CONFIG_FILE" <<EOF
# OpticSight Kamera Ajanı Yapılandırması
# Otomatik oluşturuldu: $(date)
PANEL_URL="${PANEL_URL_ARG}"
CAMERA_TOKEN="${TOKEN_ARG}"
CAMERA_NAME="${CAMERA_NAME_ARG}"
HEARTBEAT_INTERVAL=60
EOF
    chmod 600 "$CONFIG_FILE"
    log "Config yazıldı: $CONFIG_FILE"

    # Kendini /usr/local/bin'e kopyala
    cp "$0" /usr/local/bin/camera-agent.sh
    chmod +x /usr/local/bin/camera-agent.sh

    # Majestic webhook'u ayarla
    configure_majestic_webhook

    # /etc/init.d/ startup scripti
    cat > /etc/init.d/S99camera-agent <<'INITEOF'
#!/bin/sh
case "$1" in
    start)
        echo "OpticSight ajanı başlatılıyor..."
        /usr/local/bin/camera-agent.sh start &
        ;;
    stop)
        echo "OpticSight ajanı durduruluyor..."
        kill $(cat /var/run/camera-agent.pid 2>/dev/null) 2>/dev/null || true
        ;;
    restart)
        $0 stop; sleep 1; $0 start
        ;;
    *)
        echo "Kullanım: $0 {start|stop|restart}"
        exit 1
esac
INITEOF
    chmod +x /etc/init.d/S99camera-agent

    log "Kurulum tamamlandı. Ajan başlatılıyor..."
    /etc/init.d/S99camera-agent start
}

# ─── Başlat ───────────────────────────────────────────────────────────────────
cmd_start() {
    load_config

    echo $$ > "$PID_FILE"
    log "OpticSight Kamera Ajanı v${AGENT_VERSION} başlatıldı (PID: $$)"

    # Webhook dinleyici arka planda
    start_webhook_listener &
    LISTENER_PID=$!

    # Heartbeat döngüsü arka planda
    start_heartbeat_loop &
    HEARTBEAT_PID=$!

    # Her iki süreç de ölürse çık
    wait $LISTENER_PID $HEARTBEAT_PID
    rm -f "$PID_FILE"
}

# ─── Durdur ───────────────────────────────────────────────────────────────────
cmd_stop() {
    if [ -f "$PID_FILE" ]; then
        kill "$(cat $PID_FILE)" 2>/dev/null && log "Ajan durduruldu"
        rm -f "$PID_FILE"
    else
        log "PID dosyası bulunamadı, ajan çalışmıyor olabilir"
    fi
}

# ─── Durum ────────────────────────────────────────────────────────────────────
cmd_status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat $PID_FILE)" 2>/dev/null; then
        echo "Ajan ÇALIŞIYOR (PID: $(cat $PID_FILE))"
    else
        echo "Ajan ÇALIŞMIYOR"
    fi
    [ -f "$CONFIG_FILE" ] && grep "PANEL_URL\|CAMERA_NAME" "$CONFIG_FILE"
}

# ─── Log göster ───────────────────────────────────────────────────────────────
cmd_logs() {
    tail -n "${1:-50}" "$LOG_FILE" 2>/dev/null || echo "Log dosyası yok"
}

# ─── Test: Manuel olay gönder ─────────────────────────────────────────────────
cmd_test() {
    load_config
    log "Test olayı gönderiliyor (person, %90 güven)..."
    send_event "person" "0.90" "$(get_snapshot_url)"
    log "Test tamamlandı"
}

# ─── Ana komut yönlendirici ───────────────────────────────────────────────────
case "${1:-start}" in
    install)   cmd_install "$2" "$3" "$4" ;;
    start)     cmd_start ;;
    stop)      cmd_stop ;;
    restart)   cmd_stop; sleep 1; cmd_start ;;
    status)    cmd_status ;;
    logs)      cmd_logs "$2" ;;
    test)      cmd_test ;;
    configure-webhook) load_config; configure_majestic_webhook ;;
    *)
        echo "Kullanım: $0 {install|start|stop|restart|status|logs|test|configure-webhook}"
        echo ""
        echo "  install <URL> <TOKEN> [AD]  — Panele bağla ve başlat"
        echo "  start                       — Ajanı başlat"
        echo "  stop                        — Ajanı durdur"
        echo "  status                      — Çalışma durumunu göster"
        echo "  logs [N]                    — Son N satır log (varsayılan: 50)"
        echo "  test                        — Panele test olayı gönder"
        echo "  configure-webhook           — Majestic webhook'unu yeniden ayarla"
        exit 1
esac
