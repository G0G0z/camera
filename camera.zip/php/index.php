<?php
declare(strict_types=1);

// ─── Gzip sıkıştırma ─────────────────────────────────────────────────────────
if (!empty($_SERVER['HTTP_ACCEPT_ENCODING']) &&
    str_contains($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) {
    ob_start('ob_gzhandler');
}

// ─── Bootstrap ───────────────────────────────────────────────────────────────
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/Database.php';
require_once __DIR__ . '/lib/Response.php';
require_once __DIR__ . '/lib/Auth.php';
require_once __DIR__ . '/lib/Router.php';
require_once __DIR__ . '/lib/Onvif.php';

// Controller'ları sadece ihtiyaç olunca yükle (autoloader)
$__ctrlDir = __DIR__ . '/controllers/';
spl_autoload_register(function (string $class) use ($__ctrlDir) {
    $path = $__ctrlDir . $class . '.php';
    if (file_exists($path)) require_once $path;
});

// ─── CORS ────────────────────────────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ─── Servisler ────────────────────────────────────────────────────────────────
$router = new Router();
$db     = Database::getInstance();
$auth   = new Auth($db);

// ─── Lazy controller factory'leri (sadece eşleşen route tetiklendiğinde new) ─
$ac  = static fn() => new AuthController($db, $auth);
$cam = static fn() => new CameraController($db, $auth);
$ptz = static fn() => new PtzController($db, $auth);
$rc  = static fn() => new RecordingController($db, $auth);
$ec  = static fn() => new EventController($db, $auth);
$uc  = static fn() => new UserController($db, $auth);
$cc  = static fn() => new CustomerController($db, $auth);
$dc  = static fn() => new DashboardController($db, $auth);
$fc  = static fn() => new FirmwareController($db, $auth);
$reg = static fn() => new RegisterController($db, $auth);
$wc  = static fn() => new WifiController($db, $auth);
$pc  = static fn() => new ProvisionController($db, $auth);
$alc = static fn() => new AlarmController($db, $auth);
$ptc = static fn() => new PatrolController($db, $auth);

// ─── Routes ──────────────────────────────────────────────────────────────────

// Health
$router->get('/api/healthz', fn() => Response::json(['status' => 'ok']));

// ── Auth ──────────────────────────────────────────────────────────────────────
$router->post('/api/auth/login',           fn() => $ac()->login());
$router->post('/api/auth/logout',          fn() => $ac()->logout());
$router->get('/api/auth/me',               fn() => $ac()->me($auth->requireAuth()));
$router->delete('/api/auth/me',            fn() => $ac()->deleteAccount($auth->requireAuth()));
$router->post('/api/auth/profile',         fn() => $ac()->updateProfile($auth->requireAuth()));
$router->post('/api/auth/change-password', fn() => $ac()->changePassword($auth->requireAuth()));
$router->post('/api/auth/register',        fn() => $reg()->register());

// ── Dashboard ─────────────────────────────────────────────────────────────────
$router->get('/api/dashboard/stats', fn() => $dc()->stats($auth->requireAuth()));

// ── Cameras — sabit yollar wildcard'dan önce ──────────────────────────────────
$router->get('/api/cameras/status-all',        fn() => $cam()->statusAll($auth->requireAuth()));
$router->get('/api/cameras/config',            fn() => $cam()->configForAgent());
$router->get('/api/cameras',                   fn() => $cam()->index($auth->requireAuth()));
$router->post('/api/cameras',                  fn() => $cam()->store($auth->requireAuth()));
$router->get('/api/cameras/{id}',              fn($p) => $cam()->show($auth->requireAuth(), (int)$p['id']));
$router->put('/api/cameras/{id}',              fn($p) => $cam()->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/cameras/{id}',           fn($p) => $cam()->destroy($auth->requireAuth(), (int)$p['id']));
$router->get('/api/cameras/{id}/snapshot',     fn($p) => $cam()->snapshot($auth->requireAuth(), (int)$p['id']));
$router->get('/api/cameras/{id}/stream',       fn($p) => $cam()->stream($auth->requireAuth(), (int)$p['id']));
$router->post('/api/cameras/{id}/heartbeat',   fn($p) => $cam()->heartbeat());

// ── PTZ ───────────────────────────────────────────────────────────────────────
// Presets — spesifik yollar önce
$router->post('/api/cameras/{id}/ptz/presets/{pid}/goto', fn($p) => $ptz()->gotoPreset($auth->requireAuth(), (int)$p['id'], (int)$p['pid']));
$router->delete('/api/cameras/{id}/ptz/presets/{pid}',    fn($p) => $ptz()->deletePreset($auth->requireAuth(), (int)$p['id'], (int)$p['pid']));
$router->get('/api/cameras/{id}/ptz/presets',             fn($p) => $ptz()->presets($auth->requireAuth(), (int)$p['id']));
$router->post('/api/cameras/{id}/ptz/presets',            fn($p) => $ptz()->savePreset($auth->requireAuth(), (int)$p['id']));
// PTZ hareketi
$router->post('/api/cameras/{id}/ptz',                    fn($p) => $ptz()->command($auth->requireAuth(), (int)$p['id']));

// ── Recordings — sabit yollar önce ───────────────────────────────────────────
$router->get('/api/recordings/storage-stats',  fn() => $rc()->storageStats($auth->requireAuth()));
$router->get('/api/recordings',                fn() => $rc()->index($auth->requireAuth()));
$router->post('/api/recordings/start',         fn() => $rc()->start($auth->requireAuth()));
$router->get('/api/recordings/{id}',           fn($p) => $rc()->show($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/recordings/{id}',        fn($p) => $rc()->destroy($auth->requireAuth(), (int)$p['id']));
$router->post('/api/recordings/{id}/stop',     fn($p) => $rc()->stop($auth->requireAuth(), (int)$p['id']));

// ── Events ────────────────────────────────────────────────────────────────────
$router->get('/api/events/recent',   fn() => $ec()->recent($auth->requireAuth()));
$router->get('/api/events',          fn() => $ec()->index($auth->requireAuth()));
$router->post('/api/events',         fn() => $ec()->store($auth->requireAuth()));
$router->delete('/api/events/{id}',  fn($p) => $ec()->destroy($auth->requireAuth(), (int)$p['id']));

// ── Users ─────────────────────────────────────────────────────────────────────
$router->get('/api/users',           fn() => $uc()->index($auth->requireAuth()));
$router->post('/api/users',          fn() => $uc()->store($auth->requireAuth()));
$router->get('/api/users/{id}',      fn($p) => $uc()->show($auth->requireAuth(), (int)$p['id']));
$router->put('/api/users/{id}',      fn($p) => $uc()->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/users/{id}',   fn($p) => $uc()->destroy($auth->requireAuth(), (int)$p['id']));

// ── Customers ─────────────────────────────────────────────────────────────────
$router->get('/api/customers',                  fn() => $cc()->index($auth->requireAuth()));
$router->post('/api/customers',                 fn() => $cc()->store($auth->requireAuth()));
$router->get('/api/customers/{id}',             fn($p) => $cc()->show($auth->requireAuth(), (int)$p['id']));
$router->put('/api/customers/{id}',             fn($p) => $cc()->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/customers/{id}',          fn($p) => $cc()->destroy($auth->requireAuth(), (int)$p['id']));
$router->get('/api/customers/{id}/cameras',     fn($p) => $cc()->cameras($auth->requireAuth(), (int)$p['id']));

// ── Firmware ──────────────────────────────────────────────────────────────────
$router->get('/api/firmware/soc',              fn() => $fc()->socList($auth->requireAuth()));
$router->post('/api/firmware/flash-commands',  fn() => $fc()->flashCommands($auth->requireAuth()));
$router->post('/api/firmware/version-check',   fn() => $fc()->checkFirmwareVersion($auth->requireAuth()));
$router->post('/api/firmware/update',          fn() => $fc()->updateFirmware($auth->requireAuth()));
$router->post('/api/firmware/auto-setup',      fn() => $fc()->autoSetup($auth->requireAuth()));
$router->get('/api/firmware/majestic',         fn() => $fc()->getMajesticConfig($auth->requireAuth()));
$router->post('/api/firmware/majestic',        fn() => $fc()->setMajesticValue($auth->requireAuth()));
$router->post('/api/firmware/access-check',    fn() => $fc()->checkAccess($auth->requireAuth()));

// ── WiFi ──────────────────────────────────────────────────────────────────────
$router->post('/api/wifi/qr-string',   fn() => $wc()->qrString($auth->requireAuth()));
$router->get('/api/wifi',              fn() => $wc()->index($auth->requireAuth()));
$router->post('/api/wifi',             fn() => $wc()->store($auth->requireAuth()));
$router->delete('/api/wifi/{id}',      fn($p) => $wc()->destroy($auth->requireAuth(), (int)$p['id']));

// ── Provision ─────────────────────────────────────────────────────────────────
$router->get('/api/provision',                    fn() => $pc()->list($auth->requireAuth()));
$router->post('/api/provision/generate',          fn() => $pc()->generate($auth->requireAuth()));
$router->post('/api/provision/register',          fn() => $pc()->register());
$router->get('/api/provision/{token}/status',     fn($p) => $pc()->status($auth->requireAuth(), $p['token']));
$router->delete('/api/provision/{token}',         fn($p) => $pc()->cancel($auth->requireAuth(), $p['token']));

// ── Alarms ────────────────────────────────────────────────────────────────────
$router->get('/api/alarms',          fn() => $alc()->index($auth->requireAuth()));
$router->post('/api/alarms',         fn() => $alc()->store($auth->requireAuth()));
$router->put('/api/alarms/{id}',     fn($p) => $alc()->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/alarms/{id}',  fn($p) => $alc()->destroy($auth->requireAuth(), (int)$p['id']));

// ── Majestic webhook (kamera AI/hareket olaylarını panele iletir, token auth) ─
$router->post('/api/cameras/majestic-hook',    fn() => $cam()->majesticHook());

// ── Patrol routes ─────────────────────────────────────────────────────────────
$router->get('/api/patrol-routes',                  fn() => $ptc()->index($auth->requireAuth()));
$router->post('/api/patrol-routes',                 fn() => $ptc()->store($auth->requireAuth()));
$router->put('/api/patrol-routes/{id}',             fn($p) => $ptc()->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/patrol-routes/{id}',          fn($p) => $ptc()->destroy($auth->requireAuth(), (int)$p['id']));
$router->post('/api/patrol-routes/{id}/start',      fn($p) => $ptc()->startPatrol($auth->requireAuth(), (int)$p['id']));
$router->post('/api/patrol-routes/{id}/stop',       fn($p) => $ptc()->stopPatrol($auth->requireAuth(), (int)$p['id']));

// ─── Dispatch ─────────────────────────────────────────────────────────────────
$router->dispatch($_SERVER['REQUEST_METHOD'], $_SERVER['REQUEST_URI']);
