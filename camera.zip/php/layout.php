<?php
$pageTitle  = $pageTitle  ?? 'OpticSight';
$activePage = $activePage ?? '';
$userName   = $user['name']  ?? ($user['email'] ?? 'Kullanıcı');
$userRole   = $user['role']  ?? '';
$userInitial = strtoupper(mb_substr($userName, 0, 1));

$nav = [
    ['href' => '/',          'label' => 'Dashboard',    'icon' => 'layout-dashboard', 'key' => 'dashboard'],
    ['href' => '/monitor',   'label' => 'Canlı İzleme', 'icon' => 'monitor',          'key' => 'monitor'],
    ['href' => '/cameras',   'label' => 'Kameralar',    'icon' => 'camera',           'key' => 'cameras'],
    ['href' => '/setup',     'label' => 'Kamera Ekle',  'icon' => 'qr-code',          'key' => 'setup'],
    ['href' => '/patrol',    'label' => 'Devriye',      'icon' => 'navigation',       'key' => 'patrol',    'roles' => ['superadmin','admin']],
    ['href' => '/alarms',    'label' => 'Alarmlar',     'icon' => 'bell',             'key' => 'alarms',    'roles' => ['superadmin','admin']],
    ['href' => '/recordings','label' => 'Kayıtlar',     'icon' => 'video',            'key' => 'recordings'],
    ['href' => '/events',    'label' => 'Olaylar',      'icon' => 'activity',         'key' => 'events'],
    ['href' => '/provision', 'label' => 'Provizyon',    'icon' => 'link',             'key' => 'provision', 'roles' => ['superadmin','admin']],
    ['href' => '/customers', 'label' => 'Müşteriler',   'icon' => 'users',            'key' => 'customers', 'roles' => ['superadmin']],
    ['href' => '/users',     'label' => 'Kullanıcılar', 'icon' => 'user-circle',      'key' => 'users',     'roles' => ['superadmin','admin']],
    ['href' => '/firmware',  'label' => 'Firmware',     'icon' => 'cpu',              'key' => 'firmware',  'roles' => ['superadmin']],
    ['href' => '/wifi-setup','label' => 'WiFi',         'icon' => 'wifi',             'key' => 'wifi',      'roles' => ['superadmin','admin']],
];

$svgIcons = [
    'layout-dashboard' => '<path d="M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z"/>',
    'monitor'          => '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
    'camera'           => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    'qr-code'          => '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="5" y="5" width="3" height="3" fill="currentColor"/><rect x="16" y="5" width="3" height="3" fill="currentColor"/><rect x="16" y="16" width="3" height="3" fill="currentColor"/><rect x="5" y="16" width="3" height="3" fill="currentColor"/>',
    'navigation'       => '<polygon points="3 11 22 2 13 21 11 13 3 11"/>',
    'bell'             => '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    'video'            => '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>',
    'activity'         => '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    'link'             => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    'users'            => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    'user-circle'      => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    'cpu'              => '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
    'wifi'             => '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
    'log-out'          => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    'user'             => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
];

function renderIcon(string $key, array $svgIcons, string $cls = 'w-4 h-4'): string {
    $path = $svgIcons[$key] ?? '';
    return '<svg xmlns="http://www.w3.org/2000/svg" class="' . $cls . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($pageTitle) ?> — OpticSight PTZ</title>
  <link rel="icon" href="/assets/favicon.svg" type="image/svg+xml" />
<?php $av = filemtime(__DIR__ . '/assets/app.js'); ?>
  <script>
    tailwind = { config: {
      darkMode: 'class',
      theme: { extend: { colors: {
        sidebar: 'hsl(224 71% 4%)',
        'sidebar-foreground': 'hsl(213 31% 91%)',
        'sidebar-border': 'hsl(216 34% 17%)',
        'sidebar-accent': 'hsl(216 34% 17%)',
      }}}
    }};
  </script>
  <script src="/assets/tailwind.js?v=1"></script>
  <link rel="stylesheet" href="/assets/app.css?v=<?= $av ?>" />
  <script src="/assets/app.js?v=<?= $av ?>"></script>
  <script>window.__TOKEN__ = <?= json_encode($token ?? null) ?>;</script>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen flex flex-col md:flex-row">

<!-- Sidebar -->
<aside class="w-full md:w-56 bg-zinc-900 border-b md:border-b-0 md:border-r border-zinc-800 flex-shrink-0 flex flex-col">
  <div class="p-4 border-b border-zinc-800 flex items-center gap-2">
    <?= renderIcon('camera', $svgIcons, 'w-5 h-5 text-blue-500') ?>
    <span class="text-sm font-semibold text-zinc-100">OpticSight PTZ</span>
  </div>

  <nav class="flex-1 p-2 space-y-0.5 overflow-y-auto">
    <?php foreach ($nav as $item): ?>
      <?php
        if (!empty($item['roles']) && !in_array($userRole, $item['roles'], true)) continue;
        $isActive = ($activePage === $item['key']);
        $cls = $isActive
          ? 'flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium bg-zinc-800 text-zinc-100'
          : 'flex items-center gap-2.5 px-3 py-2 rounded-md text-xs text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100 transition-colors';
      ?>
      <a href="<?= $item['href'] ?>" class="<?= $cls ?>">
        <?= renderIcon($item['icon'], $svgIcons, 'w-3.5 h-3.5 shrink-0') ?>
        <?= htmlspecialchars($item['label']) ?>
      </a>
    <?php endforeach ?>
  </nav>

  <div class="p-2 border-t border-zinc-800 flex items-center justify-between">
    <a href="/profile" class="flex items-center gap-2 min-w-0 hover:opacity-80 transition-opacity p-1">
      <div class="w-7 h-7 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center font-semibold text-xs shrink-0">
        <?= htmlspecialchars($userInitial) ?>
      </div>
      <div class="flex flex-col min-w-0">
        <span class="text-xs font-medium text-zinc-200 truncate max-w-[100px]"><?= htmlspecialchars($userName) ?></span>
        <span class="text-[10px] text-zinc-500 capitalize"><?= htmlspecialchars($userRole) ?></span>
      </div>
    </a>
    <button onclick="App.logout()" title="Çıkış" class="text-zinc-500 hover:text-red-400 p-1.5 rounded-md hover:bg-red-500/10 transition-colors">
      <?= renderIcon('log-out', $svgIcons, 'w-3.5 h-3.5') ?>
    </button>
  </div>
</aside>

<!-- Main content -->
<main class="flex-1 flex flex-col min-w-0 overflow-hidden">
  <div class="flex-1 overflow-y-auto p-4 md:p-6">
