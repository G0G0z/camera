<?php
declare(strict_types=1);

// .env dosyası varsa yükle
if (file_exists(__DIR__ . '/.env')) {
    foreach (file(__DIR__ . '/.env') as $line) {
        $line = trim($line);
        if ($line && !str_starts_with($line, '#') && str_contains($line, '=')) {
            [$k, $v] = explode('=', $line, 2);
            putenv(trim($k) . '=' . trim($v, " \t\n\r\"'"));
        }
    }
}

function env(string $key, mixed $default = null): mixed
{
    $v = getenv($key);
    return $v !== false ? $v : $default;
}

// ─── Veritabanı (JSON dosyaları) ─────────────────────────────────────────────
define('DATA_DIR', env('DATA_DIR', __DIR__ . '/data'));

// ─── Auth ─────────────────────────────────────────────────────────────────────
define('JWT_SECRET', env('JWT_SECRET', 'gizli-anahtar-production-da-degistir'));
define('JWT_TTL',    3600 * 24 * 30); // 30 gün

// ─── MediaMTX (opsiyonel — RTSP→WebRTC relay) ─────────────────────────────────
define('MEDIAMTX_API',   env('MEDIAMTX_API',   'http://localhost:9997'));
define('MEDIAMTX_HLS',   env('MEDIAMTX_HLS',   ''));
define('MEDIAMTX_WEBRTC',env('MEDIAMTX_WEBRTC', ''));

// ─── Kayıtlar ─────────────────────────────────────────────────────────────────
define('RECORDINGS_DIR', env('RECORDINGS_DIR', __DIR__ . '/recordings'));

// ─── Kamera push webhook anahtarı ────────────────────────────────────────────
// Kameralar olayları POST /api/events ile gönderirken bu anahtarı
// X-Camera-Token header'ında kullanır. Üretimde mutlaka değiştirin.
define('CAMERA_PUSH_TOKEN', env('CAMERA_PUSH_TOKEN', 'degistir-bunu-production-da'));

// ─── Panel URL (provizyon QR'ına gömülür) ─────────────────────────────────────
// Boş bırakılırsa istek başlığından otomatik algılanır.
// Örnek: define('PANEL_URL', 'https://panel.sirketiniz.com');
define('PANEL_URL', env('PANEL_URL', ''));
