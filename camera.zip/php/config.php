<?php
declare(strict_types=1);

// ═══════════════════════════════════════════════════════════════════════════════
//  OpticSight — Yapılandırma
//  Ayar gerektirmez. Sunucuya yükle, çalıştır.
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Dizinler ─────────────────────────────────────────────────────────────────
define('DATA_DIR',       __DIR__ . '/data');
define('RECORDINGS_DIR', __DIR__ . '/recordings');

// ─── JWT Secret — ilk çalıştırmada otomatik üretilir, data/.secret'e kaydedilir
function _app_secret(): string
{
    // data/ dizini henüz yoksa oluştur
    if (!is_dir(DATA_DIR)) @mkdir(DATA_DIR, 0755, true);

    $file = DATA_DIR . '/.secret';

    if (is_readable($file)) {
        $s = trim((string)@file_get_contents($file));
        if (strlen($s) >= 32) return $s;
    }

    // İlk kez — rastgele 64 karakterlik secret üret
    $secret = bin2hex(random_bytes(32));
    @file_put_contents($file, $secret, LOCK_EX);
    @chmod($file, 0600);
    return $secret;
}

define('JWT_SECRET', _app_secret());
define('JWT_TTL',    3600 * 24 * 30);  // 30 gün

// ─── Kamera push token — JWT secret'ten türetilir, sabit kalır ───────────────
// Kamera ajanları X-Camera-Token başlığında per-camera token kullanır.
// Bu global token ek bir güvenlik katmanı olarak korunur.
define('CAMERA_PUSH_TOKEN', hash_hmac('sha256', 'camera-push-v1', JWT_SECRET));

// ─── Panel URL — HTTP isteğinden otomatik algılanır ──────────────────────────
// ProvisionController QR üretirken HTTP_HOST + HTTPS'den URL'yi kendisi kurar.
// Burası boş bırakılırsa otomatik algılama devreye girer — ayar gerekmez.
define('PANEL_URL', '');

// ─── MediaMTX — opsiyonel RTSP relay (InfinityFree'de kullanılmaz) ────────────
define('MEDIAMTX_API',    '');
define('MEDIAMTX_HLS',    '');
define('MEDIAMTX_WEBRTC', '');
