<?php
declare(strict_types=1);

class UserController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $users = $user['role'] === 'superadmin'
            ? $this->db->all('users')
            : $this->db->where('users', ['customer_id' => $user['customer_id']]);

        Response::json(array_map([$this, 'format'], $users));
    }

    public function store(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $b = Response::body();

        $email = strtolower(trim($b['email'] ?? ''));
        if (!$email) Response::abort(400, 'Email gerekli');
        if (!($b['password'] ?? '')) Response::abort(400, 'Şifre gerekli');
        if ($this->db->findBy('users', 'email', $email)) Response::abort(409, 'Bu email zaten kayıtlı');

        // Admin kendi müşterisine kullanıcı ekleyebilir
        $customerId = $user['role'] === 'superadmin'
            ? (isset($b['customerId']) ? (int)$b['customerId'] : null)
            : $user['customer_id'];

        $new = $this->db->insert('users', [
            'email'         => $email,
            'name'          => $b['name'] ?? null,
            'password_hash' => $this->auth->hashPassword($b['password']),
            'role'          => $b['role'] ?? 'viewer',
            'customer_id'   => $customerId,
        ]);

        Response::json($this->format($new), 201);
    }

    public function update(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $target = $this->db->find('users', $id);
        if (!$target) Response::abort(404, 'Kullanıcı bulunamadı');

        $b = Response::body();
        $changes = [];
        if (isset($b['email'])) $changes['email'] = strtolower(trim($b['email']));
        if (isset($b['name']))  $changes['name']  = $b['name'];
        if (isset($b['role']))  $changes['role']  = $b['role'];
        if (!empty($b['password'])) $changes['password_hash'] = $this->auth->hashPassword($b['password']);

        $updated = $this->db->update('users', $id, $changes);
        Response::json($this->format($updated));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        if ($id === (int)$user['id']) Response::abort(400, 'Kendinizi silemezsiniz');
        $target = $this->db->find('users', $id);
        if (!$target) Response::abort(404, 'Kullanıcı bulunamadı');

        // Admin yalnızca kendi müşterisindeki non-superadmin kullanıcıları silebilir
        if ($user['role'] !== 'superadmin') {
            if (($target['customer_id'] ?? null) != ($user['customer_id'] ?? null)) {
                Response::abort(403, 'Bu kullanıcıyı silme izniniz yok');
            }
            if ($target['role'] === 'superadmin') {
                Response::abort(403, 'Superadmin hesabı silinemez');
            }
        }

        $this->db->delete('users', $id);
        Response::noContent();
    }

    private function format(array $u): array
    {
        return [
            'id'         => (int)$u['id'],
            'email'      => $u['email'],
            'name'       => $u['name'] ?? null,
            'role'       => $u['role'],
            'customerId' => isset($u['customer_id']) ? (int)$u['customer_id'] : null,
            'createdAt'  => $u['created_at'],
        ];
    }
}
