<?php
declare(strict_types=1);

class PatrolController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $patrols = $this->db->all('patrol_routes');
        if ($user['role'] !== 'superadmin') {
            $camIds  = array_column($this->db->where('cameras', ['customer_id' => $user['customer_id']]), 'id');
            $patrols = array_values(array_filter($patrols, fn($p) => in_array((int)$p['camera_id'], $camIds)));
        }
        Response::json(array_map([$this, 'format'], $patrols));
    }

    public function store(array $user): void
    {
        $b    = Response::body();
        $name = trim($b['name'] ?? '');
        if (!$name) Response::abort(400, 'Devriye adı gerekli');
        if (empty($b['cameraId'])) Response::abort(400, 'Kamera seçilmedi');

        $patrol = $this->db->insert('patrol_routes', [
            'name'          => $name,
            'camera_id'     => (int)$b['cameraId'],
            'preset_ids'    => json_encode(array_map('intval', (array)($b['presetIds'] ?? []))),
            'dwell_seconds' => max(3, (int)($b['dwellSeconds'] ?? 10)),
            'speed'         => min(1.0, max(0.1, (float)($b['speed'] ?? 0.5))),
        ]);
        Response::json($this->format($patrol), 201);
    }

    public function update(array $user, int $id): void
    {
        $patrol = $this->db->find('patrol_routes', $id);
        if (!$patrol) Response::abort(404, 'Devriye rotası bulunamadı');

        $b       = Response::body();
        $changes = [];
        if (array_key_exists('name', $b))          $changes['name']          = trim($b['name']);
        if (array_key_exists('presetIds', $b))      $changes['preset_ids']    = json_encode(array_map('intval', (array)$b['presetIds']));
        if (array_key_exists('dwellSeconds', $b))   $changes['dwell_seconds'] = max(3, (int)$b['dwellSeconds']);
        if (array_key_exists('speed', $b))          $changes['speed']         = min(1.0, max(0.1, (float)$b['speed']));

        $updated = $this->db->update('patrol_routes', $id, $changes);
        Response::json($this->format($updated));
    }

    public function destroy(array $user, int $id): void
    {
        $patrol = $this->db->find('patrol_routes', $id);
        if (!$patrol) Response::abort(404, 'Devriye rotası bulunamadı');
        $this->db->delete('patrol_routes', $id);
        Response::json(['ok' => true]);
    }

    private function format(array $p): array
    {
        $presetIds = json_decode($p['preset_ids'] ?? '[]', true);
        if (!is_array($presetIds)) $presetIds = [];

        return [
            'id'           => (int)$p['id'],
            'name'         => $p['name'],
            'cameraId'     => (int)$p['camera_id'],
            'presetIds'    => array_map('intval', $presetIds),
            'dwellSeconds' => (int)($p['dwell_seconds'] ?? 10),
            'speed'        => (float)($p['speed'] ?? 0.5),
            'createdAt'    => $p['created_at'],
        ];
    }
}
