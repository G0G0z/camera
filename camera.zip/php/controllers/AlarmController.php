<?php
declare(strict_types=1);

class AlarmController
{
    private const VALID_TYPES  = ['', 'motion', 'person', 'vehicle', 'face', 'tamper'];
    private const VALID_SOUNDS = ['none', 'beep', 'double_beep', 'siren', 'voice'];

    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $rules = $this->db->all('alarm_rules');
        if ($user['role'] !== 'superadmin') {
            $camIds = array_column($this->db->where('cameras', ['customer_id' => $user['customer_id']]), 'id');
            $rules  = array_values(array_filter(
                $rules,
                fn($r) => (int)$r['camera_id'] === 0 || in_array((int)$r['camera_id'], $camIds)
            ));
        }
        Response::json(array_map([$this, 'format'], $rules));
    }

    public function store(array $user): void
    {
        $b    = Response::body();
        $type = $b['eventType'] ?? '';
        if (!in_array($type, self::VALID_TYPES, true)) Response::abort(400, 'Geçersiz olay türü');

        $sound = $b['sound'] ?? 'beep';
        if (!in_array($sound, self::VALID_SOUNDS, true)) $sound = 'beep';

        $rule = $this->db->insert('alarm_rules', [
            'name'             => trim($b['name'] ?? 'Alarm Kuralı'),
            'camera_id'        => (int)($b['cameraId'] ?? 0),
            'event_type'       => $type,
            'enabled'          => isset($b['enabled']) ? (bool)$b['enabled'] : true,
            'sound'            => $sound,
            'cooldown_seconds' => max(0, (int)($b['cooldownSeconds'] ?? 60)),
        ]);
        Response::json($this->format($rule), 201);
    }

    public function update(array $user, int $id): void
    {
        $rule = $this->db->find('alarm_rules', $id);
        if (!$rule) Response::abort(404, 'Alarm kuralı bulunamadı');

        $b       = Response::body();
        $changes = [];
        if (array_key_exists('name', $b))             $changes['name']             = trim($b['name']);
        if (array_key_exists('cameraId', $b))          $changes['camera_id']        = (int)$b['cameraId'];
        if (array_key_exists('eventType', $b))         $changes['event_type']       = $b['eventType'];
        if (array_key_exists('enabled', $b))           $changes['enabled']          = (bool)$b['enabled'];
        if (array_key_exists('sound', $b))             $changes['sound']            = in_array($b['sound'], self::VALID_SOUNDS, true) ? $b['sound'] : 'beep';
        if (array_key_exists('cooldownSeconds', $b))   $changes['cooldown_seconds'] = max(0, (int)$b['cooldownSeconds']);

        $updated = $this->db->update('alarm_rules', $id, $changes);
        Response::json($this->format($updated));
    }

    public function destroy(array $user, int $id): void
    {
        $rule = $this->db->find('alarm_rules', $id);
        if (!$rule) Response::abort(404, 'Alarm kuralı bulunamadı');
        $this->db->delete('alarm_rules', $id);
        Response::json(['ok' => true]);
    }

    private function format(array $r): array
    {
        return [
            'id'              => (int)$r['id'],
            'name'            => $r['name'] ?? 'Alarm Kuralı',
            'cameraId'        => (int)$r['camera_id'],
            'eventType'       => $r['event_type'] ?? '',
            'enabled'         => (bool)$r['enabled'],
            'sound'           => $r['sound'] ?? 'beep',
            'cooldownSeconds' => (int)($r['cooldown_seconds'] ?? 60),
            'createdAt'       => $r['created_at'],
        ];
    }
}
