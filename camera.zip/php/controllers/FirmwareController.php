<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/OpenIpc.php';

class FirmwareController
{
    public function __construct(private Database $db, private Auth $auth) {}

    // ── Desteklenen SoC listesi ───────────────────────────────────────────────

    public function socList(array $user): void
    {
        $list = [];
        foreach (OpenIpc::SUPPORTED_SOC as $id => $soc) {
            $list[] = [
                'id'      => $id,
                'name'    => $soc['name'],
                'sensors' => $soc['sensors'],
                'flash'   => $soc['flash'],
                'notes'   => $soc['notes'] ?? null,
            ];
        }
        Response::json($list);
    }

    // ── U-Boot flash komutları üret ───────────────────────────────────────────

    public function flashCommands(array $user): void
    {
        $b       = Response::body();
        $socId   = $b['soc']      ?? '';
        $serverIp= $b['serverIp'] ?? '192.168.1.100';
        $camIp   = $b['cameraIp'] ?? '192.168.1.200';
        $manual  = (bool)($b['manual'] ?? false);

        if (!isset(OpenIpc::SUPPORTED_SOC[$socId])) {
            Response::abort(400, "Desteklenmeyen SoC: $socId");
        }

        $soc  = OpenIpc::SUPPORTED_SOC[$socId];
        $key  = ($manual && isset($soc['uboot_cmds_manual'])) ? 'uboot_cmds_manual' : 'uboot_cmds';
        $cmds = $soc[$key] ?? $soc['uboot_cmds'];

        $rendered = array_map(fn($cmd) => str_replace(
            ['{serverip}', '{ipaddr}'],
            [$serverIp,    $camIp],
            $cmd
        ), $cmds);

        // Firmware dosya adları
        $files = [];
        if (isset($soc['files'])) {
            foreach ($soc['files'] as $type => $tpl) {
                $files[$type] = str_replace('{flash}', $soc['flash'], $tpl);
            }
        } else {
            $files['uboot']  = "openipc.{$socId}-br.{$soc['flash']}.uboot";
            $files['rootfs'] = "openipc.{$socId}-br.{$soc['flash']}.tgz";
        }

        // İndirme linkleri
        $base = $soc['url_base'] ?? 'https://github.com/OpenIPC/firmware/releases/download/latest';
        $downloads = [];
        foreach ($files as $type => $fname) {
            $downloads[$type] = "$base/$fname";
        }

        Response::json([
            'soc'       => ['id' => $socId] + $soc,
            'commands'  => $rendered,
            'files'     => $files,
            'downloads' => $downloads,
            'tftp'      => [
                'serverIp'   => $serverIp,
                'cameraIp'   => $camIp,
                'directory'  => '/var/lib/tftpboot/',
                'instruction'=> "Firmware dosyalarını $serverIp:/var/lib/tftpboot/ dizinine kopyalayın",
            ],
        ]);
    }

    // ── Kamera erişilebilirlik kontrolü ──────────────────────────────────────

    public function checkAccess(array $user): void
    {
        $b    = Response::body();
        $ip   = $b['ip']   ?? '';
        $pass = $b['pass'] ?? OpenIpc::DEFAULT_PASS;
        $port = (int)($b['port'] ?? OpenIpc::DEFAULT_SSH);

        if (!$ip) Response::abort(400, 'IP adresi gerekli');

        $oipc    = new OpenIpc($ip, $port, OpenIpc::DEFAULT_USER, $pass);
        $reachable = $oipc->isReachable(3);

        if (!$reachable) {
            Response::json(['reachable' => false, 'message' => 'SSH portuna ulaşılamıyor']);
            return;
        }

        $info = $oipc->getSystemInfo();
        Response::json([
            'reachable' => true,
            'info'      => $info,
            'rtspUrl'   => $oipc->getRtspUrl(0),
        ]);
    }

    // ── Otomatik yapılandırma (flash sonrası) ─────────────────────────────────

    public function autoSetup(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin');
        $b = Response::body();

        $ip      = $b['ip']   ?? '';
        $pass    = $b['currentPass'] ?? OpenIpc::DEFAULT_PASS;
        $port    = (int)($b['sshPort'] ?? OpenIpc::DEFAULT_SSH);

        if (!$ip) Response::abort(400, 'IP adresi gerekli');

        $oipc = new OpenIpc($ip, $port, OpenIpc::DEFAULT_USER, $pass);
        if (!$oipc->isReachable(5)) {
            Response::abort(503, 'Kameraya SSH ile bağlanılamıyor');
        }

        $results = $oipc->autoSetup([
            'hostname'     => $b['hostname']    ?? null,
            'static_ip'    => $b['staticIp']    ?? null,
            'netmask'      => $b['netmask']      ?? '255.255.255.0',
            'gateway'      => $b['gateway']      ?? null,
            'new_password' => $b['newPassword']  ?? null,
            'bitrate'      => $b['bitrate']      ?? 2048,
            'fps'          => $b['fps']          ?? 20,
            'codec'        => $b['codec']        ?? 'h264',
            'ntp_server'   => $b['ntpServer']    ?? 'pool.ntp.org',
        ]);

        // Başarılı yapılandırma sonrası kamerayı panele ekle (opsiyonel)
        $cameraId = null;
        if (!empty($b['addToPanel']) && !empty($b['cameraName'])) {
            $finalIp   = $b['staticIp'] ?? $ip;
            $finalPass = $b['newPassword'] ?? $pass;

            $camera = $this->db->insert('cameras', [
                'customer_id'        => $user['customer_id'] ?? null,
                'name'               => $b['cameraName'],
                'ip'                 => $finalIp,
                'onvif_port'         => 80,
                'rtsp_port'          => OpenIpc::RTSP_PORT,
                'username'           => OpenIpc::DEFAULT_USER,
                'password_encrypted' => base64_encode($finalPass),
                'rtsp_url'           => (new OpenIpc($finalIp, $port, OpenIpc::DEFAULT_USER, $finalPass))->getRtspUrl(),
                'stream_path'        => '/stream0',
                'ptz_enabled'        => (bool)($b['ptzEnabled'] ?? false),
                'recording_enabled'  => true,
                'status'             => 'online',
                'location'           => $b['location'] ?? null,
            ]);
            $cameraId = $camera['id'];
        }

        Response::json([
            'success'  => true,
            'results'  => $results,
            'cameraId' => $cameraId,
            'rtspUrl'  => $oipc->getRtspUrl(),
        ]);
    }

    // ── Canlı Majestic config oku / yaz ──────────────────────────────────────

    public function getMajesticConfig(array $user): void
    {
        $b    = Response::body();
        $ip   = $b['ip']   ?? '';
        $pass = $b['pass'] ?? OpenIpc::DEFAULT_PASS;
        if (!$ip) Response::abort(400, 'IP gerekli');

        $oipc   = new OpenIpc($ip, OpenIpc::DEFAULT_SSH, OpenIpc::DEFAULT_USER, $pass);
        $config = $oipc->getMajesticConfig();
        Response::json($config);
    }

    public function setMajesticValue(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin');
        $b = Response::body();

        $oipc = new OpenIpc($b['ip'], OpenIpc::DEFAULT_SSH, OpenIpc::DEFAULT_USER, $b['pass'] ?? OpenIpc::DEFAULT_PASS);
        $ok   = $oipc->setMajesticValue($b['section'], $b['key'], $b['value']);
        Response::json(['success' => $ok]);
    }

    // ── Firmware sürüm kontrolü ───────────────────────────────────────────────

    public function checkFirmwareVersion(array $user): void
    {
        $b    = Response::body();
        $ip   = $b['ip']   ?? '';
        $pass = $b['pass'] ?? OpenIpc::DEFAULT_PASS;
        if (!$ip) Response::abort(400, 'IP gerekli');

        $oipc    = new OpenIpc($ip, OpenIpc::DEFAULT_SSH, OpenIpc::DEFAULT_USER, $pass);
        $version = $oipc->getFirmwareVersion();

        Response::json([
            'ip'      => $ip,
            'version' => $version,
            'isOpenIpc' => str_contains(strtolower($version), 'openipc'),
        ]);
    }

    // ── Firmware güncelle ─────────────────────────────────────────────────────

    public function updateFirmware(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin');
        $b = Response::body();

        $oipc   = new OpenIpc($b['ip'], OpenIpc::DEFAULT_SSH, OpenIpc::DEFAULT_USER, $b['pass'] ?? OpenIpc::DEFAULT_PASS);
        $result = $oipc->updateFirmware();
        Response::json($result);
    }
}
