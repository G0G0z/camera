<?php
declare(strict_types=1);

/**
 * Kamera provizyon sistemi.
 *
 * Akış:
 *  1. Kullanıcı panelde WiFi bilgisi + kamera adı girer → generate()
 *     → benzersiz token + QR payload döner
 *  2. Kullanıcı QR'ı kameranın önüne tutar
 *  3. Kamera QR'ı okur, WiFi'ye bağlanır → register() çağırır
 *  4. Panel token'ı doğrular → kamera kaydını oluşturur
 *  5. Frontend status() endpoint'ini poll eder → yönlendirme yapar
 */
class ProvisionController
{
    private const TOKEN_TTL = 3600; // 1 saat
    private const TABLE     = 'provision_tokens';

    public function __construct(private Database $db, private Auth $auth) {}

    // ── 1. QR payload + token üret ────────────────────────────────────────────

    public function generate(array $user): void
    {
        $b = Response::body();

        $ssid     = trim($b['ssid'] ?? '');
        $password = $b['password'] ?? '';
        $security = strtoupper($b['security'] ?? 'WPA');
        $name     = trim($b['name'] ?? 'Kamera');
        $location = trim($b['location'] ?? '');

        if (!$ssid) Response::abort(400, 'WiFi SSID gerekli');
        if (!$name) Response::abort(400, 'Kamera adı gerekli');

        // Süresi dolmuş tokenları temizle
        $this->cleanup();

        // Benzersiz token
        $token = bin2hex(random_bytes(16));

        // Panel URL'sini otomatik algıla
        $panelUrl = $this->detectPanelUrl();

        // QR payload — kamera bu JSON'u okuyacak
        $payload = json_encode([
            'p' => $panelUrl,    // panel URL
            't' => $token,       // provision token
            's' => $ssid,        // WiFi SSID
            'k' => $password,    // WiFi şifre
            'e' => $security,    // güvenlik tipi
            'n' => $name,        // kamera adı
            'l' => $location,    // konum (opsiyonel)
        ], JSON_UNESCAPED_UNICODE);

        // Token kaydını sakla
        $this->db->insert(self::TABLE, [
            'token'       => $token,
            'user_id'     => $user['id'],
            'customer_id' => $user['customer_id'] ?? null,
            'camera_name' => $name,
            'location'    => $location,
            'ssid'        => $ssid,
            'status'      => 'pending',   // pending → connected
            'camera_id'   => null,
            'expires_at'  => date('c', time() + self::TOKEN_TTL),
        ]);

        Response::json([
            'token'      => $token,
            'qrPayload'  => $payload,
            'expiresAt'  => date('c', time() + self::TOKEN_TTL),
            'panelUrl'   => $panelUrl,
        ], 201);
    }

    // ── 2. Kamera bu endpoint'i çağırarak kendini kaydeder ───────────────────

    public function register(): void
    {
        $b     = Response::body();
        $token = trim($b['token'] ?? '');
        $ip    = trim($b['ip']    ?? ($_SERVER['REMOTE_ADDR'] ?? ''));
        $mac   = trim($b['mac']   ?? '');
        $fw    = trim($b['firmware'] ?? '');

        if (!$token) Response::abort(400, 'Token gerekli');

        $record = $this->db->findBy(self::TABLE, 'token', $token);

        if (!$record) {
            Response::abort(404, 'Geçersiz veya süresi dolmuş token');
        }

        if ($record['status'] === 'connected') {
            // Zaten bağlı — mevcut kamera bilgisini döndür
            $camera = $record['camera_id']
                ? $this->db->find('cameras', (int)$record['camera_id'])
                : null;
            Response::json([
                'ok'         => true,
                'alreadyReg' => true,
                'cameraId'   => $record['camera_id'],
                'cameraToken'=> $camera['camera_token'] ?? null,
            ]);
            return;
        }

        if (strtotime($record['expires_at']) < time()) {
            Response::abort(410, 'Token süresi dolmuş — panelden yeni QR oluşturun');
        }

        // Kamera kaydını oluştur
        $cameraToken = bin2hex(random_bytes(20)); // kalıcı kamera token'ı

        $camera = $this->db->insert('cameras', [
            'customer_id'        => $record['customer_id'],
            'name'               => $record['camera_name'],
            'ip'                 => $ip,
            'mac'                => $mac,
            'onvif_port'         => 80,
            'rtsp_port'          => 554,
            'username'           => 'root',
            'password_encrypted' => null,
            'rtsp_url'           => $ip ? "rtsp://root@{$ip}:554/stream0" : null,
            'stream_path'        => '/stream0',
            'ptz_enabled'        => false,
            'recording_enabled'  => true,
            'status'             => 'online',
            'last_seen'          => date('c'),
            'location'           => $record['location'],
            'firmware'           => $fw,
            'camera_token'       => $cameraToken,
        ]);

        // Token kaydını güncelle
        $this->db->update(self::TABLE, (int)$record['id'], [
            'status'     => 'connected',
            'camera_id'  => $camera['id'],
            'connected_at'=> date('c'),
            'camera_ip'  => $ip,
            'camera_mac' => $mac,
        ]);

        Response::json([
            'ok'          => true,
            'cameraId'    => $camera['id'],
            'cameraToken' => $cameraToken,  // kamera bu token'ı kaydeder, heartbeat için kullanır
            'panelUrl'    => $this->detectPanelUrl(),
        ], 201);
    }

    // ── 3. Frontend bu endpoint'i poll eder ─────────────────────────────────

    public function status(array $user, string $token): void
    {
        $record = $this->db->findBy(self::TABLE, 'token', $token);

        if (!$record) {
            Response::abort(404, 'Token bulunamadı');
        }

        // Sahiplik kontrolü
        if ((int)$record['user_id'] !== (int)$user['id'] && $user['role'] !== 'superadmin') {
            Response::abort(403, 'Erişim izni yok');
        }

        $expired = strtotime($record['expires_at']) < time();

        Response::json([
            'status'      => $expired && $record['status'] === 'pending' ? 'expired' : $record['status'],
            'cameraId'    => $record['camera_id'] ? (int)$record['camera_id'] : null,
            'cameraName'  => $record['camera_name'],
            'connectedAt' => $record['connected_at'] ?? null,
            'cameraIp'    => $record['camera_ip'] ?? null,
            'expiresAt'   => $record['expires_at'],
        ]);
    }

    // ── Kullanıcının kendi tokenlarını listele ─────────────────────────────

    public function list(array $user): void
    {
        $tokens = $user['role'] === 'superadmin'
            ? $this->db->all(self::TABLE)
            : $this->db->where(self::TABLE, ['user_id' => $user['id']]);

        // Yeniden eskiye sırala
        usort($tokens, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));

        Response::json(array_map(fn($t) => [
            'token'      => $t['token'],
            'cameraName' => $t['camera_name'],
            'location'   => $t['location'] ?? null,
            'ssid'       => $t['ssid'],
            'status'     => strtotime($t['expires_at']) < time() && $t['status'] === 'pending' ? 'expired' : $t['status'],
            'cameraId'   => $t['camera_id'] ? (int)$t['camera_id'] : null,
            'connectedAt'=> $t['connected_at'] ?? null,
            'expiresAt'  => $t['expires_at'],
            'createdAt'  => $t['created_at'],
        ], array_values($tokens)));
    }

    // ── Bekleyen tokenı iptal et ──────────────────────────────────────────

    public function cancel(array $user, string $token): void
    {
        $record = $this->db->findBy(self::TABLE, 'token', $token);
        if (!$record) Response::abort(404, 'Token bulunamadı');
        if ((int)$record['user_id'] !== (int)$user['id'] && $user['role'] !== 'superadmin') {
            Response::abort(403, 'Erişim izni yok');
        }
        $this->db->delete(self::TABLE, (int)$record['id']);
        Response::noContent();
    }

    // ── Yardımcılar ──────────────────────────────────────────────────────────

    private function cleanup(): void
    {
        $all     = $this->db->all(self::TABLE);
        $now     = time();
        $removed = 0;
        foreach ($all as $r) {
            if (strtotime($r['expires_at']) < $now && $r['status'] === 'pending') {
                $this->db->delete(self::TABLE, (int)$r['id']);
                $removed++;
            }
        }
    }

    private function detectPanelUrl(): string
    {
        if (defined('PANEL_URL') && PANEL_URL) return rtrim(PANEL_URL, '/');

        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return $scheme . '://' . $host;
    }
}
