<?php
declare(strict_types=1);

class DashboardController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function stats(array $user): void
    {
        $isSuperadmin = $user['role'] === 'superadmin';

        // ── Tek seferlik toplu yükleme (N×M döngülerden kaçın) ───────────────
        $allCameras   = $this->db->all('cameras');
        $allRecs      = $this->db->all('recordings');
        $allEvents    = $this->db->all('camera_events');
        $allCustomers = $isSuperadmin ? $this->db->all('customers') : [];

        // Kamera lookup: id → camera row
        $cameraMap = [];
        foreach ($allCameras as $c) $cameraMap[(int)$c['id']] = $c;

        // Müşteri lookup: id → customer row
        $customerMap = [];
        foreach ($allCustomers as $c) $customerMap[(int)$c['id']] = $c;

        // Bu kullanıcının görebileceği kamera ID seti
        if ($isSuperadmin) {
            $visibleCamIds = array_keys($cameraMap);
        } else {
            $custId = (int)($user['customer_id'] ?? 0);
            $visibleCamIds = array_keys(array_filter($cameraMap,
                fn($c) => (int)($c['customer_id'] ?? 0) === $custId
            ));
        }
        $visibleSet = array_flip($visibleCamIds);

        // Görünür kameralar
        $cameras = array_values(array_intersect_key($cameraMap, $visibleSet));

        // Kayıtlar (görünür)
        $recordings = array_values(array_filter($allRecs,
            fn($r) => isset($visibleSet[(int)$r['camera_id']])
        ));

        // Olaylar (görünür)
        $events = array_values(array_filter($allEvents,
            fn($e) => isset($visibleSet[(int)$e['camera_id']])
        ));

        $today       = date('Y-m-d');
        $todayEvents = array_filter($events, fn($e) => str_starts_with($e['timestamp'] ?? '', $today));

        $todayByType = [];
        foreach ($todayEvents as $e) {
            $t = $e['type'] ?? 'unknown';
            $todayByType[$t] = ($todayByType[$t] ?? 0) + 1;
        }

        // ── Depolama toplamları (tek geçişte) ────────────────────────────────
        // Müşteri başına, kamera başına kullanım
        // cameraStorageUsed[camId] => bytes
        $cameraStorageUsed = [];
        foreach ($allRecs as $r) {
            $camId = (int)$r['camera_id'];
            if ($r['status'] === 'completed' && !empty($r['file_size'])) {
                $cameraStorageUsed[$camId] = ($cameraStorageUsed[$camId] ?? 0) + (int)$r['file_size'];
            }
        }

        // ── Müşteri tablosu (superadmin) ─────────────────────────────────────
        $customerRows  = [];
        $totalUsed     = 0;
        $totalLimit    = 0;

        if ($isSuperadmin) {
            // Müşteri başına kamera listesi (tek geçiş)
            $camsByCustomer = [];
            foreach ($allCameras as $c) {
                $cid = (int)($c['customer_id'] ?? 0);
                $camsByCustomer[$cid][] = $c;
            }

            // Aktif kayıt sayısı kamera başına
            $activeRecByCam = [];
            foreach ($allRecs as $r) {
                if ($r['status'] === 'recording') {
                    $activeRecByCam[(int)$r['camera_id']] = true;
                }
            }

            foreach ($allCustomers as $cust) {
                $custId    = (int)$cust['id'];
                $custCams  = $camsByCustomer[$custId] ?? [];
                $limitGb   = (int)($cust['storage_limit_gb_per_camera'] ?? 10);
                $limitBytes = $limitGb * 1024 * 1024 * 1024;
                $camCount  = count($custCams);

                $usedBytes   = 0;
                $onlineCams  = 0;
                $activeRecs  = 0;
                foreach ($custCams as $cam) {
                    $camId = (int)$cam['id'];
                    $usedBytes  += $cameraStorageUsed[$camId] ?? 0;
                    if (($cam['status'] ?? '') === 'online') $onlineCams++;
                    if (isset($activeRecByCam[$camId])) $activeRecs++;
                }

                $custLimitTotal = $limitBytes * max(1, $camCount);
                $totalUsed     += $usedBytes;
                $totalLimit    += $custLimitTotal;

                $customerRows[] = [
                    'id'               => $custId,
                    'name'             => $cust['name'],
                    'email'            => $cust['email'] ?? null,
                    'cameraCount'      => $camCount,
                    'onlineCameras'    => $onlineCams,
                    'activeRecordings' => $activeRecs,
                    'limitGbPerCam'    => $limitGb,
                    'limitBytesTotal'  => $custLimitTotal,
                    'usedBytes'        => $usedBytes,
                    'usedPercent'      => $custLimitTotal > 0
                        ? min(100, round($usedBytes / $custLimitTotal * 100, 1))
                        : 0,
                    'createdAt'        => $cust['created_at'],
                ];
            }
        }

        // Son 10 olay — cameraMap kullanarak N DB çağrısından kaçın
        $recentEvents = array_slice(array_reverse($events), 0, 10);

        Response::json([
            'totalCameras'      => count($cameras),
            'onlineCameras'     => count(array_filter($cameras, fn($c) => ($c['status'] ?? '') === 'online')),
            'offlineCameras'    => count(array_filter($cameras, fn($c) => ($c['status'] ?? '') === 'offline')),
            'unknownCameras'    => count(array_filter($cameras, fn($c) => ($c['status'] ?? 'unknown') === 'unknown')),
            'activeRecordings'  => count(array_filter($recordings, fn($r) => $r['status'] === 'recording')),
            'totalRecordings'   => count($recordings),
            'todayEvents'       => count($todayEvents),
            'todayEventsByType' => $todayByType,
            'totalUsedBytes'    => $totalUsed,
            'totalLimitBytes'   => $totalLimit,
            'customers'         => $isSuperadmin ? count($allCustomers) : 1,
            'users'             => $isSuperadmin
                ? count($this->db->all('users'))
                : count($this->db->where('users', ['customer_id' => $user['customer_id']])),
            'customerRows'      => $customerRows,
            'recentEvents'      => array_map(fn($e) => [
                'id'          => (int)$e['id'],
                'cameraId'    => (int)$e['camera_id'],
                'cameraName'  => $cameraMap[(int)$e['camera_id']]['name'] ?? null,
                'type'        => $e['type'],
                'confidence'  => isset($e['confidence']) ? (float)$e['confidence'] : null,
                'snapshotUrl' => $e['snapshot_url'] ?? null,
                'timestamp'   => $e['timestamp'],
            ], $recentEvents),
        ]);
    }
}
