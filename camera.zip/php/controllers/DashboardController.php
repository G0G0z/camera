<?php
declare(strict_types=1);

class DashboardController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function stats(array $user): void
    {
        $isSuperadmin = $user['role'] === 'superadmin';

        $cameras = $isSuperadmin
            ? $this->db->all('cameras')
            : $this->db->where('cameras', ['customer_id' => $user['customer_id']]);

        $cameraIds = array_map(fn($c) => (int)$c['id'], $cameras);

        $allRecordings = $this->db->all('recordings');
        $recordings    = array_filter($allRecordings, fn($r) => in_array((int)$r['camera_id'], $cameraIds));

        $allEvents = $this->db->all('camera_events');
        $events    = array_filter($allEvents, fn($e) => in_array((int)$e['camera_id'], $cameraIds));

        $today       = date('Y-m-d');
        $todayEvents = array_filter($events, fn($e) => str_starts_with($e['timestamp'] ?? '', $today));

        // Olay türlerine göre bugünkü sayı
        $todayByType = [];
        foreach ($todayEvents as $e) {
            $t = $e['type'] ?? 'unknown';
            $todayByType[$t] = ($todayByType[$t] ?? 0) + 1;
        }

        // Son 10 olay (en yeni önce)
        $recentEvents = array_slice(array_reverse(array_values($events)), 0, 10);

        Response::json([
            'totalCameras'     => count($cameras),
            'onlineCameras'    => count(array_filter($cameras, fn($c) => ($c['status'] ?? '') === 'online')),
            'offlineCameras'   => count(array_filter($cameras, fn($c) => ($c['status'] ?? '') === 'offline')),
            'unknownCameras'   => count(array_filter($cameras, fn($c) => ($c['status'] ?? 'unknown') === 'unknown')),
            'activeRecordings' => count(array_filter($recordings, fn($r) => $r['status'] === 'recording')),
            'totalRecordings'  => count($recordings),
            'todayEvents'      => count($todayEvents),
            'todayEventsByType'=> $todayByType,
            'customers'        => $isSuperadmin
                ? count($this->db->all('customers'))
                : 1,
            'users'            => $isSuperadmin
                ? count($this->db->all('users'))
                : count($this->db->where('users', ['customer_id' => $user['customer_id']])),
            'recentEvents'     => array_map(
                fn($e) => [
                    'id'          => (int)$e['id'],
                    'cameraId'    => (int)$e['camera_id'],
                    'cameraName'  => $this->db->find('cameras', (int)$e['camera_id'])['name'] ?? null,
                    'type'        => $e['type'],
                    'confidence'  => isset($e['confidence']) ? (float)$e['confidence'] : null,
                    'snapshotUrl' => $e['snapshot_url'] ?? null,
                    'timestamp'   => $e['timestamp'],
                ],
                $recentEvents
            ),
        ]);
    }
}
