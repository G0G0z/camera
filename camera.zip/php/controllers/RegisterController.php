<?php
declare(strict_types=1);

class RegisterController
{
    public function __construct(private Database $db, private Auth $auth) {}

    // ── Yeni müşteri + admin kullanıcı kaydı ─────────────────────────────────
    public function register(): void
    {
        $b = Response::body();

        $companyName = trim($b['companyName'] ?? '');
        $email       = strtolower(trim($b['email'] ?? ''));
        $name        = trim($b['name'] ?? '');
        $password    = $b['password'] ?? '';
        $phone       = trim($b['phone'] ?? '');

        // Doğrulama
        if (!$companyName) Response::abort(400, 'Şirket adı gerekli');
        if (!$email)       Response::abort(400, 'E-posta gerekli');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) Response::abort(400, 'Geçersiz e-posta');
        if (strlen($password) < 6) Response::abort(400, 'Şifre en az 6 karakter olmalı');
        if ($this->db->findBy('users', 'email', $email)) {
            Response::abort(409, 'Bu e-posta zaten kayıtlı');
        }

        // Müşteri oluştur
        $customer = $this->db->insert('customers', [
            'name'  => $companyName,
            'email' => $email,
            'phone' => $phone ?: null,
        ]);

        // Admin kullanıcı oluştur
        $user = $this->db->insert('users', [
            'email'         => $email,
            'name'          => $name ?: $companyName,
            'password_hash' => $this->auth->hashPassword($password),
            'role'          => 'admin',
            'customer_id'   => $customer['id'],
        ]);

        // Otomatik giriş
        $token = $this->auth->createToken(['sub' => $user['id'], 'role' => $user['role']]);

        Response::json([
            'token' => $token,
            'user'  => [
                'id'         => $user['id'],
                'email'      => $user['email'],
                'name'       => $user['name'],
                'role'       => $user['role'],
                'customerId' => $user['customer_id'],
            ],
            'customer' => [
                'id'   => $customer['id'],
                'name' => $customer['name'],
            ],
        ], 201);
    }

    // ── Profil güncelle ───────────────────────────────────────────────────────
    public function updateProfile(array $user): void
    {
        $b = Response::body();
        $changes = [];

        if (!empty($b['name'])) {
            $changes['name'] = trim($b['name']);
        }

        if (!empty($b['email'])) {
            $email = strtolower(trim($b['email']));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) Response::abort(400, 'Geçersiz e-posta');
            $existing = $this->db->findBy('users', 'email', $email);
            if ($existing && (int)$existing['id'] !== (int)$user['id']) {
                Response::abort(409, 'Bu e-posta başka bir hesaba kayıtlı');
            }
            $changes['email'] = $email;
        }

        if (empty($changes)) Response::abort(400, 'Güncellenecek alan yok');

        $updated = $this->db->update('users', (int)$user['id'], $changes);
        unset($updated['password_hash']);

        Response::json([
            'id'         => $updated['id'],
            'email'      => $updated['email'],
            'name'       => $updated['name'] ?? null,
            'role'       => $updated['role'],
            'customerId' => $updated['customer_id'] ?? null,
        ]);
    }

    // ── Şifre değiştir ────────────────────────────────────────────────────────
    public function changePassword(array $user): void
    {
        $b           = Response::body();
        $currentPass = $b['currentPassword'] ?? '';
        $newPass     = $b['newPassword'] ?? '';

        if (!$currentPass) Response::abort(400, 'Mevcut şifre gerekli');
        if (strlen($newPass) < 6) Response::abort(400, 'Yeni şifre en az 6 karakter olmalı');

        $dbUser = $this->db->find('users', (int)$user['id']);
        if (!$this->auth->verifyPassword($currentPass, $dbUser['password_hash'])) {
            Response::abort(401, 'Mevcut şifre hatalı');
        }

        $this->db->update('users', (int)$user['id'], [
            'password_hash' => $this->auth->hashPassword($newPass),
        ]);

        Response::json(['success' => true, 'message' => 'Şifre başarıyla güncellendi']);
    }

    // ── Hesabı sil ────────────────────────────────────────────────────────────
    public function deleteAccount(array $user): void
    {
        $b    = Response::body();
        $pass = $b['password'] ?? '';

        $dbUser = $this->db->find('users', (int)$user['id']);
        if (!$this->auth->verifyPassword($pass, $dbUser['password_hash'])) {
            Response::abort(401, 'Şifre hatalı');
        }

        // Kullanıcıyı sil (superadmin silemez)
        if ($user['role'] === 'superadmin') {
            Response::abort(403, 'Superadmin hesabı silinemez');
        }

        $this->db->delete('users', (int)$user['id']);
        Response::json(['success' => true]);
    }
}
