<?php
declare(strict_types=1);

class CameraController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $customerId = Response::query('customerId');

        if ($user['role'] === 'superadmin') {
            $cameras = $customerId
                ? $this->db->where('cameras', ['customer_id' => (int)$customerId])
                : $this->db->all('cameras');
        } else {
            $cameras = $this->db->where('cameras', ['customer_id' => $user['customer_id']]);
        }

        Response::json(array_map([$this, 'format'], $cameras));
    }

    public function store(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $b = Response::body();

        $camera = $this->db->insert('cameras', [
            'customer_id'        => isset($b['customerId']) ? (int)$b['customerId'] : ($user['customer_id'] ?? null),
            'name'               => $b['name'] ?? 'Kamera',
            'ip'                 => $b['ip'] ?? '',
            'onvif_port'         => (int)($b['onvifPort'] ?? 80),
            'rtsp_port'          => (int)($b['rtspPort'] ?? 554),
            'username'           => $b['username'] ?? null,
            'password_encrypted' => isset($b['password']) ? base64_encode($b['password']) : null,
            'rtsp_url'           => $b['rtspUrl'] ?? null,
            'stream_path'        => $b['streamPath'] ?? '/stream0',
            'ptz_enabled'        => (bool)($b['ptzEnabled'] ?? false),
            'recording_enabled'  => (bool)($b['recordingEnabled'] ?? false),
            'status'             => 'unknown',
            'location'           => $b['location'] ?? null,
        ]);

        Response::json($this->format($camera), 201);
    }

    public function show(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);
        Response::json($this->format($camera));
    }

    public function update(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $this->findAuthorized($user, $id);
        $b = Response::body();

        $changes = array_filter([
            'name'               => $b['name'] ?? null,
            'ip'                 => $b['ip'] ?? null,
            'onvif_port'         => isset($b['onvifPort']) ? (int)$b['onvifPort'] : null,
            'rtsp_port'          => isset($b['rtspPort']) ? (int)$b['rtspPort'] : null,
            'username'           => $b['username'] ?? null,
            'password_encrypted' => isset($b['password']) ? base64_encode($b['password']) : null,
            'rtsp_url'           => $b['rtspUrl'] ?? null,
            'stream_path'        => $b['streamPath'] ?? null,
            'ptz_enabled'        => isset($b['ptzEnabled']) ? (bool)$b['ptzEnabled'] : null,
            'recording_enabled'  => isset($b['recordingEnabled']) ? (bool)$b['recordingEnabled'] : null,
            'location'           => $b['location'] ?? null,
            'customer_id'        => isset($b['customerId']) ? (int)$b['customerId'] : null,
        ], fn($v) => $v !== null);

        $camera = $this->db->update('cameras', $id, $changes);
        Response::json($this->format($camera));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $this->findAuthorized($user, $id);
        $this->db->delete('cameras', $id);
        $this->db->deleteWhere('ptz_presets', 'camera_id', $id);
        Response::noContent();
    }

    public function status(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);

        $online = $this->pingCamera($camera['ip'], (int)($camera['onvif_port'] ?? 80));
        $status = $online ? 'online' : 'offline';

        $this->db->update('cameras', $id, [
            'status'      => $status,
            'last_seen'   => $online ? date('c') : null,
        ]);

        Response::json([
            'id'        => $id,
            'status'    => $status,
            'checkedAt' => date('c'),
        ]);
    }

    /** Tüm erişilebilir kameraların durumunu tek seferde güncelle */
    public function statusAll(array $user): void
    {
        $cameras = $user['role'] === 'superadmin'
            ? $this->db->all('cameras')
            : $this->db->where('cameras', ['customer_id' => $user['customer_id']]);

        $results = [];
        foreach ($cameras as $camera) {
            $online = $this->pingCamera($camera['ip'], (int)($camera['onvif_port'] ?? 80));
            $status = $online ? 'online' : 'offline';
            $this->db->update('cameras', (int)$camera['id'], [
                'status'    => $status,
                'last_seen' => $online ? date('c') : ($camera['last_seen'] ?? null),
            ]);
            $results[] = [
                'id'        => (int)$camera['id'],
                'status'    => $status,
                'checkedAt' => date('c'),
            ];
        }

        Response::json($results);
    }

    public function snapshot(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);

        $pass  = $camera['password_encrypted'] ? base64_decode($camera['password_encrypted']) : '';
        $uname = $camera['username'] ?? 'admin';
        $ip    = $camera['ip'];
        $port  = (int)($camera['onvif_port'] ?? 80);

        // 1) ONVIF ile snapshot URL'si al
        $onvif = new Onvif($ip, $port, $uname, $pass);
        $profiles    = $onvif->getProfiles();
        $snapshotUrl = null;

        if ($profiles && count($profiles) > 0) {
            $snapshotUrl = $onvif->getSnapshotUri($profiles[0]);
        }

        // 2) ONVIF başarısız olduysa bilinen URL kalıplarını dene
        if (!$snapshotUrl) {
            $snapshotUrl = $this->probeSnapshotUrl($ip, $port, $uname, $pass);
        }

        if (!$snapshotUrl) {
            Response::abort(503, 'Snapshot URL alınamadı — kamera erişilebilir değil veya ONVIF desteklenmiyor');
        }

        Response::json([
            'url'        => $snapshotUrl,
            'capturedAt' => date('c'),
        ]);
    }

    public function stream(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);

        // RTSP URL oluştur
        if ($camera['rtsp_url']) {
            $rtspUrl = $camera['rtsp_url'];
        } else {
            $uname = $camera['username'] ? urlencode($camera['username']) : '';
            $pass  = $camera['password_encrypted']
                ? ':' . urlencode(base64_decode($camera['password_encrypted']))
                : '';
            $auth    = $uname ? "{$uname}{$pass}@" : '';
            $path    = $camera['stream_path'] ?? '/stream0';
            $rtspUrl = "rtsp://{$auth}{$camera['ip']}:{$camera['rtsp_port']}{$path}";
        }

        // MediaMTX üzerinden HLS/WebRTC URL (yapılandırıldıysa)
        $streamName = "cam_{$id}";
        $hlsUrl     = MEDIAMTX_HLS    ? MEDIAMTX_HLS    . "/{$streamName}/index.m3u8" : null;
        $webrtcUrl  = MEDIAMTX_WEBRTC ? MEDIAMTX_WEBRTC . "/{$streamName}" : null;

        Response::json([
            'rtspUrl'   => $rtspUrl,
            'hlsUrl'    => $hlsUrl,
            'webrtcUrl' => $webrtcUrl,
        ]);
    }

    // ── Kamera heartbeat (ajandan gelen canlı bildir) ────────────────────────

    /**
     * Kamera ajanı periyodik olarak bu endpoint'i çağırır.
     * Token doğrulama: X-Camera-Token header veya ?token= query parametresi.
     * Kimlik doğrulama gerektirmez — token tek başına yeterli.
     */
    public function heartbeat(): void
    {
        $token = $this->resolveCameraToken();
        $camera = $this->findByToken($token);

        $b = Response::body();

        $this->db->update('cameras', (int)$camera['id'], [
            'status'    => 'online',
            'last_seen' => date('c'),
        ]);

        Response::json([
            'ok'       => true,
            'cameraId' => (int)$camera['id'],
            'ts'       => date('c'),
        ]);
    }

    // ── Majestic webhook alıcısı ─────────────────────────────────────────────

    /**
     * Kamera ajanı, Majestic streamer'dan gelen hareket/AI olaylarını
     * bu endpoint üzerinden panele iletir.
     * URL: POST /api/cameras/majestic-hook?token=<CAMERA_TOKEN>
     */
    public function majesticHook(): void
    {
        $token  = $this->resolveCameraToken();
        $camera = $this->findByToken($token);
        $b      = Response::body();

        // Majestic olay tipi → panel olay tipi eşlemesi
        $eventRaw = strtolower($b['event'] ?? $b['type'] ?? 'motion');
        $classRaw = strtolower($b['class'] ?? $b['object'] ?? '');

        $typeMap = [
            'md'      => 'motion',
            'motion'  => 'motion',
            'ai'      => match(true) {
                in_array($classRaw, ['person','human','pedestrian']) => 'person',
                in_array($classRaw, ['vehicle','car','truck','bus']) => 'vehicle',
                str_contains($classRaw, 'face')                      => 'face',
                default                                               => 'motion',
            },
            'person'  => 'person',
            'vehicle' => 'vehicle',
            'face'    => 'face',
            'tamper'  => 'tamper',
        ];

        $type       = $typeMap[$eventRaw] ?? 'motion';
        $confidence = isset($b['confidence']) ? (float)$b['confidence'] : null;
        $snapshot   = $b['snapshotUrl'] ?? $b['snapshot'] ?? null;

        // Kamerayı online işaretle
        $this->db->update('cameras', (int)$camera['id'], [
            'status'    => 'online',
            'last_seen' => date('c'),
        ]);

        // Olayı kaydet
        $event = $this->db->insert('camera_events', [
            'camera_id'    => (int)$camera['id'],
            'type'         => $type,
            'confidence'   => $confidence,
            'snapshot_url' => $snapshot,
            'metadata'     => json_encode($b),
            'timestamp'    => date('c'),
        ]);

        Response::json(['ok' => true, 'eventId' => (int)$event['id']], 201);
    }

    // ── Token tabanlı kamera doğrulama (heartbeat / hook için) ───────────────

    private function resolveCameraToken(): string
    {
        // Önce header, sonra query string
        $header = $_SERVER['HTTP_X_CAMERA_TOKEN'] ?? null;
        $query  = $_GET['token'] ?? null;
        $token  = $header ?: $query;

        if (!$token) {
            Response::abort(401, 'Kamera token gerekli (X-Camera-Token header veya ?token=)');
        }
        return $token;
    }

    private function findByToken(string $token): array
    {
        // cameras tablosunda camera_token sütunu var mı diye ara
        $cameras = $this->db->all('cameras');
        foreach ($cameras as $cam) {
            if (($cam['camera_token'] ?? '') === $token) {
                return $cam;
            }
        }
        // Token eşleşmesi yoksa CAMERA_PUSH_TOKEN sabiti ile karşılaştır
        if (defined('CAMERA_PUSH_TOKEN') && CAMERA_PUSH_TOKEN && $token === CAMERA_PUSH_TOKEN) {
            // Global token: ilk kamerayı döndürmek yerine IP bazlı eşleştir
            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            if ($ip) {
                foreach ($cameras as $cam) {
                    if ($cam['ip'] === $ip) return $cam;
                }
            }
            // IP eşleşmesi de yoksa 404
        }
        Response::abort(403, 'Geçersiz kamera token');
    }

    // ── Yardımcılar ──────────────────────────────────────────────────────────

    private function findAuthorized(array $user, int $id): array
    {
        $camera = $this->db->find('cameras', $id);
        if (!$camera) Response::abort(404, 'Kamera bulunamadı');

        if ($user['role'] !== 'superadmin' && $camera['customer_id'] != $user['customer_id']) {
            Response::abort(403, 'Erişim izni yok');
        }

        return $camera;
    }

    /**
     * Curl ile TCP bağlantı kontrolü (fsockopen yerine).
     * CURLE_COULDNT_CONNECT (7) → port kapalı; diğer hatalar porta ulaşıldı.
     */
    private function pingCamera(string $ip, int $port): bool
    {
        if (!function_exists('curl_init')) {
            return false;
        }
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => "http://{$ip}:{$port}",
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT        => 2,
            CURLOPT_NOBODY         => true,
            CURLOPT_RETURNTRANSFER => true,
        ]);
        curl_exec($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        return $errno !== CURLE_COULDNT_CONNECT;
    }

    /**
     * Farklı kamera markalarının bilinen snapshot URL kalıplarını dener.
     * OpenIPC, Hikvision, Dahua, generic HTTP kameralar.
     */
    private function probeSnapshotUrl(string $ip, int $port, string $user, string $pass): ?string
    {
        $candidates = [
            // OpenIPC / Majestic
            "http://{$ip}:{$port}/snapshot.jpg",
            // Hikvision
            "http://{$ip}:{$port}/ISAPI/Streaming/channels/101/picture",
            // Dahua
            "http://{$ip}:{$port}/cgi-bin/snapshot.cgi",
            // Generic
            "http://{$ip}:{$port}/image/jpeg.cgi",
            "http://{$ip}:{$port}/axis-cgi/jpg/image.cgi",
        ];

        foreach ($candidates as $url) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 3,
                CURLOPT_CONNECTTIMEOUT => 2,
                CURLOPT_NOBODY         => true,   // sadece HEAD kontrolü
                CURLOPT_USERPWD        => "{$user}:{$pass}",
                CURLOPT_HTTPAUTH       => CURLAUTH_ANY,
                CURLOPT_FOLLOWLOCATION => true,
            ]);
            curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($code === 200 || $code === 401) {
                // 401 → URL mevcut ama kimlik doğrulama gerekiyor — URL geçerli
                return $url;
            }
        }

        return null;
    }

    public function format(array $c): array
    {
        return [
            'id'               => (int)$c['id'],
            'customerId'       => isset($c['customer_id']) ? (int)$c['customer_id'] : null,
            'name'             => $c['name'],
            'ip'               => $c['ip'],
            'onvifPort'        => (int)($c['onvif_port'] ?? 80),
            'rtspPort'         => (int)($c['rtsp_port'] ?? 554),
            'username'         => $c['username'] ?? null,
            'rtspUrl'          => $c['rtsp_url'] ?? null,
            'streamPath'       => $c['stream_path'] ?? null,
            'ptzEnabled'       => (bool)($c['ptz_enabled'] ?? false),
            'recordingEnabled' => (bool)($c['recording_enabled'] ?? false),
            'status'           => $c['status'] ?? 'unknown',
            'location'         => $c['location'] ?? null,
            'lastSeen'         => $c['last_seen'] ?? null,
            'createdAt'        => $c['created_at'],
        ];
    }
}
