<?php
declare(strict_types=1);

class RecordingController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $cameraId = Response::query('cameraId');
        $status   = Response::query('status');
        $page     = max(1, (int)Response::query('page', 1));
        $limit    = min(100, max(1, (int)Response::query('limit', 20)));

        $all = $this->db->all('recordings');

        if ($user['role'] !== 'superadmin') {
            $custId    = (int)($user['customer_id'] ?? 0);
            $myCamIds  = array_flip(array_map('intval',
                array_column($this->db->where('cameras', ['customer_id' => $custId]), 'id')
            ));
            $all = array_values(array_filter($all, fn($r) => isset($myCamIds[(int)$r['camera_id']])));
        }

        if ($cameraId) $all = array_values(array_filter($all, fn($r) => (int)$r['camera_id'] === (int)$cameraId));
        if ($status)   $all = array_values(array_filter($all, fn($r) => $r['status'] === $status));

        $all   = array_reverse($all);
        $total = count($all);
        $items = array_slice($all, ($page - 1) * $limit, $limit);

        // Camera map — DB cache sayesinde ikinci yükleme bedavadır
        $camMap = [];
        foreach ($this->db->all('cameras') as $c) $camMap[(int)$c['id']] = $c;

        Response::json([
            'items' => array_map(fn($r) => $this->format($r, $camMap), $items),
            'total' => $total,
            'page'  => $page,
        ]);
    }

    public function start(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $b        = Response::body();
        $cameraId = (int)($b['cameraId'] ?? 0);
        if (!$cameraId) Response::abort(400, 'cameraId gerekli');

        $camera = $this->db->find('cameras', $cameraId);
        if (!$camera) Response::abort(404, 'Kamera bulunamadı');
        if ($user['role'] !== 'superadmin' && (int)($camera['customer_id'] ?? 0) !== (int)($user['customer_id'] ?? 0)) {
            Response::abort(403, 'Bu kameraya erişim izniniz yok');
        }

        $active = $this->db->where('recordings', ['camera_id' => $cameraId, 'status' => 'recording']);
        if (!empty($active)) Response::abort(409, 'Bu kamera için zaten aktif bir kayıt var');

        $this->enforceStorageQuota($cameraId, (int)($camera['customer_id'] ?? 0));

        $trigger = $b['trigger'] ?? 'manual';
        if (!in_array($trigger, ['manual', 'motion', 'schedule', 'event'], true)) $trigger = 'manual';

        $recording = $this->db->insert('recordings', [
            'camera_id'  => $cameraId,
            'status'     => 'recording',
            'start_time' => date('c'),
            'trigger'    => $trigger,
            'file_path'  => null,
        ]);

        $camMap = [(int)$camera['id'] => $camera];
        Response::json($this->format($recording, $camMap), 201);
    }

    public function show(array $user, int $id): void
    {
        $recording = $this->db->find('recordings', $id);
        if (!$recording) Response::abort(404, 'Kayıt bulunamadı');

        if ($user['role'] !== 'superadmin') {
            $camera = $this->db->find('cameras', (int)$recording['camera_id']);
            if (!$camera || (int)($camera['customer_id'] ?? 0) !== (int)($user['customer_id'] ?? 0)) {
                Response::abort(403, 'Bu kayda erişim izniniz yok');
            }
        }

        $camMap = [];
        $cam = $this->db->find('cameras', (int)$recording['camera_id']);
        if ($cam) $camMap[(int)$cam['id']] = $cam;
        Response::json($this->format($recording, $camMap));
    }

    public function stop(array $user, int $id): void
    {
        $recording = $this->db->find('recordings', $id);
        if (!$recording) Response::abort(404, 'Kayıt bulunamadı');

        if ($user['role'] !== 'superadmin') {
            $camera = $this->db->find('cameras', (int)$recording['camera_id']);
            if (!$camera || (int)($camera['customer_id'] ?? 0) !== (int)($user['customer_id'] ?? 0)) {
                Response::abort(403, 'Bu kayda erişim izniniz yok');
            }
        }

        if ($recording['status'] !== 'recording') Response::abort(400, 'Kayıt aktif değil');

        $b        = Response::body();
        $start    = new DateTime($recording['start_time']);
        $end      = new DateTime();
        $duration = $end->getTimestamp() - $start->getTimestamp();

        $changes = [
            'status'   => 'completed',
            'end_time' => date('c'),
            'duration' => $duration,
        ];

        if (!empty($b['filePath']))  $changes['file_path'] = $b['filePath'];
        if (!empty($b['fileSize']))  $changes['file_size'] = (int)$b['fileSize'];
        if (empty($changes['file_size']) && !empty($changes['file_path']) && file_exists($changes['file_path'])) {
            $changes['file_size'] = filesize($changes['file_path']);
        }

        $updated = $this->db->update('recordings', $id, $changes);

        $camMap = [];
        $cam = $this->db->find('cameras', (int)$recording['camera_id']);
        if ($cam) $camMap[(int)$cam['id']] = $cam;
        Response::json($this->format($updated, $camMap));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $recording = $this->db->find('recordings', $id);
        if (!$recording) Response::abort(404, 'Kayıt bulunamadı');

        if ($user['role'] !== 'superadmin') {
            $camera = $this->db->find('cameras', (int)$recording['camera_id']);
            if (!$camera || (int)($camera['customer_id'] ?? 0) !== (int)($user['customer_id'] ?? 0)) {
                Response::abort(403, 'Bu kayda erişim izniniz yok');
            }
        }

        if (!empty($recording['file_path']) && file_exists($recording['file_path'])) {
            @unlink($recording['file_path']);
        }

        $this->db->delete('recordings', $id);
        Response::noContent();
    }

    // ── Depolama istatistikleri ────────────────────────────────────────────────

    public function storageStats(array $user): void
    {
        // Tek geçişte tüm verileri yükle
        $allRecs  = $this->db->all('recordings');
        $allCams  = $this->db->all('cameras');
        $allCusts = $this->db->all('customers');

        // Lookup map'leri
        $camMap  = [];
        foreach ($allCams  as $c) $camMap[(int)$c['id']]  = $c;
        $custMap = [];
        foreach ($allCusts as $c) $custMap[(int)$c['id']] = $c;

        // Yetki filtresi
        if ($user['role'] !== 'superadmin') {
            $custId    = (int)($user['customer_id'] ?? 0);
            $myCamIds  = array_flip(array_map('intval',
                array_column($this->db->where('cameras', ['customer_id' => $custId]), 'id')
            ));
            $allRecs = array_values(array_filter($allRecs, fn($r) => isset($myCamIds[(int)$r['camera_id']])));
        }

        // Kamera başına kullanım (tek geçiş)
        $stats = [];
        foreach ($allRecs as $r) {
            $camId = (int)$r['camera_id'];
            if (!isset($stats[$camId])) {
                $cam   = $camMap[$camId] ?? null;
                $cust  = $cam ? ($custMap[(int)($cam['customer_id'] ?? 0)] ?? null) : null;
                $limGb = (int)($cust['storage_limit_gb_per_camera'] ?? 10);
                $stats[$camId] = [
                    'cameraId'       => $camId,
                    'cameraName'     => $cam['name'] ?? "Kamera #$camId",
                    'customerId'     => $cam ? (int)$cam['customer_id'] : null,
                    'customerName'   => $cust['name'] ?? null,
                    'limitGb'        => $limGb,
                    'limitBytes'     => $limGb * 1024 * 1024 * 1024,
                    'usedBytes'      => 0,
                    'recordingCount' => 0,
                ];
            }
            if ($r['status'] === 'completed' && !empty($r['file_size'])) {
                $stats[$camId]['usedBytes'] += (int)$r['file_size'];
            }
            $stats[$camId]['recordingCount']++;
        }

        foreach ($stats as &$s) {
            $s['usedGb']      = round($s['usedBytes'] / (1024 ** 3), 2);
            $s['usedPercent'] = $s['limitBytes'] > 0
                ? min(100, round($s['usedBytes'] / $s['limitBytes'] * 100, 1))
                : 0;
        }

        Response::json(array_values($stats));
    }

    // ── Kota uygulama (circular buffer) ──────────────────────────────────────

    private function enforceStorageQuota(int $cameraId, int $customerId): void
    {
        if (!$customerId) return;

        $customer = $this->db->find('customers', $customerId);
        if (!$customer) return;

        $limitGb    = (int)($customer['storage_limit_gb_per_camera'] ?? 10);
        $limitBytes = $limitGb * 1024 * 1024 * 1024;

        // Bu kameranın tamamlanmış ve boyutu bilinen kayıtları
        $recs = array_values(array_filter(
            $this->db->all('recordings'),
            fn($r) => (int)$r['camera_id'] === $cameraId
                   && $r['status'] === 'completed'
                   && !empty($r['file_size']) && (int)$r['file_size'] > 0
        ));

        $used = array_sum(array_column($recs, 'file_size'));
        if ($used < $limitBytes) return;

        // En eski → en yeni
        usort($recs, fn($a, $b) => strcmp((string)($a['start_time'] ?? ''), (string)($b['start_time'] ?? '')));

        $target = (int)($limitBytes * 0.80);
        foreach ($recs as $old) {
            if ($used <= $target) break;
            if (!empty($old['file_path']) && file_exists($old['file_path'])) {
                @unlink($old['file_path']);
            }
            $used -= (int)($old['file_size'] ?? 0);
            $this->db->delete('recordings', (int)$old['id']);
        }
    }

    // ── Format ────────────────────────────────────────────────────────────────

    public function format(array $r, array $camMap = []): array
    {
        $camId  = (int)$r['camera_id'];
        $camera = $camMap[$camId] ?? $this->db->find('cameras', $camId);
        return [
            'id'         => (int)$r['id'],
            'cameraId'   => $camId,
            'cameraName' => $camera['name'] ?? null,
            'status'     => $r['status'],
            'startTime'  => $r['start_time'],
            'endTime'    => $r['end_time'] ?? null,
            'filePath'   => $r['file_path'] ?? null,
            'fileSize'   => isset($r['file_size']) ? (int)$r['file_size'] : null,
            'duration'   => isset($r['duration']) ? (int)$r['duration'] : null,
            'trigger'    => $r['trigger'] ?? 'manual',
            'createdAt'  => $r['created_at'],
        ];
    }
}
