<?php
declare(strict_types=1);

class EventController
{
    // Desteklenen olay türleri (OpenIPC AI modülleri dahil)
    private const VALID_TYPES = ['motion', 'person', 'vehicle', 'face', 'tamper'];

    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $cameraId = Response::query('cameraId');
        $type     = Response::query('type');
        $page     = max(1, (int)Response::query('page', 1));
        $limit    = min(100, max(1, (int)Response::query('limit', 20)));

        $all = $this->db->all('camera_events');

        // Yetki filtresi
        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($e) => in_array((int)$e['camera_id'], $myCameras));
        }

        if ($cameraId) $all = array_filter($all, fn($e) => (int)$e['camera_id'] === (int)$cameraId);
        if ($type)     $all = array_filter($all, fn($e) => $e['type'] === $type);

        $all   = array_values(array_reverse($all)); // En yeni önce
        $total = count($all);
        $items = array_slice($all, ($page - 1) * $limit, $limit);

        Response::json([
            'items' => array_map([$this, 'format'], $items),
            'total' => $total,
            'page'  => $page,
        ]);
    }

    public function recent(array $user): void
    {
        $all = $this->db->all('camera_events');

        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($e) => in_array((int)$e['camera_id'], $myCameras));
        }

        $all   = array_values(array_reverse($all));
        $items = array_slice($all, 0, 20);

        Response::json(array_map([$this, 'format'], $items));
    }

    /**
     * Kamera push webhook'u — OpenIPC / Majestic veya dış sistem olayları gönderir.
     * Kimlik doğrulama: Bearer JWT, per-camera token (X-Camera-Token) veya global CAMERA_PUSH_TOKEN.
     *
     * Kamera ajanı X-Camera-Token ile çağırır; cameraId body'de olmak zorunda değil —
     * token üzerinden otomatik çözümlenir.
     *
     * Örnek body (ajandan):
     * { "type": "person", "confidence": 0.92, "snapshotUrl": "http://192.168.1.101/image.jpg" }
     *
     * Örnek body (dış sistem / JWT ile):
     * { "cameraId": 1, "type": "person", "confidence": 0.92 }
     */
    public function create(): void
    {
        // Yetki + kamera çözümlemesi
        $resolvedCamera = $this->requirePushAuth();

        $b    = Response::body();
        $type = $b['type'] ?? '';

        if (!in_array($type, self::VALID_TYPES, true)) {
            Response::abort(400, 'Geçersiz olay türü. Desteklenenler: ' . implode(', ', self::VALID_TYPES));
        }

        // cameraId: body'den al, yoksa token üzerinden çözümlenen kameradan al
        if (!empty($b['cameraId'])) {
            $camera = $this->db->find('cameras', (int)$b['cameraId']);
            if (!$camera) Response::abort(404, 'Kamera bulunamadı');
        } elseif ($resolvedCamera) {
            $camera = $resolvedCamera;
        } else {
            Response::abort(400, 'cameraId gerekli (JWT ile çağırırken body\'e ekleyin)');
        }

        $event = $this->db->insert('camera_events', [
            'camera_id'    => (int)$camera['id'],
            'type'         => $type,
            'confidence'   => isset($b['confidence']) ? (float)$b['confidence'] : null,
            'snapshot_url' => $b['snapshotUrl'] ?? null,
            'timestamp'    => $b['timestamp'] ?? date('c'),
            'metadata'     => isset($b['metadata']) ? json_encode($b['metadata']) : null,
        ]);

        // Kameranın son görülme zamanını güncelle ve durumunu online yap
        $this->db->update('cameras', (int)$camera['id'], [
            'status'    => 'online',
            'last_seen' => date('c'),
        ]);

        Response::json($this->format($event), 201);
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $event = $this->db->find('camera_events', $id);
        if (!$event) Response::abort(404, 'Olay bulunamadı');

        // Yetki kontrolü
        if ($user['role'] !== 'superadmin') {
            $camera = $this->db->find('cameras', (int)$event['camera_id']);
            if (!$camera || $camera['customer_id'] != $user['customer_id']) {
                Response::abort(403, 'Erişim izni yok');
            }
        }

        $this->db->delete('camera_events', $id);
        Response::noContent();
    }

    // ── Yardımcılar ──────────────────────────────────────────────────────────

    /**
     * Push endpoint için yetki doğrula.
     * Dönen değer: per-camera token ile eşleşen Camera kaydı (veya null — JWT/global token durumunda).
     *
     * Öncelik sırası:
     *  1. Per-camera token (X-Camera-Token = cameras.camera_token) → kamera kaydı döner
     *  2. Global CAMERA_PUSH_TOKEN (X-Camera-Token = config sabiti) → null döner
     *  3. JWT Bearer → null döner
     */
    private function requirePushAuth(): ?array
    {
        $camToken = $_SERVER['HTTP_X_CAMERA_TOKEN'] ?? ($_GET['token'] ?? '');

        if ($camToken) {
            // Seçenek 1: per-camera token — cameras tablosunda ara
            $cameras = $this->db->all('cameras');
            foreach ($cameras as $cam) {
                if (!empty($cam['camera_token']) && hash_equals($cam['camera_token'], $camToken)) {
                    return $cam; // Kamera bulundu, cameraId çözümlendi
                }
            }

            // Seçenek 2: global CAMERA_PUSH_TOKEN
            if (defined('CAMERA_PUSH_TOKEN') && CAMERA_PUSH_TOKEN
                    && hash_equals(CAMERA_PUSH_TOKEN, $camToken)) {
                return null; // Yetki tamam, cameraId body'den gelmeli
            }
        }

        // Seçenek 3: JWT Bearer
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/^Bearer\s+(.+)$/i', $authHeader, $m)) {
            $payload = $this->auth->verifyToken($m[1]);
            if ($payload) return null; // Yetki tamam, cameraId body'den gelmeli
        }

        Response::abort(401, 'Yetkisiz: per-camera token, global token veya JWT gerekli');
    }

    public function format(array $e): array
    {
        $camera = $this->db->find('cameras', (int)$e['camera_id']);
        return [
            'id'          => (int)$e['id'],
            'cameraId'    => (int)$e['camera_id'],
            'cameraName'  => $camera['name'] ?? null,
            'type'        => $e['type'],
            'confidence'  => isset($e['confidence']) ? (float)$e['confidence'] : null,
            'snapshotUrl' => $e['snapshot_url'] ?? null,
            'metadata'    => isset($e['metadata']) ? json_decode($e['metadata'], true) : null,
            'timestamp'   => $e['timestamp'],
        ];
    }
}
