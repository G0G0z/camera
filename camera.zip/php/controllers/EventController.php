<?php
declare(strict_types=1);

class EventController
{
    // Desteklenen olay türleri (OpenIPC AI modülleri dahil)
    private const VALID_TYPES = ['motion', 'person', 'vehicle', 'face', 'tamper'];

    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $cameraId = Response::query('cameraId');
        $type     = Response::query('type');
        $page     = max(1, (int)Response::query('page', 1));
        $limit    = min(100, max(1, (int)Response::query('limit', 20)));

        $all = $this->db->all('camera_events');

        // Yetki filtresi
        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($e) => in_array((int)$e['camera_id'], $myCameras));
        }

        if ($cameraId) $all = array_filter($all, fn($e) => (int)$e['camera_id'] === (int)$cameraId);
        if ($type)     $all = array_filter($all, fn($e) => $e['type'] === $type);

        $all   = array_values(array_reverse($all)); // En yeni önce
        $total = count($all);
        $items = array_slice($all, ($page - 1) * $limit, $limit);

        Response::json([
            'items' => array_map([$this, 'format'], $items),
            'total' => $total,
            'page'  => $page,
        ]);
    }

    public function recent(array $user): void
    {
        $all = $this->db->all('camera_events');

        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($e) => in_array((int)$e['camera_id'], $myCameras));
        }

        $all   = array_values(array_reverse($all));
        $items = array_slice($all, 0, 20);

        Response::json(array_map([$this, 'format'], $items));
    }

    /**
     * Kamera push webhook'u — OpenIPC / Majestic veya dış sistem olayları gönderir.
     * Kimlik doğrulama: Bearer JWT veya basit API anahtarı (X-Camera-Token header).
     *
     * Örnek body:
     * {
     *   "cameraId": 1,
     *   "type": "person",
     *   "confidence": 0.92,
     *   "snapshotUrl": "http://192.168.1.101/snapshot.jpg",
     *   "timestamp": "2026-07-19T10:00:00+00:00"
     * }
     */
    public function create(): void
    {
        // Yetki: JWT veya kamera API anahtarı
        $this->requirePushAuth();

        $b        = Response::body();
        $cameraId = (int)($b['cameraId'] ?? 0);
        $type     = $b['type'] ?? '';

        if (!$cameraId) Response::abort(400, 'cameraId gerekli');
        if (!in_array($type, self::VALID_TYPES, true)) {
            Response::abort(400, 'Geçersiz olay türü. Desteklenenler: ' . implode(', ', self::VALID_TYPES));
        }

        $camera = $this->db->find('cameras', $cameraId);
        if (!$camera) Response::abort(404, 'Kamera bulunamadı');

        $event = $this->db->insert('camera_events', [
            'camera_id'    => $cameraId,
            'type'         => $type,
            'confidence'   => isset($b['confidence']) ? (float)$b['confidence'] : null,
            'snapshot_url' => $b['snapshotUrl'] ?? null,
            'timestamp'    => $b['timestamp'] ?? date('c'),
            'metadata'     => isset($b['metadata']) ? json_encode($b['metadata']) : null,
        ]);

        // Kameranın son görülme zamanını güncelle ve durumunu online yap
        $this->db->update('cameras', $cameraId, [
            'status'    => 'online',
            'last_seen' => date('c'),
        ]);

        Response::json($this->format($event), 201);
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $event = $this->db->find('camera_events', $id);
        if (!$event) Response::abort(404, 'Olay bulunamadı');

        // Yetki kontrolü
        if ($user['role'] !== 'superadmin') {
            $camera = $this->db->find('cameras', (int)$event['camera_id']);
            if (!$camera || $camera['customer_id'] != $user['customer_id']) {
                Response::abort(403, 'Erişim izni yok');
            }
        }

        $this->db->delete('camera_events', $id);
        Response::noContent();
    }

    // ── Yardımcılar ──────────────────────────────────────────────────────────

    /**
     * Push endpoint için JWT veya X-Camera-Token header'ı ile yetki doğrula.
     * X-Camera-Token: config.php'deki CAMERA_PUSH_TOKEN ile eşleşmeli.
     */
    private function requirePushAuth(): void
    {
        // Seçenek 1: standart JWT Bearer
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/^Bearer\s+(.+)$/i', $authHeader, $m)) {
            $db   = $this->db; // Database referansı Auth'a gerekiyor
            $auth = new Auth($db);
            $payload = $auth->verifyToken($m[1]);
            if ($payload) return; // Geçerli JWT
        }

        // Seçenek 2: kamera API anahtarı (X-Camera-Token header)
        $camToken = $_SERVER['HTTP_X_CAMERA_TOKEN'] ?? '';
        if ($camToken && defined('CAMERA_PUSH_TOKEN') && hash_equals(CAMERA_PUSH_TOKEN, $camToken)) {
            return;
        }

        Response::abort(401, 'Yetkisiz: JWT veya X-Camera-Token gerekli');
    }

    public function format(array $e): array
    {
        $camera = $this->db->find('cameras', (int)$e['camera_id']);
        return [
            'id'          => (int)$e['id'],
            'cameraId'    => (int)$e['camera_id'],
            'cameraName'  => $camera['name'] ?? null,
            'type'        => $e['type'],
            'confidence'  => isset($e['confidence']) ? (float)$e['confidence'] : null,
            'snapshotUrl' => $e['snapshot_url'] ?? null,
            'metadata'    => isset($e['metadata']) ? json_decode($e['metadata'], true) : null,
            'timestamp'   => $e['timestamp'],
        ];
    }
}
