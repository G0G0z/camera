<?php
declare(strict_types=1);

class CustomerController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');

        $customers = $user['role'] === 'superadmin'
            ? $this->db->all('customers')
            : [$this->db->find('customers', (int)$user['customer_id'])];

        $customers = array_filter($customers);
        Response::json(array_map(fn($c) => $this->format($c), array_values($customers)));
    }

    public function store(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin');
        $b = Response::body();
        if (!trim($b['name'] ?? '')) Response::abort(400, 'Müşteri adı gerekli');

        $customer = $this->db->insert('customers', [
            'name'  => trim($b['name']),
            'email' => $b['email'] ?? null,
            'phone' => $b['phone'] ?? null,
        ]);

        Response::json($this->format($customer), 201);
    }

    public function show(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $customer = $this->db->find('customers', $id);
        if (!$customer) Response::abort(404, 'Müşteri bulunamadı');
        Response::json($this->format($customer));
    }

    public function update(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin');
        if (!$this->db->find('customers', $id)) Response::abort(404, 'Müşteri bulunamadı');
        $b = Response::body();

        $changes = array_filter([
            'name'  => $b['name'] ?? null,
            'email' => $b['email'] ?? null,
            'phone' => $b['phone'] ?? null,
        ], fn($v) => $v !== null);

        $updated = $this->db->update('customers', $id, $changes);
        Response::json($this->format($updated));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin');
        if (!$this->db->find('customers', $id)) Response::abort(404, 'Müşteri bulunamadı');
        $this->db->delete('customers', $id);
        $this->db->deleteWhere('cameras', 'customer_id', $id);
        $this->db->deleteWhere('users', 'customer_id', $id);
        Response::noContent();
    }

    public function cameras(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $cameras = $this->db->where('cameras', ['customer_id' => $id]);
        $cc = new CameraController($this->db, $this->auth);
        Response::json(array_map([$cc, 'format'], $cameras));
    }

    private function format(array $c): array
    {
        $cameraCount = count($this->db->where('cameras', ['customer_id' => (int)$c['id']]));
        return [
            'id'          => (int)$c['id'],
            'name'        => $c['name'],
            'email'       => $c['email'] ?? null,
            'phone'       => $c['phone'] ?? null,
            'cameraCount' => $cameraCount,
            'createdAt'   => $c['created_at'],
        ];
    }
}
