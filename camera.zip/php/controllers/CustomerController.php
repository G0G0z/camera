<?php
declare(strict_types=1);

class CustomerController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');

        $customers = $user['role'] === 'superadmin'
            ? $this->db->all('customers')
            : array_filter([$this->db->find('customers', (int)$user['customer_id'])]);

        $customers = array_values(array_filter($customers));

        // Tüm kamera ve kayıtları tek seferinde yükle
        $allCameras = $this->db->all('cameras');
        $allRecs    = $this->db->all('recordings');

        // Kamera başına kullanılan alan (single pass)
        $camUsed = [];
        foreach ($allRecs as $r) {
            $camId = (int)$r['camera_id'];
            if ($r['status'] === 'completed' && !empty($r['file_size'])) {
                $camUsed[$camId] = ($camUsed[$camId] ?? 0) + (int)$r['file_size'];
            }
        }

        Response::json(array_map(
            fn($c) => $this->format($c, $allCameras, $camUsed),
            $customers
        ));
    }

    public function store(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin');
        $b = Response::body();
        if (!trim($b['name'] ?? '')) Response::abort(400, 'Müşteri adı gerekli');

        $limitGb = isset($b['storageLimitGbPerCamera'])
            ? max(1, (int)$b['storageLimitGbPerCamera'])
            : 10;

        $customer = $this->db->insert('customers', [
            'name'                        => trim($b['name']),
            'email'                       => $b['email'] ?? null,
            'phone'                       => $b['phone'] ?? null,
            'storage_limit_gb_per_camera' => $limitGb,
        ]);

        $allCameras = $this->db->all('cameras');
        Response::json($this->format($customer, $allCameras, []), 201);
    }

    public function show(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $customer = $this->db->find('customers', $id);
        if (!$customer) Response::abort(404, 'Müşteri bulunamadı');

        $allCameras = $this->db->all('cameras');
        $allRecs    = $this->db->all('recordings');

        $camUsed = [];
        foreach ($allRecs as $r) {
            $camId = (int)$r['camera_id'];
            if ($r['status'] === 'completed' && !empty($r['file_size'])) {
                $camUsed[$camId] = ($camUsed[$camId] ?? 0) + (int)$r['file_size'];
            }
        }

        Response::json($this->format($customer, $allCameras, $camUsed));
    }

    public function update(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin');
        if (!$this->db->find('customers', $id)) Response::abort(404, 'Müşteri bulunamadı');
        $b = Response::body();

        $changes = [];
        if (!empty($b['name']))              $changes['name']  = trim($b['name']);
        if (array_key_exists('email', $b))   $changes['email'] = $b['email'];
        if (array_key_exists('phone', $b))   $changes['phone'] = $b['phone'];
        if (isset($b['storageLimitGbPerCamera'])) {
            $changes['storage_limit_gb_per_camera'] = max(1, (int)$b['storageLimitGbPerCamera']);
        }

        $updated    = $this->db->update('customers', $id, $changes);
        $allCameras = $this->db->all('cameras');
        $allRecs    = $this->db->all('recordings');

        $camUsed = [];
        foreach ($allRecs as $r) {
            $camId = (int)$r['camera_id'];
            if ($r['status'] === 'completed' && !empty($r['file_size'])) {
                $camUsed[$camId] = ($camUsed[$camId] ?? 0) + (int)$r['file_size'];
            }
        }

        Response::json($this->format($updated, $allCameras, $camUsed));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin');
        if (!$this->db->find('customers', $id)) Response::abort(404, 'Müşteri bulunamadı');
        $this->db->delete('customers', $id);
        $this->db->deleteWhere('cameras', 'customer_id', $id);
        $this->db->deleteWhere('users', 'customer_id', $id);
        Response::noContent();
    }

    public function cameras(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $cameras = $this->db->where('cameras', ['customer_id' => $id]);
        $cc = new CameraController($this->db, $this->auth);
        Response::json(array_map([$cc, 'format'], $cameras));
    }

    // ── Format (önceden yüklenmiş kamera + kayıt verileri ile) ───────────────

    public function format(array $c, array $allCameras = [], array $camUsed = []): array
    {
        $custId  = (int)$c['id'];
        $limitGb = (int)($c['storage_limit_gb_per_camera'] ?? 10);

        // Bu müşteriye ait kameralar (allCameras zaten yüklü)
        $custCams = array_values(array_filter(
            $allCameras,
            fn($cam) => (int)($cam['customer_id'] ?? 0) === $custId
        ));
        $cameraCount = count($custCams);

        // Kamera başına kullanım (camUsed zaten hesaplı)
        $usagePerCamera = [];
        foreach ($custCams as $cam) {
            $camId = (int)$cam['id'];
            $usagePerCamera[$camId] = $camUsed[$camId] ?? 0;
        }

        return [
            'id'                      => $custId,
            'name'                    => $c['name'],
            'email'                   => $c['email'] ?? null,
            'phone'                   => $c['phone'] ?? null,
            'cameraCount'             => $cameraCount,
            'storageLimitGbPerCamera' => $limitGb,
            'storageLimitBytes'       => $limitGb * 1024 * 1024 * 1024,
            'storageUsagePerCamera'   => $usagePerCamera,
            'createdAt'               => $c['created_at'],
        ];
    }
}
