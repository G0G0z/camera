<?php
declare(strict_types=1);

class AuthController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function login(): void
    {
        $body  = Response::body();
        $email = trim($body['email'] ?? '');
        $pass  = $body['password'] ?? '';

        if (!$email || !$pass) Response::abort(400, 'Email ve şifre gerekli');

        $user = $this->db->findBy('users', 'email', strtolower($email));
        if (!$user || !$this->auth->verifyPassword($pass, $user['password_hash'])) {
            Response::abort(401, 'Email veya şifre hatalı');
        }

        $token = $this->auth->createToken(['sub' => $user['id'], 'role' => $user['role']]);

        Response::json([
            'token' => $token,
            'user'  => $this->sanitize($user),
        ]);
    }

    public function logout(): void
    {
        // JWT stateless — istemci token'ı siler
        Response::json(['success' => true]);
    }

    public function me(array $user): void
    {
        Response::json($this->sanitize($user));
    }

    private function sanitize(array $user): array
    {
        unset($user['password_hash']);
        return [
            'id'         => $user['id'],
            'email'      => $user['email'],
            'name'       => $user['name'] ?? null,
            'role'       => $user['role'],
            'customerId' => $user['customer_id'] ?? null,
            'createdAt'  => $user['created_at'],
        ];
    }
}
