<?php
declare(strict_types=1);

class AuthController
{
    public function __construct(private Database $db, private Auth $auth) {}

    // ── Giriş ────────────────────────────────────────────────────────────────
    public function login(): void
    {
        $body  = Response::body();
        $email = trim($body['email'] ?? '');
        $pass  = $body['password'] ?? '';

        if (!$email || !$pass) Response::abort(400, 'Email ve şifre gerekli');

        $user = $this->db->findBy('users', 'email', strtolower($email));
        if (!$user || !$this->auth->verifyPassword($pass, $user['password_hash'])) {
            Response::abort(401, 'Email veya şifre hatalı');
        }

        // JWT'ye tüm kimlik bilgilerini koy — requireAuth() DB'ye gitmeden dönsün
        $token = $this->auth->createToken([
            'sub'         => $user['id'],
            'role'        => $user['role'],
            'email'       => $user['email']       ?? '',
            'name'        => $user['name']        ?? '',
            'customer_id' => $user['customer_id'] ?? null,
        ]);

        Response::json([
            'token' => $token,
            'user'  => $this->sanitize($user),
        ]);
    }

    public function logout(): void
    {
        Response::json(['success' => true]);
    }

    public function me(array $user): void
    {
        // JWT claim'lerinden gelen $user yeterli; DB'ye gitmek gerekmiyor
        // ancak en güncel veriyi döndürmek için DB'den oku (cache'den gelir)
        $fresh = $this->db->find('users', $user['id']);
        Response::json($this->sanitize($fresh ?? $user));
    }

    // ── Profil güncelleme ─────────────────────────────────────────────────────
    public function updateProfile(array $user): void
    {
        $b    = Response::body();
        $name = trim($b['name'] ?? '');
        $email = strtolower(trim($b['email'] ?? ''));

        $changes = [];
        if ($name)  $changes['name']  = $name;
        if ($email) {
            // Başka kullanıcıda aynı email var mı?
            $existing = $this->db->findBy('users', 'email', $email);
            if ($existing && (int)$existing['id'] !== $user['id']) {
                Response::abort(409, 'Bu email başka bir hesapta kullanılıyor');
            }
            $changes['email'] = $email;
        }

        if (empty($changes)) Response::abort(400, 'Güncellenecek alan yok');

        $updated = $this->db->update('users', $user['id'], $changes);
        Response::json($this->sanitize($updated ?? $user));
    }

    // ── Şifre değiştirme ─────────────────────────────────────────────────────
    public function changePassword(array $user): void
    {
        $b    = Response::body();
        $cur  = $b['currentPassword'] ?? '';
        $new  = $b['newPassword']     ?? '';

        if (!$cur || !$new) Response::abort(400, 'Mevcut ve yeni şifre gerekli');
        if (strlen($new) < 6) Response::abort(400, 'Yeni şifre en az 6 karakter olmalı');

        // Güncel hash'i DB'den al
        $fresh = $this->db->find('users', $user['id']);
        if (!$fresh || !$this->auth->verifyPassword($cur, $fresh['password_hash'] ?? '')) {
            Response::abort(401, 'Mevcut şifre hatalı');
        }

        $this->db->update('users', $user['id'], [
            'password_hash' => $this->auth->hashPassword($new),
        ]);

        Response::json(['success' => true]);
    }

    // ── Hesap silme ───────────────────────────────────────────────────────────
    public function deleteAccount(array $user): void
    {
        if ($user['role'] === 'superadmin') {
            Response::abort(403, 'Superadmin hesabı silinemez');
        }
        $this->db->delete('users', $user['id']);
        Response::json(['success' => true]);
    }

    // ── Yardımcılar ───────────────────────────────────────────────────────────
    private function sanitize(array $user): array
    {
        unset($user['password_hash']);
        return [
            'id'         => (int)$user['id'],
            'email'      => $user['email'],
            'name'       => $user['name'] ?? null,
            'role'       => $user['role'],
            'customerId' => isset($user['customer_id']) ? (int)$user['customer_id'] : null,
            'createdAt'  => $user['created_at'],
        ];
    }
}
