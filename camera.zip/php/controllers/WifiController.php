<?php
declare(strict_types=1);

class WifiController
{
    public function __construct(private Database $db, private Auth $auth) {}

    // ── WiFi profil listesi ───────────────────────────────────────────────────
    public function index(array $user): void
    {
        $profiles = $user['role'] === 'superadmin'
            ? $this->db->all('wifi_profiles')
            : $this->db->where('wifi_profiles', ['customer_id' => $user['customer_id']]);

        Response::json(array_map([$this, 'format'], array_values($profiles)));
    }

    // ── Yeni profil kaydet ────────────────────────────────────────────────────
    public function store(array $user): void
    {
        $b    = Response::body();
        $ssid = trim($b['ssid'] ?? '');
        if (!$ssid) Response::abort(400, 'WiFi ağ adı (SSID) gerekli');

        $profile = $this->db->insert('wifi_profiles', [
            'customer_id' => $user['customer_id'] ?? null,
            'name'        => trim($b['name'] ?? $ssid),
            'ssid'        => $ssid,
            'password'    => isset($b['password']) ? base64_encode($b['password']) : null,
            'security'    => $b['security'] ?? 'WPA',  // WPA | WEP | nopass
            'hidden'      => (bool)($b['hidden'] ?? false),
        ]);

        Response::json($this->format($profile), 201);
    }

    // ── Profil sil ────────────────────────────────────────────────────────────
    public function destroy(array $user, int $id): void
    {
        $profile = $this->db->find('wifi_profiles', $id);
        if (!$profile) Response::abort(404, 'Profil bulunamadı');
        if ($user['role'] !== 'superadmin' && $profile['customer_id'] != $user['customer_id']) {
            Response::abort(403, 'Erişim izni yok');
        }
        $this->db->delete('wifi_profiles', $id);
        Response::noContent();
    }

    // ── QR string üret (WiFi QR standart formatı) ─────────────────────────────
    public function qrString(array $user): void
    {
        $b        = Response::body();
        $ssid     = trim($b['ssid'] ?? '');
        $password = $b['password'] ?? '';
        $security = strtoupper($b['security'] ?? 'WPA');
        $hidden   = (bool)($b['hidden'] ?? false);

        if (!$ssid) Response::abort(400, 'SSID gerekli');

        // WiFi QR standart formatı: WIFI:T:WPA;S:ssid;P:password;H:true;;
        $escape = fn(string $v): string => addcslashes($v, '\\;,":');

        $parts  = ['T:' . ($security === 'NOPASS' ? 'nopass' : $security)];
        $parts[] = 'S:' . $escape($ssid);
        if ($password && $security !== 'NOPASS') {
            $parts[] = 'P:' . $escape($password);
        }
        if ($hidden) {
            $parts[] = 'H:true';
        }

        $qrString = 'WIFI:' . implode(';', $parts) . ';;';

        Response::json([
            'qrString' => $qrString,
            'ssid'     => $ssid,
            'security' => $security,
            'hidden'   => $hidden,
        ]);
    }

    private function format(array $p): array
    {
        return [
            'id'         => (int)$p['id'],
            'name'       => $p['name'],
            'ssid'       => $p['ssid'],
            'security'   => $p['security'],
            'hidden'     => (bool)$p['hidden'],
            'hasPassword'=> !empty($p['password']),
            'customerId' => isset($p['customer_id']) ? (int)$p['customer_id'] : null,
            'createdAt'  => $p['created_at'],
        ];
    }
}
