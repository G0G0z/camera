<?php
declare(strict_types=1);

class PtzController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function command(array $user, int $cameraId): void
    {
        $camera = $this->getCamera($user, $cameraId);
        $b      = Response::body();
        $action = $b['action'] ?? '';
        $speed  = (float)($b['speed'] ?? 0.5);

        if (!$camera['ptz_enabled']) Response::abort(400, 'Bu kamerada PTZ etkin değil');

        $pass  = $camera['password_encrypted'] ? base64_decode($camera['password_encrypted']) : '';
        $onvif = new Onvif($camera['ip'], (int)($camera['onvif_port'] ?? 80), $camera['username'] ?? 'admin', $pass);

        $profiles = $onvif->getProfiles();
        $token    = $profiles[0] ?? 'Profile_1';

        $ok = match ($action) {
            'left'     => $onvif->continuousMove($token, -$speed, 0),
            'right'    => $onvif->continuousMove($token, $speed, 0),
            'up'       => $onvif->continuousMove($token, 0, $speed),
            'down'     => $onvif->continuousMove($token, 0, -$speed),
            'zoom_in'  => $onvif->continuousMove($token, 0, 0, $speed),
            'zoom_out' => $onvif->continuousMove($token, 0, 0, -$speed),
            'stop'     => $onvif->stop($token),
            'home'     => $onvif->gotoHomePosition($token),
            default    => false,
        };

        Response::json(['success' => $ok, 'message' => $ok ? null : 'PTZ komutu gönderilemedi']);
    }

    public function presets(array $user, int $cameraId): void
    {
        $this->getCamera($user, $cameraId);
        $presets = $this->db->where('ptz_presets', ['camera_id' => $cameraId]);

        Response::json(array_map(fn($p) => [
            'id'       => (int)$p['id'],
            'cameraId' => (int)$p['camera_id'],
            'name'     => $p['name'],
            'token'    => $p['token'],
        ], $presets));
    }

    public function savePreset(array $user, int $cameraId): void
    {
        $camera = $this->getCamera($user, $cameraId);
        $b      = Response::body();
        $name   = trim($b['name'] ?? '');
        if (!$name) Response::abort(400, 'Preset adı gerekli');

        $pass  = $camera['password_encrypted'] ? base64_decode($camera['password_encrypted']) : '';
        $onvif = new Onvif($camera['ip'], (int)($camera['onvif_port'] ?? 80), $camera['username'] ?? 'admin', $pass);

        $profiles = $onvif->getProfiles();
        $token    = $profiles[0] ?? 'Profile_1';
        $presetToken = $onvif->setPreset($token, $name) ?? uniqid('preset_');

        $preset = $this->db->insert('ptz_presets', [
            'camera_id' => $cameraId,
            'name'      => $name,
            'token'     => $presetToken,
        ]);

        Response::json([
            'id'       => (int)$preset['id'],
            'cameraId' => $cameraId,
            'name'     => $preset['name'],
            'token'    => $preset['token'],
        ], 201);
    }

    public function gotoPreset(array $user, int $cameraId, int $presetId): void
    {
        $camera = $this->getCamera($user, $cameraId);
        $preset = $this->db->find('ptz_presets', $presetId);
        if (!$preset || $preset['camera_id'] != $cameraId) Response::abort(404, 'Preset bulunamadı');

        $pass  = $camera['password_encrypted'] ? base64_decode($camera['password_encrypted']) : '';
        $onvif = new Onvif($camera['ip'], (int)($camera['onvif_port'] ?? 80), $camera['username'] ?? 'admin', $pass);

        $profiles = $onvif->getProfiles();
        $token    = $profiles[0] ?? 'Profile_1';
        $ok       = $onvif->gotoPreset($token, $preset['token']);

        Response::json(['success' => $ok, 'message' => $ok ? null : 'Preset konumuna gidilemedi']);
    }

    private function getCamera(array $user, int $id): array
    {
        $camera = $this->db->find('cameras', $id);
        if (!$camera) Response::abort(404, 'Kamera bulunamadı');
        if ($user['role'] !== 'superadmin' && $camera['customer_id'] != $user['customer_id']) {
            Response::abort(403, 'Erişim izni yok');
        }
        return $camera;
    }
}
