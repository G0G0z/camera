# Kamera Yönetim Sistemi — PHP Backend

Framework veya veritabanı kurulumu gerektirmez. JSON dosyaları üzerinde çalışır.

## Replit'te Geliştirme

PHP otomatik olarak `php-backend: PHP Server` workflow'u ile çalışır.

## Ucuz Hosting'e Deploy

### Apache (cPanel, Hepsia vb.)
1. `php-backend/` klasörünü hosting'e yükle
2. `.htaccess` dosyası zaten yapılandırılmış
3. `data/` klasörünün yazılabilir olduğundan emin ol: `chmod 755 data/`
4. `.env` dosyasını düzenle (JWT_SECRET mutlaka değiştir)
5. `php seed.php` çalıştır (SSH varsa) veya web tarayıcısından `/api/setup` çağır
6. React uygulamasını build et: `pnpm run build`
7. `dist/` klasörünü public_html'e yükle

### nginx + PHP-FPM
```nginx
server {
    root /var/www/html;

    # React static dosyalar
    location / {
        try_files $uri $uri/ /index.html;
    }

    # PHP API
    location /api/ {
        root /var/www/php-backend;
        try_files $uri $uri/ /api/index.php?$query_string;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME /var/www/php-backend/index.php;
        include fastcgi_params;
    }
}
```

## Yapılandırma (.env)

```env
JWT_SECRET=cok-gizli-bir-anahtar-buraya
DATA_DIR=/var/www/php-backend/data
MEDIAMTX_HLS=https://yourserver.com/hls
MEDIAMTX_WEBRTC=https://yourserver.com/webrtc
```

## Kullanıcılar (seed sonrası)

| Email | Şifre | Rol |
|-------|-------|-----|
| admin@example.com | admin123 | Süper Admin |
| avm@example.com | avm123 | Admin |
| izleyici@example.com | izleyici123 | İzleyici |

## Veri Dosyaları

Tüm veriler `data/` klasöründe JSON olarak saklanır:
- `data/customers.json`
- `data/users.json`
- `data/cameras.json`
- `data/recordings.json`
- `data/camera_events.json`
- `data/ptz_presets.json`
