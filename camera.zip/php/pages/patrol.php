<?php
$pageTitle  = 'Devriye Modu';
$activePage = 'patrol';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>🔄 Devriye Modu</h1>
    <p>PTZ kameralarda otomatik preset turu</p>
  </div>
  <button class="btn btn-primary btn-sm" onclick="openAddPatrol()">+ Devriye Ekle</button>
</div>

<!-- Bilgi banner -->
<div class="card mb-4 border-green-500/30 bg-green-500/5">
  <div class="flex items-start gap-3">
    <span class="text-green-400 text-xl">✅</span>
    <div>
      <p class="text-sm font-medium text-green-300">Kamera taraflı devriye</p>
      <p class="text-xs text-zinc-400 mt-1">Devriye, kameranın kendi ajanı (camera-agent) tarafından yürütülür. Tarayıcıyı kapatabilirsiniz — kamera devriyeye devam eder.</p>
    </div>
  </div>
</div>

<!-- Devriye listesi -->
<div id="patrol-list" class="grid grid-cols-1 md:grid-cols-2 gap-4">
  <div class="card skeleton h-32"></div>
  <div class="card skeleton h-32"></div>
</div>

<script>
let patrols = [];
let cameras = [];
let presetsByCamera = {}; // cameraId → presets[]

async function load() {
  try {
    [patrols, cameras] = await Promise.all([ App.get('/patrol-routes'), App.get('/cameras') ]);
    // PTZ kameraların presetlerini yükle
    const ptzCams = cameras.filter(c => c.ptzEnabled);
    await Promise.allSettled(ptzCams.map(async c => {
      try { presetsByCamera[c.id] = await App.get('/cameras/' + c.id + '/ptz/presets'); }
      catch(e) { presetsByCamera[c.id] = []; }
    }));
    render();
  } catch(e) { App.toast('Yüklenemedi: ' + e.message, 'error'); }
}

function camName(id) {
  const c = cameras.find(x => x.id === id);
  return c ? c.name : '#' + id;
}

function presetName(cameraId, id) {
  const prs = presetsByCamera[cameraId] || [];
  const p   = prs.find(x => x.id === id);
  return p ? (p.icon||'📍') + ' ' + p.name : '#' + id;
}

function render() {
  const el = document.getElementById('patrol-list');
  if (!patrols.length) {
    el.innerHTML = `<div class="col-span-2 empty-state">
      <p style="font-size:3rem">🔄</p>
      <h3>Devriye rotası yok</h3>
      <p>PTZ kameranıza presetler ekleyip devriye oluşturun.</p>
    </div>`;
    return;
  }
  el.innerHTML = patrols.map(p => {
    const running = PatrolEngine.isRunning(p);
    const cam     = cameras.find(c => c.id === p.cameraId);
    const presetNames = p.presetIds.map(id => presetName(p.cameraId, id)).join(' → ');
    return `<div class="card">
      <div class="flex items-start justify-between gap-2 mb-3">
        <div>
          <h3 class="font-semibold text-sm flex items-center gap-2">
            ${p.name}
            ${running ? '<span class="badge badge-green">▶ Kamerada Aktif</span>' : '<span class="badge badge-zinc">⏹ Bekliyor</span>'}
          </h3>
          <p class="text-xs text-zinc-500 mt-0.5">${camName(p.cameraId)} · ${p.dwellSeconds}sn bekleme · Hız ${p.speed}</p>
        </div>
        <div class="flex gap-1 shrink-0">
          <button class="btn btn-ghost btn-xs" onclick="openEditPatrol(${p.id})">✏️</button>
          <button class="btn btn-ghost btn-xs text-red-400" onclick="deletePatrol(${p.id})">🗑</button>
        </div>
      </div>
      <p class="text-xs text-zinc-400 mb-4 truncate" title="${presetNames}">
        📍 ${presetNames || 'Preset yok'}
      </p>
      ${!cam?.ptzEnabled ? '<p class="text-xs text-red-400">⚠️ Kamerada PTZ aktif değil</p>' : `
      <div class="flex gap-2">
        ${running
          ? `<button class="btn btn-warning btn-sm flex-1 patrol-running" onclick="stopPatrol(${p.id},'${p.name}')">⏹ Devriyeyi Durdur</button>`
          : `<button class="btn btn-success btn-sm flex-1" onclick="startPatrol(${p.id})">▶ Devriyeyi Başlat</button>`}
      </div>`}
    </div>`;
  }).join('');
}

async function startPatrol(id) {
  const p = patrols.find(x => x.id === id);
  if (!p) return;
  await PatrolEngine.start(p);
  // Sunucudan güncel listeyi çek (active durumu güncellendi)
  patrols = await App.get('/patrol-routes');
  render();
}
async function stopPatrol(id, name) {
  await PatrolEngine.stop(id, name);
  patrols = await App.get('/patrol-routes');
  render();
}

async function deletePatrol(id) {
  App.confirm('Bu devriye rotasını silmek istediğinize emin misiniz?', async () => {
    try {
      await App.del('/patrol-routes/' + id);
      patrols = patrols.filter(p => p.id !== id);
      render();
      App.toast('Silindi', 'success');
    } catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

function patrolFormInner(p) {
  const ptzCams = cameras.filter(c => c.ptzEnabled);
  const camOpts = ptzCams.map(c => `<option value="${c.id}" ${p?.cameraId===c.id?'selected':''}>${c.name}</option>`).join('');
  return `
    <div class="form-group">
      <label class="form-label">Devriye Adı</label>
      <input id="pf-name" class="form-control" value="${p?.name||''}" placeholder="Gece Devriyesi" />
    </div>
    <div class="form-group">
      <label class="form-label">Kamera</label>
      <select id="pf-cam" class="form-control" onchange="loadPresetPicker(parseInt(this.value))">
        <option value="">— Seçin —</option>${camOpts}
      </select>
    </div>
    <div id="pf-preset-area" class="form-group" style="display:${p?'block':'none'}">
      <label class="form-label">Presetler (sırayla seçin)</label>
      <div id="pf-presets" class="flex flex-wrap gap-2"></div>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div class="form-group">
        <label class="form-label">Bekleme (sn)</label>
        <input id="pf-dwell" type="number" class="form-control" value="${p?.dwellSeconds||10}" min="3" />
      </div>
      <div class="form-group">
        <label class="form-label">Hız (0.1–1.0)</label>
        <input id="pf-speed" type="number" class="form-control" value="${p?.speed||0.5}" min="0.1" max="1" step="0.1" />
      </div>
    </div>
    <div id="pf-err" class="text-red-400 text-xs hidden"></div>`;
}

async function loadPresetPicker(camId, selectedIds) {
  const area = document.getElementById('pf-preset-area');
  const list = document.getElementById('pf-presets');
  if (!camId) { area.style.display='none'; return; }
  area.style.display = 'block';
  list.innerHTML = '<div class="skeleton h-8 w-full rounded"></div>';
  try {
    let prs = presetsByCamera[camId];
    if (!prs) { prs = await App.get('/cameras/' + camId + '/ptz/presets'); presetsByCamera[camId] = prs; }
    if (!prs.length) { list.innerHTML = '<p class="text-xs text-zinc-500">Bu kamerada preset yok. Önce kamera detayından preset ekleyin.</p>'; return; }
    list.innerHTML = prs.map(pr => `<label class="preset-chip">
      <input type="checkbox" value="${pr.id}" ${(selectedIds||[]).includes(pr.id)?'checked':''} style="margin-right:4px">${pr.icon||'📍'} ${pr.name}
    </label>`).join('');
  } catch(e) { list.innerHTML = '<p class="text-xs text-red-400">Presetler yüklenemedi</p>'; }
}

function openAddPatrol() {
  App.openModal(`
    <div class="modal-header"><h3>Devriye Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">${patrolFormInner(null)}</div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="savePatrol(null)">Ekle</button>
    </div>`, true);
}

function openEditPatrol(id) {
  const p = patrols.find(x => x.id === id);
  App.openModal(`
    <div class="modal-header"><h3>Devriye Düzenle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">${patrolFormInner(p)}</div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="savePatrol(${id})">Kaydet</button>
    </div>`, true);
  if (p) loadPresetPicker(p.cameraId, p.presetIds);
}

async function savePatrol(id) {
  const name     = document.getElementById('pf-name').value.trim();
  const cameraId = parseInt(document.getElementById('pf-cam').value);
  const boxes    = document.querySelectorAll('#pf-presets input:checked');
  const presetIds = Array.from(boxes).map(b => parseInt(b.value));
  const dwell    = parseInt(document.getElementById('pf-dwell').value)||10;
  const speed    = parseFloat(document.getElementById('pf-speed').value)||0.5;
  const err      = document.getElementById('pf-err');
  if (!name)            { err.textContent='Ad giriniz'; err.classList.remove('hidden'); return; }
  if (!cameraId)        { err.textContent='Kamera seçin'; err.classList.remove('hidden'); return; }
  if (!presetIds.length){ err.textContent='En az 1 preset seçin'; err.classList.remove('hidden'); return; }
  try {
    if (id) {
      const u = await App.put('/patrol-routes/'+id, { name, presetIds, dwellSeconds: dwell, speed });
      const idx = patrols.findIndex(x => x.id === id); if (idx>=0) patrols[idx]=u;
    } else {
      const p = await App.post('/patrol-routes', { cameraId, name, presetIds, dwellSeconds: dwell, speed });
      patrols.push(p);
    }
    render(); App.closeModal(); App.toast(id ? 'Güncellendi' : 'Devriye eklendi', 'success');
  } catch(e) { err.textContent=e.message; err.classList.remove('hidden'); }
}

load();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
