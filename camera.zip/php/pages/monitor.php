<?php
$pageTitle  = 'Canlı İzleme';
$activePage = 'monitor';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>🖥 Canlı İzleme</h1>
    <p>Tüm kameraları tek ekranda izleyin</p>
  </div>
  <div class="flex gap-2 flex-wrap items-center">
    <select id="sel-cols" class="form-control" style="width:auto" onchange="setGrid(this.value)">
      <option value="2">2×2</option>
      <option value="3" selected>3×3</option>
      <option value="4">4×4</option>
      <option value="1">Tek</option>
    </select>
    <select id="sel-interval" class="form-control" style="width:auto" onchange="setInterval(parseInt(this.value))">
      <option value="5">5sn</option>
      <option value="10" selected>10sn</option>
      <option value="30">30sn</option>
      <option value="60">1dk</option>
      <option value="0">Manuel</option>
    </select>
    <button class="btn btn-secondary btn-sm" onclick="refreshAll()">🔄 Tümünü Yenile</button>
    <span id="next-refresh" class="text-xs text-zinc-500"></span>
  </div>
</div>

<div id="monitor-grid" class="monitor-grid cols-3">
  <?php for($i=0;$i<6;$i++): ?>
  <div class="monitor-cell"><div class="no-signal"><span style="font-size:2rem">📷</span><span>Yükleniyor…</span></div></div>
  <?php endfor ?>
</div>

<script>
let cameras   = [];
let refreshTimer = null;
let countdown    = 0;
let countdownTmr = null;

async function loadCameras() {
  try {
    cameras = await App.get('/cameras');
    renderGrid();
    refreshAll();
  } catch(e) {
    App.toast('Kameralar yüklenemedi: ' + e.message, 'error');
  }
}

function renderGrid() {
  const grid = document.getElementById('monitor-grid');
  if (!cameras.length) {
    grid.innerHTML = '<div class="col-span-4 empty-state"><h3>Kamera bulunamadı</h3><p>Önce kamera ekleyin.</p></div>';
    return;
  }
  grid.innerHTML = cameras.map(cam => `
    <div class="monitor-cell ${cam.status==='offline'?'cam-offline':''}" id="cell-${cam.id}" onclick="location.href='/cameras/${cam.id}'">
      <div class="no-signal" id="snap-placeholder-${cam.id}">
        <span style="font-size:1.5rem">📷</span>
        <span>${cam.name}</span>
      </div>
      <img id="snap-img-${cam.id}" src="" style="display:none" alt="${cam.name}" />
      <div class="cell-overlay">
        <div class="cell-name">${cam.name}</div>
        <div class="cell-status">${cam.ip}${cam.location?' · '+cam.location:''}</div>
      </div>
      <div class="cell-event" id="cell-evt-${cam.id}"></div>
    </div>`).join('');
}

async function refreshCamera(cam) {
  try {
    const snap = await App.get('/cameras/' + cam.id + '/snapshot');
    const img  = document.getElementById('snap-img-' + cam.id);
    const ph   = document.getElementById('snap-placeholder-' + cam.id);
    if (snap?.url && img) {
      img.src = snap.url + '?t=' + Date.now();
      img.style.display = 'block';
      img.onerror = () => { img.style.display='none'; if(ph) ph.style.display='flex'; };
      if (ph) ph.style.display = 'none';
    }
  } catch(e) {}
}

async function refreshAll() {
  if (!cameras.length) return;
  await Promise.allSettled(cameras.map(c => refreshCamera(c)));
  // Son olayları yükle
  try {
    const evts = await App.get('/events/recent');
    if (Array.isArray(evts)) {
      cameras.forEach(cam => {
        const last = evts.find(e => e.cameraId === cam.id);
        const el   = document.getElementById('cell-evt-' + cam.id);
        if (el && last) el.innerHTML = App.eventBadge(last.type);
      });
    }
  } catch(e) {}
}

function setGrid(cols) {
  const grid = document.getElementById('monitor-grid');
  grid.className = 'monitor-grid cols-' + cols;
}

let autoInterval = 10;
function setInterval(secs) {
  autoInterval = secs;
  clearInterval(refreshTimer);
  clearInterval(countdownTmr);
  if (secs > 0) {
    refreshTimer  = setInterval(refreshAll, secs * 1000);
    countdown     = secs;
    countdownTmr  = setInterval(() => {
      countdown--;
      const el = document.getElementById('next-refresh');
      if (el) el.textContent = countdown > 0 ? `Yenileme: ${countdown}sn` : '';
      if (countdown <= 0) countdown = autoInterval;
    }, 1000);
  } else {
    const el = document.getElementById('next-refresh');
    if (el) el.textContent = 'Manuel mod';
  }
}

loadCameras();
setInterval(10);
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
