<?php
$pageTitle  = 'Provizyon';
$activePage = 'provision';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Provizyon Listesi</h1>
  <p>Bekleyen ve tamamlanan kamera kayıtlarını görüntüleyin</p>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr>
        <th>Token</th><th>Etiket</th><th>Durum</th><th>Oluşturulma</th><th style="width:100px">İşlem</th>
      </tr></thead>
      <tbody id="prov-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 5) . '</tr>', 4) ?>
      </tbody>
    </table>
  </div>
  <div id="prov-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
    <h3>Bekleyen provizyon yok</h3>
    <p>Yeni kamera eklemek için <a href="/setup" class="text-blue-400 hover:underline">Kamera Ekle</a> sayfasını kullanın.</p>
  </div>
</div>

<script>
(async () => {
  const tbody = document.getElementById('prov-tbody');
  const empty = document.getElementById('prov-empty');
  try {
    const data = await App.get('/provision');
    const list = Array.isArray(data) ? data : [];
    if (!list.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = list.map(p => {
      const statusBadge = p.status === 'completed'
        ? App.badge('Tamamlandı','green')
        : p.status === 'cancelled' ? App.badge('İptal','red') : App.badge('Bekliyor','yellow');
      return `<tr>
        <td class="font-mono text-xs text-zinc-400">${p.token}</td>
        <td>${p.label || '—'}</td>
        <td>${statusBadge}</td>
        <td class="text-zinc-500 text-sm">${App.fmtDate(p.createdAt)}</td>
        <td>
          ${p.status === 'pending' ? `<button class="btn btn-ghost btn-sm text-red-400" onclick="cancelProv('${p.token}')">İptal</button>` : '—'}
        </td>
      </tr>`;
    }).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
})();

async function cancelProv(token) {
  App.confirm('Bu provizyon tokenini iptal etmek istediğinize emin misiniz?', async () => {
    try { await App.del('/provision/' + token); App.toast('İptal edildi','success'); location.reload(); }
    catch(e) { App.toast('Hata: ' + e.message,'error'); }
  });
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
