<?php
$pageTitle  = 'Firmware';
$activePage = 'firmware';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Firmware Yönetimi</h1>
  <p>OpenIPC firmware yükle ve yönet</p>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

  <!-- Flash commands -->
  <div class="card">
    <div class="card-header"><span class="card-title">Flash Komutları Üret</span></div>
    <form id="flash-form" class="space-y-4">
      <div class="form-group">
        <label class="form-label">SoC Modeli</label>
        <select name="soc" id="soc-select" class="form-control">
          <option value="">Yükleniyor…</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Flash Boyutu</label>
        <select name="flashSize" class="form-control">
          <option value="8m">8 MB</option>
          <option value="16m">16 MB</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Kamera IP</label>
        <input name="ip" class="form-control" placeholder="192.168.1.200" value="192.168.1.200" />
      </div>
      <button type="button" class="btn btn-primary w-full" onclick="getFlashCommands()">Komutları Üret</button>
    </form>
    <div id="flash-result" class="mt-4 hidden">
      <p class="text-xs text-zinc-500 mb-2 font-medium uppercase tracking-wider">U-Boot Komutları</p>
      <pre id="flash-cmds" class="bg-zinc-950 text-green-400 text-xs p-4 rounded-lg overflow-x-auto font-mono leading-relaxed"></pre>
    </div>
  </div>

  <!-- Version check -->
  <div class="card">
    <div class="card-header"><span class="card-title">Versiyon Kontrolü</span></div>
    <form id="ver-form" class="space-y-4">
      <div class="form-group">
        <label class="form-label">Kamera IP</label>
        <input name="ip" class="form-control" placeholder="192.168.1.200" />
      </div>
      <div class="form-group">
        <label class="form-label">SSH Şifresi</label>
        <input name="password" type="password" class="form-control" placeholder="12345" />
      </div>
      <button type="button" class="btn btn-secondary w-full" onclick="checkVersion()">Versiyonu Kontrol Et</button>
    </form>
    <div id="ver-result" class="mt-4 hidden">
      <pre id="ver-output" class="bg-zinc-950 text-zinc-300 text-xs p-4 rounded-lg overflow-x-auto font-mono"></pre>
    </div>
  </div>

  <!-- Firmware update -->
  <div class="card lg:col-span-2">
    <div class="card-header"><span class="card-title">Uzak Firmware Güncelleme</span></div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="form-group">
        <label class="form-label">Kamera IP</label>
        <input id="upd-ip" class="form-control" placeholder="192.168.1.200" />
      </div>
      <div class="form-group">
        <label class="form-label">SSH Şifresi</label>
        <input id="upd-pass" type="password" class="form-control" />
      </div>
      <div class="form-group">
        <label class="form-label">SoC</label>
        <select id="upd-soc" class="form-control"><option value="">Seçin…</option></select>
      </div>
    </div>
    <button class="btn btn-primary" onclick="updateFirmware()">🚀 Firmware Güncelle</button>
    <div id="upd-result" class="mt-4 hidden">
      <pre id="upd-output" class="bg-zinc-950 text-green-400 text-xs p-4 rounded-lg overflow-x-auto font-mono"></pre>
    </div>
  </div>
</div>

<script>
(async () => {
  try {
    const socs = await App.get('/firmware/soc');
    const list = Array.isArray(socs) ? socs : [];
    const opts = list.map(s => `<option value="${s.value || s}">${s.label || s}</option>`).join('');
    document.getElementById('soc-select').innerHTML = opts || '<option value="">Bulunamadı</option>';
    document.getElementById('upd-soc').innerHTML = '<option value="">Seçin…</option>' + opts;
  } catch(e) {
    document.getElementById('soc-select').innerHTML = '<option value="">Yüklenemedi</option>';
  }
})();

async function getFlashCommands() {
  const fd = new FormData(document.getElementById('flash-form'));
  try {
    const res = await App.post('/firmware/flash-commands', { soc: fd.get('soc'), flashSize: fd.get('flashSize'), ip: fd.get('ip') });
    const cmds = res.commands || res.output || JSON.stringify(res, null, 2);
    document.getElementById('flash-cmds').textContent = cmds;
    document.getElementById('flash-result').classList.remove('hidden');
  } catch(e) { App.toast('Hata: ' + e.message, 'error'); }
}

async function checkVersion() {
  const fd = new FormData(document.getElementById('ver-form'));
  try {
    const res = await App.post('/firmware/version-check', { ip: fd.get('ip'), password: fd.get('password') });
    document.getElementById('ver-output').textContent = JSON.stringify(res, null, 2);
    document.getElementById('ver-result').classList.remove('hidden');
  } catch(e) { App.toast('Hata: ' + e.message, 'error'); }
}

async function updateFirmware() {
  const ip = document.getElementById('upd-ip').value;
  const pass = document.getElementById('upd-pass').value;
  const soc = document.getElementById('upd-soc').value;
  if (!ip || !soc) { App.toast('IP ve SoC gerekli', 'error'); return; }
  try {
    const res = await App.post('/firmware/update', { ip, password: pass, soc });
    document.getElementById('upd-output').textContent = res.output || JSON.stringify(res, null, 2);
    document.getElementById('upd-result').classList.remove('hidden');
    App.toast('Firmware güncelleme başlatıldı', 'success');
  } catch(e) { App.toast('Hata: ' + e.message, 'error'); }
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
