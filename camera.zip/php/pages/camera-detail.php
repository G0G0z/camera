<?php
$pageTitle  = 'Kamera Detay';
$activePage = 'cameras';
require __DIR__ . '/../layout.php';
?>

<div id="cam-header" class="page-header-row page-header">
  <div>
    <a href="/cameras" class="text-xs text-zinc-500 hover:text-zinc-300 mb-1 inline-block">← Kameralar</a>
    <h1 id="cam-name">Yükleniyor…</h1>
    <p id="cam-ip" class="text-zinc-500 text-sm"></p>
  </div>
  <div class="flex gap-2" id="cam-actions"></div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

  <!-- Stream / Snapshot -->
  <div class="lg:col-span-2 card p-0 overflow-hidden">
    <div id="stream-box" class="aspect-video bg-zinc-950 flex items-center justify-center text-zinc-700">
      <div class="skeleton w-full h-full"></div>
    </div>
    <!-- PTZ controls -->
    <div id="ptz-controls" class="hidden p-4 border-t border-zinc-800">
      <p class="text-xs text-zinc-500 mb-3 font-medium uppercase tracking-wider">PTZ Kontrol</p>
      <div class="grid grid-cols-3 gap-2 w-40 mx-auto text-center">
        <div></div>
        <button class="btn btn-secondary btn-sm" onclick="ptz('up')">▲</button>
        <div></div>
        <button class="btn btn-secondary btn-sm" onclick="ptz('left')">◀</button>
        <button class="btn btn-secondary btn-sm" onclick="ptz('home')">⌂</button>
        <button class="btn btn-secondary btn-sm" onclick="ptz('right')">▶</button>
        <div></div>
        <button class="btn btn-secondary btn-sm" onclick="ptz('down')">▼</button>
        <div></div>
      </div>
      <div class="flex justify-center gap-2 mt-2">
        <button class="btn btn-secondary btn-sm" onclick="ptz('zoom_in')">🔍+</button>
        <button class="btn btn-secondary btn-sm" onclick="ptz('zoom_out')">🔍−</button>
      </div>
    </div>
  </div>

  <!-- Info + actions -->
  <div class="space-y-4">
    <div class="card" id="cam-info-card">
      <div class="skeleton h-48 rounded-lg"></div>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">İşlemler</span></div>
      <div class="space-y-2">
        <button class="btn btn-secondary w-full justify-start" onclick="refreshSnapshot()">
          📸 Anlık Görüntü Yenile
        </button>
        <button class="btn btn-secondary w-full justify-start" onclick="openEditModal()">
          ✏️ Kamera Düzenle
        </button>
        <button class="btn btn-danger w-full justify-start" onclick="deleteCamera()">
          🗑 Kamerayı Sil
        </button>
      </div>
    </div>
  </div>
</div>

<script>
const camId = parseInt(location.pathname.split('/').pop());
let camData = null;

async function loadCamera() {
  try {
    camData = await App.get('/cameras/' + camId);
    document.getElementById('cam-name').textContent = camData.name;
    document.getElementById('cam-ip').textContent   = camData.ip + (camData.location ? ' — ' + camData.location : '');
    document.getElementById('cam-info-card').innerHTML = `
      <div class="space-y-3">
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">Durum</span>${App.statusBadge(camData.status)}</div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">IP</span><span class="text-sm font-mono">${camData.ip}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">RTSP Port</span><span class="text-sm font-mono">${camData.rtspPort || 554}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">PTZ</span><span class="text-sm">${camData.ptzEnabled ? '✅ Aktif' : '❌ Pasif'}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">Kayıt</span><span class="text-sm">${camData.recordingEnabled ? '🔴 Aktif' : '⬛ Pasif'}</span></div>
        ${camData.location ? `<div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">Konum</span><span class="text-sm">${camData.location}</span></div>` : ''}
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-sm">Eklenme</span><span class="text-xs text-zinc-500">${App.fmtDate(camData.createdAt)}</span></div>
      </div>`;
    if (camData.ptzEnabled) document.getElementById('ptz-controls').classList.remove('hidden');
    loadSnapshot();
  } catch(e) {
    App.toast('Kamera yüklenemedi: ' + e.message, 'error');
  }
}

async function loadSnapshot() {
  const box = document.getElementById('stream-box');
  try {
    const snap = await App.get('/cameras/' + camId + '/snapshot');
    if (snap?.url) {
      box.innerHTML = `<img src="${snap.url}" class="w-full h-full object-contain" />`;
    } else {
      box.innerHTML = `<div class="text-center text-zinc-600"><p class="text-4xl mb-2">📷</p><p class="text-sm">Sinyal yok</p></div>`;
    }
  } catch(e) {
    box.innerHTML = `<div class="text-center text-zinc-600"><p class="text-4xl mb-2">📷</p><p class="text-sm">Anlık görüntü alınamadı</p></div>`;
  }
}

function refreshSnapshot() { loadSnapshot(); App.toast('Yenilendi', 'info'); }

async function ptz(dir) {
  try { await App.post('/cameras/' + camId + '/ptz', { action: dir }); }
  catch(e) { App.toast('PTZ hatası: ' + e.message, 'error'); }
}

function openEditModal() {
  if (!camData) return;
  App.openModal(`
    <div class="modal-header"><h3>Kamera Düzenle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <form id="edit-cam-form">
        <div class="form-group"><label class="form-label">Kamera Adı</label><input name="name" class="form-control" value="${camData.name||''}" required /></div>
        <div class="form-group"><label class="form-label">IP Adresi</label><input name="ip" class="form-control" value="${camData.ip||''}" required /></div>
        <div class="form-group"><label class="form-label">RTSP Port</label><input name="rtspPort" type="number" class="form-control" value="${camData.rtspPort||554}" /></div>
        <div class="form-group"><label class="form-label">Kullanıcı Adı</label><input name="username" class="form-control" value="${camData.username||''}" /></div>
        <div class="form-group"><label class="form-label">Şifre (boş = değiştirme)</label><input name="password" type="password" class="form-control" /></div>
        <div class="form-group"><label class="form-label">Konum</label><input name="location" class="form-control" value="${camData.location||''}" /></div>
        <div id="edit-cam-err" class="text-red-400 text-sm hidden"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitEditCamera()">Kaydet</button>
    </div>`);
}

async function submitEditCamera() {
  const fd  = new FormData(document.getElementById('edit-cam-form'));
  const err = document.getElementById('edit-cam-err');
  const body = { name: fd.get('name'), ip: fd.get('ip'), rtspPort: parseInt(fd.get('rtspPort')||'554'), username: fd.get('username'), location: fd.get('location') };
  if (fd.get('password')) body.password = fd.get('password');
  try {
    await App.put('/cameras/' + camId, body);
    App.closeModal(); App.toast('Kamera güncellendi', 'success'); loadCamera();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

async function deleteCamera() {
  App.confirm('Bu kamerayı silmek istediğinize emin misiniz?', async () => {
    try { await App.del('/cameras/' + camId); App.toast('Kamera silindi', 'success'); setTimeout(() => location.href = '/cameras', 800); }
    catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

loadCamera();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
