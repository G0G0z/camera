<?php
$pageTitle  = 'Kamera Detay';
$activePage = 'cameras';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <a href="/cameras" class="text-xs text-zinc-500 hover:text-zinc-300 mb-1 inline-block">← Kameralar</a>
    <h1 id="cam-name">Yükleniyor…</h1>
    <p id="cam-ip" class="text-zinc-500 text-sm"></p>
  </div>
  <div class="flex gap-2 flex-wrap" id="cam-actions">
    <span id="cam-status-badge"></span>
  </div>
</div>

<div class="grid grid-cols-1 xl:grid-cols-3 gap-4">

  <!-- ── Sol: Stream + PTZ ────────────────────────────────────────────────── -->
  <div class="xl:col-span-2 space-y-4">

    <!-- Stream -->
    <div class="card p-0 overflow-hidden">
      <div id="stream-box" class="aspect-video bg-zinc-950 flex items-center justify-center">
        <div class="skeleton w-full h-full"></div>
      </div>
      <div class="p-3 flex items-center gap-2 border-t border-zinc-800">
        <button class="btn btn-secondary btn-sm" onclick="refreshSnapshot()">📸 Yenile</button>
        <button class="btn btn-secondary btn-sm" id="btn-autorefresh" onclick="toggleAutoRefresh()">⏱ Oto-Yenile</button>
        <span id="snap-time" class="text-xs text-zinc-600 ml-auto"></span>
      </div>
    </div>

    <!-- PTZ Panel (sadece PTZ kameralarda) -->
    <div id="ptz-panel" class="card hidden">
      <div class="tab-bar" id="ptz-tabs">
        <button class="tab-btn" data-tab="tab-dpad">Yön Kontrolü</button>
        <button class="tab-btn" data-tab="tab-optics">Optik</button>
        <button class="tab-btn" data-tab="tab-presets">Presetler</button>
        <button class="tab-btn" data-tab="tab-patrol">Devriye</button>
      </div>

      <!-- Tab: Yön Kontrolü -->
      <div class="tab-panel" id="tab-dpad">
        <div class="flex flex-col sm:flex-row gap-6 items-start">

          <!-- D-pad -->
          <div class="flex flex-col items-center gap-3">
            <div class="ptz-dpad">
              <div></div>
              <button class="ptz-btn" id="btn-up"         data-dir="up">▲</button>
              <div></div>
              <button class="ptz-btn" id="btn-left"       data-dir="left">◀</button>
              <button class="ptz-btn center" id="btn-home" onclick="ptz('home')">⌂</button>
              <button class="ptz-btn" id="btn-right"      data-dir="right">▶</button>
              <div></div>
              <button class="ptz-btn" id="btn-down"       data-dir="down">▼</button>
              <div></div>
            </div>
            <!-- Zoom -->
            <div class="flex gap-2">
              <button class="ptz-btn" id="btn-zoom-in"  data-dir="zoom_in"  title="Zoom +">🔍+</button>
              <button class="ptz-btn" id="btn-zoom-out" data-dir="zoom_out" title="Zoom −">🔍−</button>
            </div>
          </div>

          <!-- Hız + Ev konumu -->
          <div class="flex-1 space-y-4 min-w-[180px]">
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-xs text-zinc-500">Hız</span>
                <span class="text-xs text-zinc-400" id="speed-val">50%</span>
              </div>
              <input type="range" min="1" max="100" value="50" id="ptz-speed" oninput="updateSpeed(this.value)" />
            </div>
            <div class="space-y-2">
              <button class="btn btn-secondary btn-sm w-full" onclick="ptz('set_home')">
                📌 Mevcut Konumu Ev Yap
              </button>
              <button class="btn btn-secondary btn-sm w-full" onclick="ptz('stop')">
                ⏹ Durdur
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab: Optik -->
      <div class="tab-panel" id="tab-optics">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

          <!-- Focus -->
          <div>
            <p class="text-xs text-zinc-500 uppercase tracking-wider mb-3 font-semibold">Odak (Focus)</p>
            <div class="flex gap-2 mb-3">
              <button class="ptz-btn flex-1" id="btn-focus-near" data-dir="focus_near" title="Yakın odak">◀ Yakın</button>
              <button class="ptz-btn flex-1" id="btn-focus-far"  data-dir="focus_far"  title="Uzak odak">Uzak ▶</button>
            </div>
            <button class="btn btn-secondary btn-sm w-full" onclick="ptz('auto_focus')">
              🎯 Oto-Odak
            </button>
          </div>

          <!-- Iris -->
          <div>
            <p class="text-xs text-zinc-500 uppercase tracking-wider mb-3 font-semibold">Diyafram (Iris)</p>
            <div class="flex gap-2 mb-3">
              <button class="ptz-btn flex-1" id="btn-iris-close" data-dir="iris_close" title="Diyafram kapat">◀ Kapat</button>
              <button class="ptz-btn flex-1" id="btn-iris-open"  data-dir="iris_open"  title="Diyafram aç">Aç ▶</button>
            </div>
            <button class="btn btn-secondary btn-sm w-full" onclick="ptz('iris_stop')">
              ⏹ Durdur
            </button>
          </div>
        </div>
        <p class="text-xs text-zinc-600 mt-4">* Basılı tut = sürekli hareket. Bırak = durdur.</p>
      </div>

      <!-- Tab: Presetler -->
      <div class="tab-panel" id="tab-presets">
        <div id="preset-list" class="flex flex-wrap gap-2 mb-4 min-h-[40px]">
          <div class="skeleton h-8 w-24 rounded-full"></div>
          <div class="skeleton h-8 w-20 rounded-full"></div>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="openAddPreset()">+ Preset Ekle</button>
        <p class="text-xs text-zinc-600 mt-2">Çipi tıkla → o konuma git. Çöp kutusu → sil.</p>
      </div>

      <!-- Tab: Devriye -->
      <div class="tab-panel" id="tab-patrol">
        <div id="patrol-cam-list" class="space-y-2 mb-4"></div>
        <button class="btn btn-secondary btn-sm" onclick="openAddPatrol()">+ Yeni Devriye Rotası</button>
        <p class="text-xs text-zinc-600 mt-2">Devriye tarayıcıda çalışır — bu sekmeyi açık bırakın.</p>
      </div>
    </div>

  </div>

  <!-- ── Sağ: Bilgi + İşlemler ───────────────────────────────────────────── -->
  <div class="space-y-4">

    <!-- Kamera Bilgisi -->
    <div class="card" id="cam-info-card">
      <div class="skeleton h-52 rounded-lg"></div>
    </div>

    <!-- Sistem İstatistikleri -->
    <div class="card" id="sys-stats-card" style="display:none">
      <div class="card-header"><span class="card-title">Sistem</span></div>
      <div id="sys-stats-body" class="space-y-2 text-sm"></div>
    </div>

    <!-- İşlemler -->
    <div class="card">
      <div class="card-header"><span class="card-title">İşlemler</span></div>
      <div class="space-y-2">
        <button class="btn btn-secondary w-full justify-start text-sm" onclick="refreshSnapshot()">
          📸 Anlık Görüntü Yenile
        </button>
        <button class="btn btn-secondary w-full justify-start text-sm" onclick="openEditModal()">
          ✏️ Kamera Düzenle
        </button>
        <a href="/monitor" class="btn btn-secondary w-full justify-start text-sm" style="text-decoration:none">
          🖥 Canlı İzleme Ekranı
        </a>
        <button class="btn btn-danger w-full justify-start text-sm" onclick="deleteCamera()">
          🗑 Kamerayı Sil
        </button>
      </div>
    </div>

  </div>
</div>

<script>
const camId = parseInt(location.pathname.split('/').pop());
let camData = null;
let ptzSpeed = 0.5;
let autoRefreshTimer = null;

// ── Kamera yükleme ──────────────────────────────────────────────────────────
async function loadCamera() {
  try {
    camData = await App.get('/cameras/' + camId);
    document.getElementById('cam-name').textContent = camData.name;
    document.getElementById('cam-ip').textContent   = camData.ip + (camData.location ? ' — ' + camData.location : '');
    document.getElementById('cam-status-badge').innerHTML = App.statusBadge(camData.status);

    // Info card
    document.getElementById('cam-info-card').innerHTML = `
      <div class="card-header"><span class="card-title">Kamera Bilgisi</span></div>
      <div class="space-y-2.5">
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">Durum</span>${App.statusBadge(camData.status)}</div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">IP</span><span class="text-xs font-mono">${camData.ip}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">ONVIF Port</span><span class="text-xs font-mono">${camData.onvifPort||80}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">RTSP Port</span><span class="text-xs font-mono">${camData.rtspPort||554}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">PTZ</span><span class="text-xs">${camData.ptzEnabled?'✅ Aktif':'❌ Pasif'}</span></div>
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">Kayıt</span><span class="text-xs">${camData.recordingEnabled?'🔴 Aktif':'⬛ Pasif'}</span></div>
        ${camData.location?`<div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">Konum</span><span class="text-xs">${camData.location}</span></div>`:''}
        ${camData.firmware?`<div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">Firmware</span><span class="text-xs font-mono">${camData.firmware}</span></div>`:''}
        <div class="flex justify-between items-center"><span class="text-zinc-500 text-xs">Eklenme</span><span class="text-xs text-zinc-500">${App.fmtDate(camData.createdAt)}</span></div>
      </div>`;

    // Sistem istatistikleri (heartbeat'ten gelen)
    if (camData.memFreeKb || camData.uptimeS || camData.diskFreeKb) {
      const sys = document.getElementById('sys-stats-card');
      sys.style.display = '';
      document.getElementById('sys-stats-body').innerHTML = `
        ${camData.uptimeS ? `<div class="flex justify-between"><span class="text-zinc-500 text-xs">Uptime</span><span class="text-xs">${App.fmtDuration(camData.uptimeS)}</span></div>` : ''}
        ${camData.memFreeKb ? `<div class="flex justify-between"><span class="text-zinc-500 text-xs">Boş RAM</span><span class="text-xs">${Math.round(camData.memFreeKb/1024)} MB</span></div>` : ''}
        ${camData.diskFreeKb ? `<div class="flex justify-between"><span class="text-zinc-500 text-xs">Boş Disk</span><span class="text-xs">${Math.round(camData.diskFreeKb/1024)} MB</span></div>` : ''}`;
    }

    // PTZ paneli
    if (camData.ptzEnabled) {
      document.getElementById('ptz-panel').classList.remove('hidden');
      App.initTabs(document.getElementById('ptz-panel'));
      setupPtzButtons();
      loadPresets();
      loadPatrols();
    }

    loadSnapshot();
  } catch(e) {
    App.toast('Kamera yüklenemedi: ' + e.message, 'error');
  }
}

// ── Snapshot ────────────────────────────────────────────────────────────────
async function loadSnapshot() {
  const box = document.getElementById('stream-box');
  try {
    const snap = await App.get('/cameras/' + camId + '/snapshot');
    if (snap?.url) {
      box.innerHTML = `<img src="${snap.url}?t=${Date.now()}" class="w-full h-full object-contain" />`;
      document.getElementById('snap-time').textContent = 'Son: ' + new Date().toLocaleTimeString('tr-TR');
    } else {
      box.innerHTML = noSignal();
    }
  } catch(e) {
    box.innerHTML = noSignal();
  }
}

function noSignal() {
  return `<div class="text-center text-zinc-600"><p class="text-4xl mb-2">📷</p><p class="text-sm">Sinyal yok</p></div>`;
}

function refreshSnapshot() { loadSnapshot(); }

function toggleAutoRefresh() {
  const btn = document.getElementById('btn-autorefresh');
  if (autoRefreshTimer) {
    clearInterval(autoRefreshTimer);
    autoRefreshTimer = null;
    btn.classList.remove('btn-active');
    btn.textContent = '⏱ Oto-Yenile';
  } else {
    autoRefreshTimer = setInterval(loadSnapshot, 5000);
    btn.classList.add('btn-active');
    btn.textContent = '⏱ Oto (5sn)';
    App.toast('Oto-yenileme açık (5sn)', 'info');
  }
}

// ── PTZ ─────────────────────────────────────────────────────────────────────
function updateSpeed(v) {
  ptzSpeed = v / 100;
  document.getElementById('speed-val').textContent = v + '%';
}

async function ptz(dir) {
  try { await App.post('/cameras/' + camId + '/ptz', { action: dir, speed: ptzSpeed }); }
  catch(e) { App.toast('PTZ: ' + e.message, 'error'); }
}

// Hold-to-move butonlar (mousedown → hareket, mouseup/leave → durdur)
function setupPtzButtons() {
  const holdDirs = ['up','down','left','right','zoom_in','zoom_out','focus_near','focus_far','iris_open','iris_close'];
  holdDirs.forEach(dir => {
    const btn = document.getElementById('btn-' + dir.replace('_','-'));
    if (!btn) return;
    let active = false;
    const go   = async () => { if (active) return; active = true; btn.classList.add('pressing'); await ptz(dir); };
    const stop = async () => { if (!active) return; active = false; btn.classList.remove('pressing'); await ptz('stop'); };
    btn.addEventListener('mousedown', go);
    btn.addEventListener('mouseup',   stop);
    btn.addEventListener('mouseleave',stop);
    btn.addEventListener('touchstart', e => { e.preventDefault(); go(); }, { passive: false });
    btn.addEventListener('touchend',   e => { e.preventDefault(); stop(); });
  });
}

// ── Presetler ────────────────────────────────────────────────────────────────
let presets = [];

async function loadPresets() {
  try {
    presets = await App.get('/cameras/' + camId + '/ptz/presets');
    renderPresets();
  } catch(e) { App.toast('Presetler yüklenemedi', 'error'); }
}

function renderPresets() {
  const el = document.getElementById('preset-list');
  if (!presets.length) {
    el.innerHTML = '<p class="text-xs text-zinc-600">Henüz preset eklenmemiş.</p>';
    return;
  }
  el.innerHTML = presets.map(p => `
    <div class="preset-chip" onclick="gotoPreset(${p.id})">
      <span>${p.icon||'📍'}</span>
      <span>${p.name}</span>
      <span class="del" onclick="event.stopPropagation();deletePreset(${p.id})" title="Sil">✕</span>
    </div>`).join('');
}

async function gotoPreset(id) {
  try { await App.post(`/cameras/${camId}/ptz/presets/${id}/goto`, {}); App.toast('Preset konumuna gidiliyor…', 'info'); }
  catch(e) { App.toast('Hata: ' + e.message, 'error'); }
}

function deletePreset(id) {
  App.confirm('Bu preset silinsin mi?', async () => {
    try {
      await App.del(`/cameras/${camId}/ptz/presets/${id}`);
      presets = presets.filter(p => p.id !== id);
      renderPresets();
      App.toast('Preset silindi', 'success');
    } catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

function openAddPreset() {
  App.openModal(`
    <div class="modal-header"><h3>Preset Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <p class="text-xs text-zinc-500 mb-4">Kamerayı istediğiniz konuma götürün, sonra preset kaydedin.</p>
      <div class="form-group">
        <label class="form-label">Preset Adı</label>
        <input id="preset-name" class="form-control" placeholder="Giriş Kapısı" />
      </div>
      <div class="form-group">
        <label class="form-label">İkon</label>
        <div class="flex gap-2 flex-wrap" id="icon-picker">
          ${['📍','🏠','🚪','🅿','🏢','📦','🌳','⚠️','🎯','🔴'].map(ic =>
            `<button class="ptz-btn" onclick="selectIcon('${ic}')" id="icon-${ic}">${ic}</button>`
          ).join('')}
        </div>
        <input type="hidden" id="preset-icon" value="📍" />
      </div>
      <div id="preset-err" class="text-red-400 text-xs hidden"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="savePreset()">Kaydet</button>
    </div>`);
}

function selectIcon(ic) {
  document.getElementById('preset-icon').value = ic;
  document.querySelectorAll('#icon-picker .ptz-btn').forEach(b => b.classList.remove('btn-active'));
  document.getElementById('icon-' + ic)?.classList.add('btn-active');
}

async function savePreset() {
  const name = document.getElementById('preset-name').value.trim();
  const icon = document.getElementById('preset-icon').value;
  const err  = document.getElementById('preset-err');
  if (!name) { err.textContent = 'Ad giriniz'; err.classList.remove('hidden'); return; }
  try {
    const p = await App.post(`/cameras/${camId}/ptz/presets`, { name, icon });
    presets.push(p);
    renderPresets();
    App.closeModal();
    App.toast('Preset kaydedildi', 'success');
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

// ── Devriye (patrol) ─────────────────────────────────────────────────────────
let patrols = [];

async function loadPatrols() {
  try {
    const all = await App.get('/patrols');
    patrols = all.filter(p => p.cameraId === camId);
    renderPatrols();
  } catch(e) {}
}

function renderPatrols() {
  const el = document.getElementById('patrol-cam-list');
  if (!patrols.length) {
    el.innerHTML = '<p class="text-xs text-zinc-600">Bu kamera için devriye rotası yok.</p>';
    return;
  }
  el.innerHTML = patrols.map(p => {
    const running = PatrolEngine.isRunning(p.id);
    const presetNames = p.presetIds.map(id => {
      const pr = presets.find(x => x.id === id);
      return pr ? pr.name : '#' + id;
    }).join(' → ');
    return `<div class="flex items-center justify-between gap-2 p-2 bg-zinc-800/50 rounded-lg">
      <div class="min-w-0">
        <p class="text-xs font-medium text-zinc-200">${p.name}</p>
        <p class="text-[10px] text-zinc-500 truncate">${presetNames || 'Preset yok'} · ${p.dwellSeconds}sn bekleme</p>
      </div>
      <div class="flex gap-1 shrink-0">
        ${running
          ? `<button class="btn btn-warning btn-xs patrol-running" onclick="stopPatrol(${p.id},'${p.name}')">⏹ Dur</button>`
          : `<button class="btn btn-success btn-xs" onclick="startPatrol(${p.id})">▶ Başlat</button>`}
        <button class="btn btn-ghost btn-xs text-red-400" onclick="deletePatrol(${p.id})">✕</button>
      </div>
    </div>`;
  }).join('');
}

function startPatrol(id) {
  const p = patrols.find(x => x.id === id);
  if (!p) return;
  PatrolEngine.start(p, () => renderPatrols());
  renderPatrols();
}
function stopPatrol(id, name) {
  PatrolEngine.stop(id, name);
  renderPatrols();
}
async function deletePatrol(id) {
  App.confirm('Devriye rotası silinsin mi?', async () => {
    try {
      await App.del('/patrols/' + id);
      PatrolEngine.stop(id);
      patrols = patrols.filter(p => p.id !== id);
      renderPatrols();
    } catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

function openAddPatrol() {
  if (!presets.length) { App.toast('Önce preset ekleyin', 'error'); return; }
  App.openModal(`
    <div class="modal-header"><h3>Devriye Rotası Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Rota Adı</label>
        <input id="p-name" class="form-control" placeholder="Gece Devriyesi" />
      </div>
      <div class="form-group">
        <label class="form-label">Presetler (sırayla seç)</label>
        <div id="p-presets" class="flex flex-wrap gap-2">
          ${presets.map(pr => `<label class="preset-chip"><input type="checkbox" value="${pr.id}" style="margin-right:4px">${pr.icon||'📍'} ${pr.name}</label>`).join('')}
        </div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div class="form-group">
          <label class="form-label">Her konumda bekleme (sn)</label>
          <input id="p-dwell" type="number" class="form-control" value="10" min="3" />
        </div>
        <div class="form-group">
          <label class="form-label">Hız (0.1–1.0)</label>
          <input id="p-speed" type="number" class="form-control" value="0.5" min="0.1" max="1" step="0.1" />
        </div>
      </div>
      <div id="p-err" class="text-red-400 text-xs hidden"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="savePatrol()">Kaydet</button>
    </div>`);
}

async function savePatrol() {
  const name  = document.getElementById('p-name').value.trim();
  const boxes = document.querySelectorAll('#p-presets input:checked');
  const presetIds = Array.from(boxes).map(b => parseInt(b.value));
  const dwell = parseInt(document.getElementById('p-dwell').value) || 10;
  const speed = parseFloat(document.getElementById('p-speed').value) || 0.5;
  const err   = document.getElementById('p-err');
  if (!name)              { err.textContent = 'Ad giriniz'; err.classList.remove('hidden'); return; }
  if (!presetIds.length)  { err.textContent = 'En az 1 preset seçin'; err.classList.remove('hidden'); return; }
  try {
    const p = await App.post('/patrols', { cameraId: camId, name, presetIds, dwellSeconds: dwell, speed });
    patrols.push(p);
    renderPatrols();
    App.closeModal();
    App.toast('Devriye rotası eklendi', 'success');
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

// ── Düzenleme / Silme ─────────────────────────────────────────────────────────
function openEditModal() {
  if (!camData) return;
  App.openModal(`
    <div class="modal-header"><h3>Kamera Düzenle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <form id="edit-cam-form">
        <div class="form-group"><label class="form-label">Kamera Adı</label><input name="name" class="form-control" value="${camData.name||''}" required /></div>
        <div class="form-group"><label class="form-label">IP Adresi</label><input name="ip" class="form-control" value="${camData.ip||''}" required /></div>
        <div class="grid grid-cols-2 gap-3">
          <div class="form-group"><label class="form-label">ONVIF Port</label><input name="onvifPort" type="number" class="form-control" value="${camData.onvifPort||80}" /></div>
          <div class="form-group"><label class="form-label">RTSP Port</label><input name="rtspPort" type="number" class="form-control" value="${camData.rtspPort||554}" /></div>
        </div>
        <div class="form-group"><label class="form-label">Kullanıcı Adı</label><input name="username" class="form-control" value="${camData.username||''}" /></div>
        <div class="form-group"><label class="form-label">Şifre (boş = değiştirme)</label><input name="password" type="password" class="form-control" /></div>
        <div class="form-group"><label class="form-label">Konum</label><input name="location" class="form-control" value="${camData.location||''}" /></div>
        <div id="edit-cam-err" class="text-red-400 text-sm hidden"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitEditCamera()">Kaydet</button>
    </div>`);
}

async function submitEditCamera() {
  const fd  = new FormData(document.getElementById('edit-cam-form'));
  const err = document.getElementById('edit-cam-err');
  const body = { name: fd.get('name'), ip: fd.get('ip'), onvifPort: parseInt(fd.get('onvifPort')||'80'), rtspPort: parseInt(fd.get('rtspPort')||'554'), username: fd.get('username'), location: fd.get('location') };
  if (fd.get('password')) body.password = fd.get('password');
  try {
    await App.put('/cameras/' + camId, body);
    App.closeModal(); App.toast('Güncellendi', 'success'); loadCamera();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

async function deleteCamera() {
  App.confirm('Bu kamerayı silmek istediğinize emin misiniz?', async () => {
    try { await App.del('/cameras/' + camId); App.toast('Kamera silindi', 'success'); setTimeout(() => location.href = '/cameras', 800); }
    catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

loadCamera();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
