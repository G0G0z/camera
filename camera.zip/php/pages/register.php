<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Kayıt Ol — OpticSight PTZ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="/assets/app.css" />
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen flex items-center justify-center p-4">

<div class="w-full max-w-sm">
  <div class="text-center mb-8">
    <div class="inline-flex items-center gap-2 text-xl font-bold mb-1">
      <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
      OpticSight PTZ
    </div>
    <p class="text-zinc-500 text-sm">Yeni hesap oluşturun</p>
  </div>

  <div class="card">
    <form id="reg-form" class="space-y-4">
      <div class="form-group">
        <label class="form-label">Ad Soyad</label>
        <input type="text" name="name" class="form-control" placeholder="Ahmet Yılmaz" required autofocus />
      </div>
      <div class="form-group">
        <label class="form-label">E-posta</label>
        <input type="email" name="email" class="form-control" placeholder="admin@ornek.com" required />
      </div>
      <div class="form-group">
        <label class="form-label">Şirket / Müşteri Adı</label>
        <input type="text" name="companyName" class="form-control" placeholder="OpticSight Güvenlik" required />
      </div>
      <div class="form-group mb-0">
        <label class="form-label">Şifre</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" required minlength="6" />
      </div>
      <div id="reg-error" class="text-red-400 text-sm hidden"></div>
      <button type="submit" id="reg-btn" class="btn btn-primary w-full justify-center mt-2">Kayıt Ol</button>
    </form>
  </div>

  <p class="text-center text-sm text-zinc-500 mt-4">
    Zaten hesabınız var mı?
    <a href="/login" class="text-blue-400 hover:underline">Giriş Yap</a>
  </p>
</div>

<div id="toast-container" class="fixed bottom-4 right-4 z-50 space-y-2 pointer-events-none"></div>
<script src="/assets/app.js"></script>
<script>
document.getElementById('reg-form').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = document.getElementById('reg-btn');
  const err = document.getElementById('reg-error');
  const fd  = new FormData(e.target);
  btn.disabled = true; btn.textContent = 'Kaydediliyor…';
  err.classList.add('hidden');
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        name: fd.get('name'),
        email: fd.get('email'),
        password: fd.get('password'),
        companyName: fd.get('companyName'),
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || data.message || 'Kayıt başarısız');
    await fetch('/auth/session', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ token: data.token, user: data.user }),
    });
    localStorage.setItem('os_token', data.token);
    window.location.href = '/';
  } catch (ex) {
    err.textContent = ex.message;
    err.classList.remove('hidden');
    btn.disabled = false; btn.textContent = 'Kayıt Ol';
  }
});
</script>
</body>
</html>
