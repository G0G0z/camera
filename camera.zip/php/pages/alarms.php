<?php
$pageTitle  = 'Alarm Kuralları';
$activePage = 'alarms';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>🔔 Alarm Kuralları</h1>
    <p>Olay tespitinde ses ve bildirim yönetimi</p>
  </div>
  <div class="flex gap-2 flex-wrap">
    <button class="btn btn-secondary btn-sm" onclick="testSound()">🔊 Ses Test</button>
    <button class="btn btn-primary btn-sm" onclick="openAddAlarm()">+ Kural Ekle</button>
  </div>
</div>

<!-- Ses test paneli -->
<div class="card mb-4">
  <div class="card-header"><span class="card-title">Ses Önizleme</span></div>
  <div class="flex gap-3 flex-wrap items-center">
    <button class="btn btn-secondary btn-sm" onclick="AudioManager.preview('beep')">🔔 Bip</button>
    <button class="btn btn-secondary btn-sm" onclick="AudioManager.preview('double_beep')">🔔🔔 Çift Bip</button>
    <button class="btn btn-secondary btn-sm" onclick="AudioManager.preview('siren')">🚨 Siren</button>
    <button class="btn btn-secondary btn-sm" onclick="AudioManager.preview('voice')">🗣 Sesli Uyarı</button>
    <p class="text-xs text-zinc-500 ml-auto">Alarm seslerini cihaz sesini açık tutarak dinleyin.</p>
  </div>
</div>

<!-- Kural listesi -->
<div class="card">
  <div class="card-header">
    <span class="card-title">Kurallar</span>
    <span id="rule-count" class="badge badge-zinc">0 kural</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Ad</th>
          <th>Kamera</th>
          <th>Olay Türü</th>
          <th>Ses</th>
          <th>Bekleme</th>
          <th>Durum</th>
          <th></th>
        </tr>
      </thead>
      <tbody id="alarm-tbody">
        <tr><?= '<td colspan="7">' ?><div class="skeleton h-4"></div></td></tr>
      </tbody>
    </table>
  </div>
</div>

<script>
let rules   = [];
let cameras = [];

const soundLabels = { none:'Sessiz', beep:'🔔 Bip', double_beep:'🔔🔔 Çift Bip', siren:'🚨 Siren', voice:'🗣 Sesli' };
const typeLabels  = { '':'Tüm Olaylar', motion:'📡 Hareket', person:'👤 Kişi', vehicle:'🚗 Araç', face:'🎭 Yüz', tamper:'⚠️ Oynamak' };

async function load() {
  try {
    [rules, cameras] = await Promise.all([ App.get('/alarms'), App.get('/cameras') ]);
    render();
  } catch(e) { App.toast('Yüklenemedi: ' + e.message, 'error'); }
}

function camName(id) {
  if (!id) return '<span class="text-zinc-500 text-xs">Tüm Kameralar</span>';
  const c = cameras.find(x => x.id === id);
  return c ? c.name : '#' + id;
}

function render() {
  document.getElementById('rule-count').textContent = rules.length + ' kural';
  const tbody = document.getElementById('alarm-tbody');
  if (!rules.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-zinc-500 py-8">Henüz alarm kuralı yok.<br><small>+ Kural Ekle butonunu kullanın.</small></td></tr>';
    return;
  }
  tbody.innerHTML = rules.map(r => `
    <tr>
      <td class="font-medium">${r.name}</td>
      <td class="text-sm">${camName(r.cameraId)}</td>
      <td>${typeLabels[r.eventType] || r.eventType || '—'}</td>
      <td class="text-sm">${soundLabels[r.sound] || r.sound}</td>
      <td class="text-xs text-zinc-500">${r.cooldownSeconds}sn</td>
      <td>
        <label class="toggle">
          <input type="checkbox" ${r.enabled?'checked':''} onchange="toggleRule(${r.id}, this.checked)">
          <span class="toggle-slider"></span>
        </label>
      </td>
      <td class="flex gap-1">
        <button class="btn btn-ghost btn-xs" onclick="openEditAlarm(${r.id})">✏️</button>
        <button class="btn btn-ghost btn-xs text-red-400" onclick="deleteRule(${r.id})">🗑</button>
      </td>
    </tr>`).join('');
}

async function toggleRule(id, enabled) {
  try {
    await App.put('/alarms/' + id, { enabled });
    const r = rules.find(x => x.id === id);
    if (r) r.enabled = enabled;
    AlarmEngine.reload();
  } catch(e) { App.toast('Güncellenemedi', 'error'); }
}

function ruleModal(rule) {
  const camOpts = ['<option value="0">Tüm Kameralar</option>',
    ...cameras.map(c => `<option value="${c.id}" ${rule?.cameraId===c.id?'selected':''}>${c.name}</option>`)
  ].join('');
  const typeOpts = Object.entries(typeLabels).map(([v,l]) => `<option value="${v}" ${rule?.eventType===v?'selected':''}>${l}</option>`).join('');
  const soundOpts = Object.entries(soundLabels).map(([v,l]) => `<option value="${v}" ${rule?.sound===v?'selected':''}>${l}</option>`).join('');
  return `
    <div class="form-group">
      <label class="form-label">Kural Adı</label>
      <input id="a-name" class="form-control" value="${rule?.name||'Alarm Kuralı'}" />
    </div>
    <div class="form-group">
      <label class="form-label">Kamera</label>
      <select id="a-cam" class="form-control">${camOpts}</select>
    </div>
    <div class="form-group">
      <label class="form-label">Olay Türü</label>
      <select id="a-type" class="form-control">${typeOpts}</select>
    </div>
    <div class="form-group">
      <label class="form-label">Ses</label>
      <select id="a-sound" class="form-control" onchange="AudioManager.preview(this.value)">${soundOpts}</select>
    </div>
    <div class="form-group">
      <label class="form-label">Bekleme süresi (sn) — aynı kuralın tekrar çalması için</label>
      <input id="a-cool" type="number" class="form-control" value="${rule?.cooldownSeconds||60}" min="0" />
    </div>
    <div id="a-err" class="text-red-400 text-xs hidden"></div>`;
}

function openAddAlarm() {
  App.openModal(`
    <div class="modal-header"><h3>Alarm Kuralı Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">${ruleModal(null)}</div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="saveAlarm(null)">Ekle</button>
    </div>`);
}

function openEditAlarm(id) {
  const r = rules.find(x => x.id === id);
  App.openModal(`
    <div class="modal-header"><h3>Alarm Kuralı Düzenle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">${ruleModal(r)}</div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="saveAlarm(${id})">Kaydet</button>
    </div>`);
}

async function saveAlarm(id) {
  const body = {
    name:            document.getElementById('a-name').value.trim(),
    cameraId:        parseInt(document.getElementById('a-cam').value),
    eventType:       document.getElementById('a-type').value,
    sound:           document.getElementById('a-sound').value,
    cooldownSeconds: parseInt(document.getElementById('a-cool').value)||60,
    enabled:         true,
  };
  const err = document.getElementById('a-err');
  try {
    if (id) {
      const updated = await App.put('/alarms/' + id, body);
      const idx = rules.findIndex(x => x.id === id);
      if (idx >= 0) rules[idx] = updated;
    } else {
      const r = await App.post('/alarms', body);
      rules.push(r);
    }
    render();
    App.closeModal();
    AlarmEngine.reload();
    App.toast(id ? 'Güncellendi' : 'Alarm kuralı eklendi', 'success');
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

function deleteRule(id) {
  App.confirm('Bu alarm kuralını silmek istediğinize emin misiniz?', async () => {
    try {
      await App.del('/alarms/' + id);
      rules = rules.filter(r => r.id !== id);
      render();
      AlarmEngine.reload();
      App.toast('Silindi', 'success');
    } catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

function testSound() {
  AudioManager.preview('double_beep');
  App.toast('🔊 Çift bip çalındı', 'info');
}

load();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
