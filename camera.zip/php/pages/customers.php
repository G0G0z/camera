<?php
$pageTitle  = 'Müşteriler';
$activePage = 'customers';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>Müşteriler</h1>
    <p>Müşteri hesaplarını yönetin</p>
  </div>
  <button class="btn btn-primary" onclick="openAddCustomer()">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Müşteri Ekle
  </button>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr>
        <th>Ad</th><th>E-posta</th><th>Telefon</th>
        <th>Kayıt Kotası (Kamera başı)</th>
        <th>Eklenme</th><th style="width:120px">İşlem</th>
      </tr></thead>
      <tbody id="cust-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 6) . '</tr>', 5) ?>
      </tbody>
    </table>
  </div>
  <div id="cust-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
    <h3>Müşteri bulunamadı</h3>
  </div>
</div>

<script>
async function loadCustomers() {
  const tbody = document.getElementById('cust-tbody');
  const empty = document.getElementById('cust-empty');
  try {
    const data = await App.get('/customers');
    const list = Array.isArray(data) ? data : [];
    if (!list.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = list.map(c => `<tr>
      <td><a href="/customers/${c.id}" class="text-blue-400 hover:underline font-medium">${c.name}</a></td>
      <td class="text-zinc-400">${c.email || '—'}</td>
      <td class="text-zinc-400">${c.phone || '—'}</td>
      <td class="text-zinc-300 font-medium">💾 ${c.storageLimitGbPerCamera ?? 10} GB</td>
      <td class="text-zinc-500 text-sm">${App.fmtDateShort(c.createdAt)}</td>
      <td class="flex gap-1">
        <a href="/customers/${c.id}" class="btn btn-secondary btn-sm">Detay</a>
        <button class="btn btn-ghost btn-sm text-red-400" onclick="deleteCust(${c.id})">🗑</button>
      </td>
    </tr>`).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
}

function openAddCustomer() {
  App.openModal(`
    <div class="modal-header"><h3>Müşteri Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <form id="add-cust-form">
        <div class="form-group"><label class="form-label">Müşteri Adı *</label><input name="name" class="form-control" required /></div>
        <div class="form-group"><label class="form-label">E-posta</label><input name="email" type="email" class="form-control" /></div>
        <div class="form-group"><label class="form-label">Telefon</label><input name="phone" class="form-control" /></div>
        <div class="form-group">
          <label class="form-label">Kayıt Kotası (kamera başına GB)</label>
          <div class="flex items-center gap-2">
            <input name="storageLimitGbPerCamera" type="number" class="form-control" value="10" min="1" max="10000" style="max-width:120px" />
            <span class="text-xs text-zinc-500">GB / kamera · dolunca en eski kayıt silinir</span>
          </div>
        </div>
        <div id="add-cust-err" class="text-red-400 text-sm hidden"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitAddCustomer()">Ekle</button>
    </div>`);
}

async function submitAddCustomer() {
  const fd = new FormData(document.getElementById('add-cust-form'));
  const err = document.getElementById('add-cust-err');
  try {
    await App.post('/customers', {
      name:  fd.get('name'),
      email: fd.get('email'),
      phone: fd.get('phone'),
      storageLimitGbPerCamera: parseInt(fd.get('storageLimitGbPerCamera')) || 10,
    });
    App.closeModal(); App.toast('Müşteri eklendi','success'); loadCustomers();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

async function deleteCust(id) {
  App.confirm('Bu müşteriyi silmek istediğinize emin misiniz?', async () => {
    try { await App.del('/customers/' + id); App.toast('Müşteri silindi','success'); loadCustomers(); }
    catch(e) { App.toast('Silinemedi: ' + e.message,'error'); }
  });
}

loadCustomers();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
