<?php
$pageTitle  = 'WiFi Profilleri';
$activePage = 'wifi';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>WiFi Profilleri</h1>
    <p>Kamera kurulumu için WiFi ağlarını yönetin</p>
  </div>
  <button class="btn btn-primary" onclick="openAddWifi()">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Profil Ekle
  </button>
</div>

<div class="card mb-6">
  <div class="table-wrap">
    <table>
      <thead><tr><th>SSID</th><th>Güvenlik</th><th>Eklenme</th><th style="width:120px">İşlem</th></tr></thead>
      <tbody id="wifi-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 4) . '</tr>', 4) ?>
      </tbody>
    </table>
  </div>
  <div id="wifi-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>
    <h3>WiFi profili bulunamadı</h3>
    <p>Kamera QR kurulumu için WiFi profili ekleyin.</p>
  </div>
</div>

<!-- QR String generator -->
<div class="card">
  <div class="card-header"><span class="card-title">QR WiFi Kodu Üret</span></div>
  <div class="flex gap-4 flex-wrap">
    <div class="form-group flex-1 min-w-48 mb-0">
      <label class="form-label">Profil Seç</label>
      <select id="qr-profile" class="form-control"><option value="">— Seçin —</option></select>
    </div>
    <div class="flex items-end">
      <button class="btn btn-secondary" onclick="genQR()">QR String Üret</button>
    </div>
  </div>
  <div id="qr-result" class="mt-4 hidden">
    <p class="text-xs text-zinc-500 mb-2">QR içeriği:</p>
    <code id="qr-string" class="block bg-zinc-950 text-green-400 text-xs p-3 rounded-lg break-all font-mono"></code>
  </div>
</div>

<script>
async function loadWifi() {
  const tbody = document.getElementById('wifi-tbody');
  const empty = document.getElementById('wifi-empty');
  const sel   = document.getElementById('qr-profile');
  try {
    const data = await App.get('/wifi');
    const list = Array.isArray(data) ? data : [];
    sel.innerHTML = '<option value="">— Seçin —</option>' + list.map(w => `<option value="${w.id}">${w.ssid}</option>`).join('');
    if (!list.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = list.map(w => `<tr>
      <td class="font-medium">${w.ssid}</td>
      <td>${App.badge(w.security || 'WPA2','zinc')}</td>
      <td class="text-zinc-500 text-sm">${App.fmtDateShort(w.createdAt)}</td>
      <td><button class="btn btn-ghost btn-sm text-red-400" onclick="deleteWifi(${w.id})">🗑</button></td>
    </tr>`).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="4" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
}

function openAddWifi() {
  App.openModal(`
    <div class="modal-header"><h3>WiFi Profili Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <form id="add-wifi-form">
        <div class="form-group"><label class="form-label">SSID (Ağ Adı) *</label><input name="ssid" class="form-control" required /></div>
        <div class="form-group"><label class="form-label">Şifre</label><input name="password" type="password" class="form-control" /></div>
        <div class="form-group"><label class="form-label">Güvenlik</label>
          <select name="security" class="form-control"><option value="WPA2">WPA2</option><option value="WPA">WPA</option><option value="nopass">Açık</option></select>
        </div>
        <div id="add-wifi-err" class="text-red-400 text-sm hidden"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitAddWifi()">Ekle</button>
    </div>`);
}

async function submitAddWifi() {
  const fd = new FormData(document.getElementById('add-wifi-form'));
  const err = document.getElementById('add-wifi-err');
  try {
    await App.post('/wifi', { ssid: fd.get('ssid'), password: fd.get('password'), security: fd.get('security') });
    App.closeModal(); App.toast('WiFi profili eklendi','success'); loadWifi();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

async function deleteWifi(id) {
  App.confirm('Bu WiFi profilini silmek istediğinize emin misiniz?', async () => {
    try { await App.del('/wifi/' + id); App.toast('Profil silindi','success'); loadWifi(); }
    catch(e) { App.toast('Silinemedi: ' + e.message,'error'); }
  });
}

async function genQR() {
  const id = document.getElementById('qr-profile').value;
  if (!id) { App.toast('Lütfen bir profil seçin','error'); return; }
  try {
    const res = await App.post('/wifi/qr-string', { profileId: parseInt(id) });
    document.getElementById('qr-string').textContent = res.qrString || res.string || JSON.stringify(res);
    document.getElementById('qr-result').classList.remove('hidden');
  } catch(e) { App.toast('Hata: ' + e.message,'error'); }
}

loadWifi();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
