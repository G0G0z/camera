<?php
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Dashboard</h1>
  <p id="dash-subtitle">Sistem durumu ve genel bakış</p>
</div>

<!-- Üst istatistik kartları -->
<div id="stats-grid" class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
  <?php for ($i = 0; $i < 4; $i++): ?>
    <div class="card skeleton h-28"></div>
  <?php endfor ?>
</div>

<!-- Superadmin: Müşteri Tablosu -->
<div id="customer-section" class="hidden mb-6">
  <div class="card">
    <div class="card-header">
      <span class="card-title flex items-center gap-2">
        <svg class="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        Müşteriler
      </span>
      <a href="/customers" class="btn btn-ghost btn-sm">Tümünü Yönet →</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr>
          <th>Müşteri</th>
          <th>Kameralar</th>
          <th>Aktif Kayıt</th>
          <th>Kota (Kamera Başı)</th>
          <th>Depolama Kullanımı</th>
          <th style="width:100px">İşlem</th>
        </tr></thead>
        <tbody id="cust-tbody">
          <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 6) . '</tr>', 4) ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Alt satır: Son Olaylar -->
<div class="card">
  <div class="card-header">
    <span class="card-title flex items-center gap-2">
      <svg class="w-4 h-4 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      Son Olaylar
    </span>
    <a href="/events" class="btn btn-ghost btn-sm">Tümü →</a>
  </div>
  <div id="events-list" class="space-y-2">
    <?php for ($i = 0; $i < 5; $i++): ?>
      <div class="skeleton h-14 rounded-lg"></div>
    <?php endfor ?>
  </div>
</div>

<script>
function fmtBytes(b) {
  b = parseInt(b) || 0;
  if (b === 0) return '0 B';
  const u = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(b) / Math.log(1024));
  return (b / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + ' ' + u[i];
}

function storageBar(pct) {
  const bc = pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-yellow-500' : 'bg-blue-500';
  const label = pct >= 90
    ? `<span class="text-[10px] text-red-400 font-semibold">⚠ ${pct}%</span>`
    : `<span class="text-[10px] text-zinc-500">${pct}%</span>`;
  return `<div class="flex items-center gap-2">
    <div class="flex-1 bg-zinc-800 rounded-full h-1.5" style="min-width:80px">
      <div class="${bc} h-1.5 rounded-full transition-all" style="width:${pct}%"></div>
    </div>
    ${label}
  </div>`;
}

(async () => {
  try {
    const stats = await App.get('/dashboard/stats');
    const isSuperadmin = Array.isArray(stats.customerRows);

    // ── İstatistik Kartları ──────────────────────────────────────────────────
    const totalUsedGb  = ((stats.totalUsedBytes  ?? 0) / (1024**3)).toFixed(1);
    const totalLimGb   = ((stats.totalLimitBytes ?? 0) / (1024**3)).toFixed(1);
    const storagePct   = stats.totalLimitBytes
      ? Math.min(100, Math.round(stats.totalUsedBytes / stats.totalLimitBytes * 100))
      : 0;
    const storageColor = storagePct >= 90 ? 'text-red-400' : storagePct >= 70 ? 'text-yellow-400' : 'text-emerald-400';

    document.getElementById('stats-grid').innerHTML = `
      <!-- Kameralar -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">Kameralar</span>
          <svg class="w-4 h-4 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
        </div>
        <div class="stat-value">${stats.totalCameras ?? 0}</div>
        <div class="flex gap-3 mt-1 flex-wrap">
          <span class="text-xs text-emerald-400 flex items-center gap-1"><span class="dot dot-green"></span>${stats.onlineCameras ?? 0} online</span>
          <span class="text-xs text-red-400 flex items-center gap-1"><span class="dot dot-red"></span>${stats.offlineCameras ?? 0} offline</span>
          ${(stats.unknownCameras ?? 0) > 0 ? `<span class="text-xs text-zinc-500">${stats.unknownCameras} bilinmiyor</span>` : ''}
        </div>
      </div>

      <!-- Kayıtlar -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">Kayıtlar</span>
          <svg class="w-4 h-4 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
        </div>
        <div class="stat-value">${stats.totalRecordings ?? 0}</div>
        <div class="stat-label">${stats.activeRecordings ?? 0} aktif kayıt devam ediyor</div>
      </div>

      <!-- Depolama -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">Depolama</span>
          <svg class="w-4 h-4 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
        </div>
        <div class="stat-value ${storageColor}">${totalUsedGb} <span class="text-sm font-normal text-zinc-500">/ ${totalLimGb} GB</span></div>
        <div class="w-full bg-zinc-800 rounded-full h-1 mt-2">
          <div class="${storagePct >= 90 ? 'bg-red-500' : storagePct >= 70 ? 'bg-yellow-500' : 'bg-blue-500'} h-1 rounded-full" style="width:${storagePct}%"></div>
        </div>
      </div>

      <!-- Müşteriler veya Bugünkü Olaylar -->
      ${isSuperadmin ? `
      <div class="card">
        <div class="card-header">
          <span class="card-title">Müşteriler</span>
          <svg class="w-4 h-4 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <div class="stat-value">${stats.customers ?? 0}</div>
        <div class="stat-label">${stats.users ?? 0} kullanıcı toplam</div>
      </div>` : `
      <div class="card">
        <div class="card-header">
          <span class="card-title">Bugünkü Olaylar</span>
          <svg class="w-4 h-4 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
        </div>
        <div class="stat-value">${stats.todayEvents ?? 0}</div>
        <div class="stat-label">AI & hareket tetikleyiciler</div>
      </div>`}`;

    // ── Superadmin: Müşteri Tablosu ──────────────────────────────────────────
    if (isSuperadmin && stats.customerRows.length > 0) {
      document.getElementById('customer-section').classList.remove('hidden');
      const tbody = document.getElementById('cust-tbody');
      tbody.innerHTML = stats.customerRows.map(c => {
        const pct = c.usedPercent ?? 0;
        const onlineBadge = c.onlineCameras > 0
          ? `<span class="text-emerald-400 text-xs">${c.onlineCameras} online</span>`
          : '';
        const activeRecBadge = c.activeRecordings > 0
          ? `<span class="badge badge-green text-[10px]">● ${c.activeRecordings} kayıt</span>`
          : '<span class="text-zinc-600 text-xs">—</span>';
        return `<tr>
          <td>
            <a href="/customers/${c.id}" class="font-medium text-blue-400 hover:underline">${c.name}</a>
            ${c.email ? `<div class="text-[11px] text-zinc-500">${c.email}</div>` : ''}
          </td>
          <td>
            <span class="font-medium">${c.cameraCount}</span>
            ${onlineBadge ? `<div class="mt-0.5">${onlineBadge}</div>` : ''}
          </td>
          <td>${activeRecBadge}</td>
          <td class="font-medium text-zinc-300">💾 ${c.limitGbPerCam} GB</td>
          <td style="min-width:180px">
            ${storageBar(pct)}
            <div class="text-[10px] text-zinc-500 mt-0.5">${fmtBytes(c.usedBytes)} / ${fmtBytes(c.limitBytesTotal)} toplam</div>
          </td>
          <td class="flex gap-1">
            <a href="/customers/${c.id}" class="btn btn-secondary btn-xs">Detay</a>
            <button class="btn btn-ghost btn-xs text-zinc-400" onclick="editQuota(${c.id},'${c.name}',${c.limitGbPerCam})">⚙</button>
          </td>
        </tr>`;
      }).join('');
    } else if (isSuperadmin) {
      document.getElementById('customer-section').classList.remove('hidden');
      document.getElementById('cust-tbody').innerHTML =
        '<tr><td colspan="6" class="text-center text-zinc-500 py-6">Henüz müşteri yok — <a href="/customers" class="text-blue-400 hover:underline">Müşteri Ekle</a></td></tr>';
    }

    // ── Son Olaylar ──────────────────────────────────────────────────────────
    const events = stats.recentEvents ?? [];
    if (!events.length) {
      document.getElementById('events-list').innerHTML =
        '<div class="empty-state py-8"><p class="text-zinc-600">Son olay yok</p></div>';
      return;
    }
    const eventIcon = t => ({person:'👤',vehicle:'🚗',face:'🧑',tamper:'⚠️',motion:'📡'}[t] ?? '📡');
    document.getElementById('events-list').innerHTML = events.map(ev => `
      <div class="flex items-center gap-3 p-3 rounded-lg hover:bg-zinc-800 transition-colors">
        ${ev.snapshotUrl
          ? `<img src="${ev.snapshotUrl}" class="w-16 h-11 rounded object-cover shrink-0" />`
          : `<div class="w-16 h-11 rounded bg-zinc-800 flex items-center justify-center text-zinc-600 shrink-0 text-xl">${eventIcon(ev.type)}</div>`}
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2">
            <span class="text-sm font-medium capitalize">${ev.type}</span>
            ${ev.confidence ? `<span class="text-xs text-zinc-500">${Math.round(ev.confidence * 100)}%</span>` : ''}
          </div>
          <div class="text-xs text-zinc-500 truncate">${ev.cameraName || 'Kamera #' + ev.cameraId}</div>
          <div class="text-xs text-zinc-600">${App.fmtDate(ev.timestamp)}</div>
        </div>
      </div>`).join('');

  } catch (e) {
    document.getElementById('stats-grid').innerHTML =
      `<div class="col-span-4 text-red-400 text-sm p-4">Veriler yüklenemedi: ${e.message}</div>`;
    document.getElementById('events-list').innerHTML = '';
  }
})();

// Kota hızlı düzenleme (dashboard'dan inline)
async function editQuota(id, name, current) {
  App.openModal(`
    <div class="modal-header">
      <h3>${name} — Kayıt Kotası</h3>
      <button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <p class="text-sm text-zinc-400 mb-4">Bu müşterinin her kamerası için ayrı depolama kotası.</p>
      <div class="form-group">
        <label class="form-label">Kamera Başına Limit (GB)</label>
        <div class="flex items-center gap-2">
          <input id="dq-gb" type="number" class="form-control" value="${current}" min="1" max="100000" style="max-width:140px" />
          <span class="text-sm text-zinc-500">GB / kamera</span>
        </div>
      </div>
      <div id="dq-err" class="text-red-400 text-sm hidden"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitQuota(${id})">Kaydet</button>
    </div>`);
}
async function submitQuota(id) {
  const val = parseInt(document.getElementById('dq-gb').value);
  const err = document.getElementById('dq-err');
  if (!val || val < 1) { err.textContent = 'En az 1 GB giriniz'; err.classList.remove('hidden'); return; }
  try {
    await App.put('/customers/' + id, { storageLimitGbPerCamera: val });
    App.closeModal();
    App.toast('Kota güncellendi', 'success');
    location.reload();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
