<?php
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Dashboard</h1>
  <p>Sistem durumu ve son olaylar</p>
</div>

<!-- Stat cards -->
<div id="stats-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
  <?php for ($i = 0; $i < 4; $i++): ?>
    <div class="card skeleton h-28"></div>
  <?php endfor ?>
</div>

<!-- Recent events -->
<div class="card">
  <div class="card-header">
    <span class="card-title flex items-center gap-2">
      <svg class="w-4 h-4 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      Son Olaylar
    </span>
    <a href="/events" class="btn btn-ghost btn-sm">Tümü →</a>
  </div>
  <div id="events-list" class="space-y-2">
    <?php for ($i = 0; $i < 5; $i++): ?>
      <div class="skeleton h-14 rounded-lg"></div>
    <?php endfor ?>
  </div>
</div>

<script>
(async () => {
  try {
    const stats = await App.get('/dashboard/stats');
    document.getElementById('stats-grid').innerHTML = `
      <div class="card">
        <div class="card-header"><span class="card-title">Toplam Kamera</span>
          <svg class="w-4 h-4 text-zinc-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
        </div>
        <div class="stat-value">${stats.totalCameras ?? 0}</div>
        <div class="flex gap-3 mt-1">
          <span class="text-xs text-emerald-400 flex items-center gap-1"><span class="dot dot-green"></span>${stats.onlineCameras ?? 0} online</span>
          <span class="text-xs text-red-400 flex items-center gap-1"><span class="dot dot-red"></span>${stats.offlineCameras ?? 0} offline</span>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Kayıtlar</span>
          <svg class="w-4 h-4 text-zinc-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
        </div>
        <div class="stat-value">${stats.totalRecordings ?? 0}</div>
        <div class="stat-label">${stats.activeRecordings ?? 0} aktif</div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Bugünkü Olaylar</span>
          <svg class="w-4 h-4 text-zinc-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
        </div>
        <div class="stat-value">${stats.todayEvents ?? 0}</div>
        <div class="stat-label">AI & hareket tetikleyiciler</div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Müşteriler</span>
          <svg class="w-4 h-4 text-zinc-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <div class="stat-value">${stats.customers ?? 0}</div>
        <div class="stat-label">Aktif hesaplar</div>
      </div>`;

    const events = stats.recentEvents ?? [];
    if (!events.length) {
      document.getElementById('events-list').innerHTML = '<div class="empty-state py-8"><p>Son olay yok</p></div>';
      return;
    }
    const eventIcon = t => {
      const icons = {
        person: '👤', vehicle: '🚗', face: '🧑', tamper: '⚠️', motion: '📡',
      };
      return icons[t] || '📡';
    };
    document.getElementById('events-list').innerHTML = events.map(ev => `
      <div class="flex items-center gap-3 p-3 rounded-lg hover:bg-zinc-800 transition-colors">
        ${ev.snapshotUrl
          ? `<img src="${ev.snapshotUrl}" class="w-16 h-11 rounded object-cover shrink-0" />`
          : `<div class="w-16 h-11 rounded bg-zinc-800 flex items-center justify-center text-zinc-600 shrink-0 text-xl">${eventIcon(ev.type)}</div>`}
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2">
            <span class="text-sm font-medium capitalize">${ev.type}</span>
            ${ev.confidence ? `<span class="text-xs text-zinc-500">${Math.round(ev.confidence * 100)}%</span>` : ''}
          </div>
          <div class="text-xs text-zinc-500 truncate">${ev.cameraName || 'Kamera #' + ev.cameraId}</div>
          <div class="text-xs text-zinc-600">${App.fmtDate(ev.timestamp)}</div>
        </div>
      </div>`).join('');
  } catch (e) {
    document.getElementById('stats-grid').innerHTML = `<div class="col-span-4 text-red-400 text-sm">Veriler yüklenemedi: ${e.message}</div>`;
    document.getElementById('events-list').innerHTML = '';
  }
})();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
