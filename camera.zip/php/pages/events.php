<?php
$pageTitle  = 'Olaylar';
$activePage = 'events';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Olaylar</h1>
  <p>AI ve hareket algılama günlüğü</p>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr>
        <th>Tür</th><th>Kamera</th><th>Güven</th><th>Zaman</th><th>Anlık Görüntü</th><th style="width:80px">İşlem</th>
      </tr></thead>
      <tbody id="ev-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 6) . '</tr>', 8) ?>
      </tbody>
    </table>
  </div>
  <div id="ev-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
    <h3>Olay bulunamadı</h3>
    <p>Henüz hiçbir olay kaydedilmedi.</p>
  </div>
</div>

<script>
const eventEmoji = { person: '👤', vehicle: '🚗', face: '🧑', tamper: '⚠️', motion: '📡' };

(async () => {
  const tbody = document.getElementById('ev-tbody');
  const empty = document.getElementById('ev-empty');
  try {
    const data = await App.get('/events');
    const evs = Array.isArray(data) ? data : (data?.data ?? []);
    if (!evs.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = evs.map(ev => `
      <tr>
        <td><span class="flex items-center gap-1.5">${eventEmoji[ev.type] || '📡'} <span class="capitalize">${ev.type}</span></span></td>
        <td><a href="/cameras/${ev.cameraId}" class="text-blue-400 hover:underline">${ev.cameraName || 'Kamera #' + ev.cameraId}</a></td>
        <td>${ev.confidence ? Math.round(ev.confidence * 100) + '%' : '—'}</td>
        <td class="text-zinc-400 whitespace-nowrap">${App.fmtDate(ev.timestamp)}</td>
        <td>${ev.snapshotUrl ? `<img src="${ev.snapshotUrl}" class="h-10 w-16 object-cover rounded" />` : '—'}</td>
        <td><button class="btn btn-ghost btn-sm text-red-400" onclick="deleteEv(${ev.id})">🗑</button></td>
      </tr>`).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
})();

async function deleteEv(id) {
  App.confirm('Bu olayı silmek istediğinize emin misiniz?', async () => {
    try { await App.del('/events/' + id); App.toast('Olay silindi','success'); location.reload(); }
    catch(e) { App.toast('Silinemedi: ' + e.message,'error'); }
  });
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
