<?php
$pageTitle  = 'Kayıtlar';
$activePage = 'recordings';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Kayıtlar</h1>
  <p>Video arşivini görüntüleyin ve yönetin</p>
</div>

<!-- Depolama Kullanımı (kamera bazlı) -->
<div id="storage-wrap" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-6"></div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr>
        <th>Kamera</th><th>Başlangıç</th><th>Bitiş</th><th>Tetikleyici</th><th>Süre</th><th>Boyut</th><th style="width:80px">İşlem</th>
      </tr></thead>
      <tbody id="rec-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 7) . '</tr>', 6) ?>
      </tbody>
    </table>
  </div>
  <div id="rec-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
    <h3>Kayıt bulunamadı</h3>
    <p>Henüz kayıt yapılmamış.</p>
  </div>
</div>

<script>
function fmtBytes(b) {
  b = parseInt(b) || 0;
  if (b === 0) return '—';
  const u = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(b) / Math.log(1024));
  return (b / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + ' ' + u[i];
}

async function loadStorageStats() {
  const wrap = document.getElementById('storage-wrap');
  try {
    const stats = await App.get('/recordings/storage-stats');
    if (!stats.length) { wrap.innerHTML = ''; return; }
    wrap.innerHTML = stats.map(s => {
      const pct   = s.usedPercent ?? 0;
      const bc    = pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-yellow-500' : 'bg-blue-500';
      const label = pct >= 90
        ? '<span class="text-[10px] text-red-400 font-semibold">⚠ Dolu</span>'
        : pct >= 70
          ? '<span class="text-[10px] text-yellow-400">Dolmak üzere</span>'
          : '';
      return `<div class="card p-3">
        <div class="flex justify-between items-start mb-1">
          <div class="min-w-0">
            <p class="text-xs font-medium text-zinc-200 truncate">${s.cameraName}</p>
            ${s.customerName ? `<p class="text-[10px] text-zinc-500 truncate">${s.customerName}</p>` : ''}
          </div>
          ${label}
        </div>
        <div class="w-full bg-zinc-800 rounded-full h-1.5 mb-1">
          <div class="${bc} h-1.5 rounded-full transition-all" style="width:${pct}%"></div>
        </div>
        <div class="flex justify-between text-[10px] text-zinc-500">
          <span>${fmtBytes(s.usedBytes)} kullanıldı</span>
          <span>Limit: ${s.limitGb} GB</span>
        </div>
      </div>`;
    }).join('');
  } catch { wrap.innerHTML = ''; }
}

async function loadRecordings() {
  const tbody = document.getElementById('rec-tbody');
  const empty = document.getElementById('rec-empty');
  try {
    const data = await App.get('/recordings');
    const recs = Array.isArray(data) ? data : (data?.items ?? []);
    if (!recs.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = recs.map(r => {
      const dur = r.duration ? (r.duration >= 60
        ? Math.floor(r.duration/60) + 'dk ' + (r.duration%60) + 's'
        : r.duration + 's') : '—';
      const statusCell = r.status === 'recording'
        ? App.badge('● Kaydediyor', 'green')
        : r.status === 'completed'
          ? App.badge('Tamamlandı', 'zinc')
          : App.badge(r.status, 'zinc');
      return `<tr>
        <td class="font-medium">${r.cameraName || 'Kamera #' + r.cameraId}</td>
        <td class="text-zinc-400">${App.fmtDate(r.startTime)}</td>
        <td class="text-zinc-400">${r.endTime ? App.fmtDate(r.endTime) : statusCell}</td>
        <td><span class="badge badge-zinc">${r.trigger || 'manual'}</span></td>
        <td class="text-zinc-400">${dur}</td>
        <td class="text-zinc-400">${fmtBytes(r.fileSize)}</td>
        <td>
          <button class="btn btn-ghost btn-sm text-red-400 hover:text-red-300" onclick="deleteRec(${r.id})">🗑</button>
        </td>
      </tr>`;
    }).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
}

async function deleteRec(id) {
  App.confirm('Bu kaydı silmek istediğinize emin misiniz?', async () => {
    try {
      await App.del('/recordings/' + id);
      App.toast('Kayıt silindi','success');
      loadRecordings();
      loadStorageStats();
    } catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}

loadStorageStats();
loadRecordings();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
