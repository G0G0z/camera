<?php
$pageTitle  = 'Kayıtlar';
$activePage = 'recordings';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Kayıtlar</h1>
  <p>Video arşivini görüntüleyin ve yönetin</p>
</div>

<div class="card">
  <div id="rec-table-wrap" class="table-wrap">
    <table>
      <thead><tr>
        <th>Kamera</th><th>Başlangıç</th><th>Bitiş</th><th>Tetikleyici</th><th>Süre</th><th style="width:80px">İşlem</th>
      </tr></thead>
      <tbody id="rec-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 6) . '</tr>', 6) ?>
      </tbody>
    </table>
  </div>
  <div id="rec-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
    <h3>Kayıt bulunamadı</h3>
    <p>Henüz kayıt yapılmamış.</p>
  </div>
</div>

<script>
(async () => {
  const tbody = document.getElementById('rec-tbody');
  const empty = document.getElementById('rec-empty');
  try {
    const data = await App.get('/recordings');
    const recs = Array.isArray(data) ? data : (data?.data ?? []);
    if (!recs.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = recs.map(r => {
      const dur = r.endedAt && r.startedAt
        ? Math.round((new Date(r.endedAt) - new Date(r.startedAt)) / 1000) + 's'
        : r.endedAt ? '—' : App.badge('Aktif','green');
      return `<tr>
        <td class="font-medium">${r.cameraName || 'Kamera #' + r.cameraId}</td>
        <td class="text-zinc-400">${App.fmtDate(r.startedAt)}</td>
        <td class="text-zinc-400">${r.endedAt ? App.fmtDate(r.endedAt) : '—'}</td>
        <td><span class="badge badge-zinc">${r.trigger || 'manual'}</span></td>
        <td>${dur}</td>
        <td>
          <button class="btn btn-ghost btn-sm text-red-400 hover:text-red-300" onclick="deleteRec(${r.id})">🗑</button>
        </td>
      </tr>`;
    }).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
})();

async function deleteRec(id) {
  App.confirm('Bu kaydı silmek istediğinize emin misiniz?', async () => {
    try { await App.del('/recordings/' + id); App.toast('Kayıt silindi','success'); location.reload(); }
    catch(e) { App.toast('Silinemedi: ' + e.message, 'error'); }
  });
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
