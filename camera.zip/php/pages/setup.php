<?php
$pageTitle  = 'Kamera Ekle (QR Provizyon)';
$activePage = 'setup';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Kamera Ekle</h1>
  <p>QR kodu ile yeni kamera provizyon tokeni oluşturun</p>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

  <div class="card">
    <div class="card-header"><span class="card-title">Provizyon Tokeni Üret</span></div>
    <form id="prov-form" class="space-y-4">

      <!-- Kamera bilgileri -->
      <div class="form-group">
        <label class="form-label">Kamera Adı *</label>
        <input name="name" class="form-control" placeholder="Ön Kapı Kamerası" required />
      </div>
      <div class="form-group">
        <label class="form-label">Konum (opsiyonel)</label>
        <input name="location" class="form-control" placeholder="Giriş kapısı" />
      </div>

      <!-- WiFi profili seçimi -->
      <div class="form-group">
        <label class="form-label">WiFi Profili</label>
        <select id="wifi-profile-sel" class="form-control" onchange="onWifiProfileChange()">
          <option value="">— Kayıtlı profil yok / Manuel gir —</option>
        </select>
        <p id="wifi-profile-hint" class="text-xs text-zinc-500 mt-1 hidden">
          Profil seçildi. Aşağıdaki alanlar otomatik dolduruldu.
        </p>
      </div>

      <!-- WiFi alanları (profil seçilince gizlenebilir) -->
      <div id="wifi-manual-fields">
        <div class="form-group">
          <label class="form-label">WiFi SSID *</label>
          <input id="wifi-ssid" name="ssid" class="form-control" placeholder="EvWifi" required />
        </div>
        <div class="form-group">
          <label class="form-label">WiFi Şifresi</label>
          <input id="wifi-pass" name="password" type="password" class="form-control" placeholder="(boş bırakılabilir)" />
        </div>
        <div class="form-group">
          <label class="form-label">Güvenlik Tipi</label>
          <select id="wifi-sec" name="security" class="form-control">
            <option value="WPA">WPA</option>
            <option value="WPA2" selected>WPA2</option>
            <option value="nopass">Açık Ağ</option>
          </select>
        </div>
      </div>

      <!-- Müşteri -->
      <div class="form-group" id="cust-group">
        <label class="form-label">Müşteri</label>
        <select name="customerId" id="setup-cust" class="form-control">
          <option value="">— Varsayılan —</option>
        </select>
      </div>

      <div id="prov-err" class="text-red-400 text-sm hidden"></div>
      <button type="button" class="btn btn-primary w-full" onclick="generateToken()">🔑 Token Üret</button>
    </form>

    <div id="token-result" class="mt-6 hidden">
      <!-- QR Code -->
      <div class="flex flex-col items-center p-5 bg-white rounded-xl mb-4">
        <canvas id="qr-canvas"></canvas>
      </div>
      <p class="text-xs text-zinc-400 text-center mb-3">
        Bu QR kodu kamerayla tarayın — provision.sh panele otomatik kaydeder.
      </p>

      <!-- Token + raw payload (collapse) -->
      <div class="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-xs">
        <div class="flex items-center justify-between mb-1">
          <span class="text-zinc-500 font-medium uppercase tracking-wider">Token</span>
          <span id="prov-token" class="font-mono text-zinc-300 break-all"></span>
        </div>
        <details class="mt-2">
          <summary class="text-zinc-600 cursor-pointer select-none hover:text-zinc-400">Ham payload göster</summary>
          <div id="qr-payload" class="font-mono text-green-400 break-all mt-2 leading-relaxed"></div>
        </details>
      </div>

      <a href="/wifi-setup" class="btn btn-ghost btn-sm mt-3 text-xs">
        ← Yeni WiFi profili ekle
      </a>
    </div>
  </div>

  <!-- Kurulum adımları -->
  <div class="card">
    <div class="card-header"><span class="card-title">Kurulum Adımları</span></div>
    <ol class="space-y-3 text-sm text-zinc-300">
      <li class="flex gap-3"><span class="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold shrink-0">1</span><span>Windows'ta Camera Flasher uygulamasını yönetici olarak açın</span></li>
      <li class="flex gap-3"><span class="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold shrink-0">2</span><span>USB-TTL adaptörü bağlayın (TX→RX, RX→TX, GND→GND)</span></li>
      <li class="flex gap-3"><span class="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold shrink-0">3</span><span>SoC modelini ve flash boyutunu seçin, BAŞLAT'a basın</span></li>
      <li class="flex gap-3"><span class="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold shrink-0">4</span><span>OpenIPC firmware otomatik yüklenir, kamera SSH açar</span></li>
      <li class="flex gap-3"><span class="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold shrink-0">5</span><span>Provision.sh çalışır, yukarıdaki QR payload'ı okur</span></li>
      <li class="flex gap-3"><span class="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold shrink-0">6</span><span>Kamera bu panele otomatik kaydolur ✅</span></li>
    </ol>

    <div class="mt-6 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg text-xs text-blue-300">
      💡 <strong>İpucu:</strong> WiFi profillerinizi önceden
      <a href="/wifi-setup" class="underline hover:text-blue-200">WiFi Profilleri</a>
      sayfasında oluşturun; burada listeden seçebilirsiniz.
    </div>
  </div>
</div>

<script src="/assets/qrcode.min.js"></script>
<script>
// Kayıtlı WiFi profillerini yükle
(async () => {
  const sel  = document.getElementById('wifi-profile-sel');
  const csel = document.getElementById('setup-cust');

  const [wifiRes, custRes] = await Promise.allSettled([
    App.get('/wifi'),
    App.get('/customers'),
  ]);

  // WiFi profilleri
  if (wifiRes.status === 'fulfilled') {
    const profiles = Array.isArray(wifiRes.value) ? wifiRes.value : [];
    if (profiles.length) {
      sel.innerHTML = '<option value="">— Manuel gir —</option>' +
        profiles.map(p => `<option
          value="${p.id}"
          data-ssid="${p.ssid}"
          data-pass=""
          data-sec="${p.security || 'WPA2'}"
        >${p.ssid}${p.name && p.name !== p.ssid ? ' (' + p.name + ')' : ''}</option>`).join('');
    }
  }

  // Müşteri listesi
  if (custRes.status === 'fulfilled') {
    const custs = Array.isArray(custRes.value) ? custRes.value : [];
    if (custs.length > 1) {
      csel.innerHTML = '<option value="">— Varsayılan —</option>' +
        custs.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    } else if (custs.length === 1) {
      // Tek müşteri → gizle, otomatik seç
      csel.innerHTML = `<option value="${custs[0].id}">${custs[0].name}</option>`;
      document.getElementById('cust-group').classList.add('hidden');
    } else {
      document.getElementById('cust-group').classList.add('hidden');
    }
  } else {
    document.getElementById('cust-group').classList.add('hidden');
  }
})();

// Profil seçilince alanları otomatik doldur
function onWifiProfileChange() {
  const sel    = document.getElementById('wifi-profile-sel');
  const hint   = document.getElementById('wifi-profile-hint');
  const opt    = sel.options[sel.selectedIndex];
  const fields = document.getElementById('wifi-manual-fields');

  if (sel.value) {
    // Profil seçildi — alanları doldur ve salt-okunur yap
    document.getElementById('wifi-ssid').value = opt.dataset.ssid || '';
    document.getElementById('wifi-sec').value  = opt.dataset.sec  || 'WPA2';
    // Şifre base64'te saklanıyor, provision endpoint şifreyi tekrar istiyor
    document.getElementById('wifi-pass').value = '';
    fields.style.opacity = '0.5';
    fields.style.pointerEvents = 'none';
    hint.classList.remove('hidden');
  } else {
    // Manuel mod
    fields.style.opacity = '';
    fields.style.pointerEvents = '';
    hint.classList.add('hidden');
  }
}

async function generateToken() {
  const fd  = new FormData(document.getElementById('prov-form'));
  const err = document.getElementById('prov-err');
  err.classList.add('hidden');

  const name = fd.get('name')?.trim();
  const ssid = document.getElementById('wifi-ssid').value.trim();

  if (!name) { err.textContent = 'Kamera adı gerekli.'; err.classList.remove('hidden'); return; }
  if (!ssid) { err.textContent = 'WiFi SSID gerekli. Bir profil seçin veya manuel girin.'; err.classList.remove('hidden'); return; }

  try {
    const res = await App.post('/provision/generate', {
      name,
      ssid,
      password:   document.getElementById('wifi-pass').value || '',
      security:   document.getElementById('wifi-sec').value  || 'WPA2',
      location:   fd.get('location') || '',
      customerId: fd.get('customerId') ? parseInt(fd.get('customerId')) : undefined,
    });
    const payload = res.qrPayload || JSON.stringify(res);
    document.getElementById('qr-payload').textContent = payload;
    document.getElementById('prov-token').textContent  = res.token || '—';
    document.getElementById('token-result').classList.remove('hidden');

    // QR kodu çiz
    await QRCode.toCanvas(document.getElementById('qr-canvas'), payload, {
      width: 240,
      margin: 2,
      color: { dark: '#000000', light: '#ffffff' },
    });

    App.toast('Token oluşturuldu', 'success');
  } catch(e) {
    err.textContent = 'Hata: ' + e.message;
    err.classList.remove('hidden');
  }
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
