<?php
$pageTitle  = 'Müşteri Detay';
$activePage = 'customers';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <a href="/customers" class="text-xs text-zinc-500 hover:text-zinc-300 mb-1 inline-block">← Müşteriler</a>
  <h1 id="cust-name">Yükleniyor…</h1>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <div class="card" id="cust-info">
    <div class="skeleton h-48 rounded-lg"></div>
  </div>

  <div class="lg:col-span-2 card">
    <div class="card-header">
      <span class="card-title">Kameralar</span>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kamera</th><th>IP</th><th>Durum</th><th>Konum</th></tr></thead>
        <tbody id="cust-cams">
          <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 4) . '</tr>', 4) ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
const custId = parseInt(location.pathname.split('/').pop());

(async () => {
  try {
    const [cust, cams] = await Promise.all([
      App.get('/customers/' + custId),
      App.get('/customers/' + custId + '/cameras'),
    ]);
    document.getElementById('cust-name').textContent = cust.name;
    document.getElementById('cust-info').innerHTML = `
      <div class="card-header"><span class="card-title">Bilgiler</span></div>
      <div class="space-y-3">
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Ad</span><span class="text-sm font-medium">${cust.name}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">E-posta</span><span class="text-sm">${cust.email || '—'}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Telefon</span><span class="text-sm">${cust.phone || '—'}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Eklenme</span><span class="text-sm text-zinc-400">${App.fmtDate(cust.createdAt)}</span></div>
      </div>`;

    const list = Array.isArray(cams) ? cams : [];
    const tbody = document.getElementById('cust-cams');
    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="text-zinc-500 text-center py-4">Bu müşteriye ait kamera yok</td></tr>';
      return;
    }
    tbody.innerHTML = list.map(c => `<tr>
      <td><a href="/cameras/${c.id}" class="text-blue-400 hover:underline">${c.name}</a></td>
      <td class="font-mono text-zinc-400">${c.ip}</td>
      <td>${App.statusBadge(c.status)}</td>
      <td class="text-zinc-500">${c.location || '—'}</td>
    </tr>`).join('');
  } catch(e) {
    App.toast('Yüklenemedi: ' + e.message, 'error');
  }
})();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
