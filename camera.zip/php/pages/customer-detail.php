<?php
$pageTitle  = 'Müşteri Detay';
$activePage = 'customers';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <a href="/customers" class="text-xs text-zinc-500 hover:text-zinc-300 mb-1 inline-block">← Müşteriler</a>
    <h1 id="cust-name">Yükleniyor…</h1>
  </div>
  <div id="header-actions" class="hidden">
    <button class="btn btn-secondary btn-sm" onclick="openEditQuota()">⚙ Kayıt Kotasını Düzenle</button>
  </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

  <!-- Sol: Müşteri Bilgileri + Kota -->
  <div class="space-y-4">
    <div class="card" id="cust-info">
      <div class="skeleton h-48 rounded-lg"></div>
    </div>
    <div class="card" id="cust-storage">
      <div class="skeleton h-32 rounded-lg"></div>
    </div>
  </div>

  <!-- Sağ: Kameralar + Kamera Bazlı Doluluk -->
  <div class="lg:col-span-2 space-y-4">
    <div class="card">
      <div class="card-header"><span class="card-title">Kameralar</span></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Kamera</th><th>IP</th><th>Durum</th><th>Kayıt Kullanımı</th><th>Konum</th></tr></thead>
          <tbody id="cust-cams">
            <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 5) . '</tr>', 4) ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

<script>
const custId = parseInt(location.pathname.split('/').pop());
let custData = null;
// superadmin kontrolü: __ROLE__ sunucu tarafından yerleştirilebilir,
// yoksa localStorage token decode ile bakıyoruz
function isSuperAdmin() {
  try {
    const t = window.__TOKEN__;
    if (!t) return false;
    const p = JSON.parse(atob(t.split('.')[1]));
    return p.role === 'superadmin';
  } catch { return false; }
}

(async () => {
  try {
    const [cust, cams, stats] = await Promise.all([
      App.get('/customers/' + custId),
      App.get('/customers/' + custId + '/cameras'),
      App.get('/recordings/storage-stats').catch(() => []),
    ]);
    custData = cust;
    document.getElementById('cust-name').textContent = cust.name;

    // Header buton: sadece superadmin görsün
    if (isSuperAdmin()) {
      document.getElementById('header-actions').classList.remove('hidden');
    }

    // ── Müşteri Bilgi Kartı ──────────────────────────────────────────────────
    document.getElementById('cust-info').innerHTML = `
      <div class="card-header">
        <span class="card-title">Bilgiler</span>
        ${isSuperAdmin() ? `<button class="btn btn-ghost btn-xs text-zinc-400" onclick="openEditInfo()">✏️</button>` : ''}
      </div>
      <div class="space-y-3">
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Ad</span><span class="text-sm font-medium">${cust.name}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">E-posta</span><span class="text-sm">${cust.email || '—'}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Telefon</span><span class="text-sm">${cust.phone || '—'}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Kamera sayısı</span><span class="text-sm font-medium">${cust.cameraCount}</span></div>
        <div class="flex justify-between"><span class="text-zinc-500 text-sm">Eklenme</span><span class="text-sm text-zinc-400">${App.fmtDate(cust.createdAt)}</span></div>
      </div>`;

    // ── Depolama Kota Özeti ──────────────────────────────────────────────────
    const limitGb = cust.storageLimitGbPerCamera ?? 10;
    const camIds  = (Array.isArray(cams) ? cams : []).map(c => c.id);
    const camStats= Array.isArray(stats) ? stats.filter(s => camIds.includes(s.cameraId)) : [];
    const totalUsedBytes = camStats.reduce((s, x) => s + x.usedBytes, 0);
    const totalLimBytes  = limitGb * 1024 * 1024 * 1024 * (camIds.length || 1);
    const pct = totalLimBytes > 0 ? Math.min(100, Math.round(totalUsedBytes / totalLimBytes * 100)) : 0;
    const barColor = pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-yellow-500' : 'bg-blue-500';

    document.getElementById('cust-storage').innerHTML = `
      <div class="card-header">
        <span class="card-title">💾 Depolama Kotası</span>
        ${isSuperAdmin() ? `<button class="btn btn-ghost btn-xs text-zinc-400" onclick="openEditQuota()">✏️ Düzenle</button>` : ''}
      </div>
      <div class="space-y-3">
        <div class="flex justify-between text-sm">
          <span class="text-zinc-400">Kamera başına limit</span>
          <span class="font-semibold text-zinc-100">${limitGb} GB</span>
        </div>
        <div class="flex justify-between text-sm">
          <span class="text-zinc-400">Toplam kullanım</span>
          <span class="text-zinc-200">${fmtBytes(totalUsedBytes)} / ${fmtBytes(totalLimBytes)}</span>
        </div>
        <div class="w-full bg-zinc-800 rounded-full h-2">
          <div class="${barColor} h-2 rounded-full transition-all" style="width:${pct}%"></div>
        </div>
        <p class="text-[11px] text-zinc-500">
          Doluluk %${pct} · Kota dolunca kamera tarafında en eski kayıt otomatik silinir.
        </p>
      </div>`;

    // ── Kameralar Tablosu ────────────────────────────────────────────────────
    const list  = Array.isArray(cams) ? cams : [];
    const tbody = document.getElementById('cust-cams');
    if (!list.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-zinc-500 text-center py-4">Bu müşteriye ait kamera yok</td></tr>';
      return;
    }
    tbody.innerHTML = list.map(c => {
      const cs   = stats.find ? stats.find(s => s.cameraId === c.id) : null;
      const used = cs ? cs.usedBytes : 0;
      const lim  = limitGb * 1024 * 1024 * 1024;
      const pctC = lim > 0 ? Math.min(100, Math.round(used / lim * 100)) : 0;
      const bc   = pctC >= 90 ? 'bg-red-500' : pctC >= 70 ? 'bg-yellow-500' : 'bg-blue-500';
      return `<tr>
        <td><a href="/cameras/${c.id}" class="text-blue-400 hover:underline">${c.name}</a></td>
        <td class="font-mono text-zinc-400">${c.ip}</td>
        <td>${App.statusBadge(c.status)}</td>
        <td style="min-width:140px">
          <div class="flex items-center gap-2">
            <div class="flex-1 bg-zinc-800 rounded-full h-1.5">
              <div class="${bc} h-1.5 rounded-full" style="width:${pctC}%"></div>
            </div>
            <span class="text-[10px] text-zinc-400 shrink-0">${fmtBytes(used)} / ${limitGb}GB</span>
          </div>
        </td>
        <td class="text-zinc-500">${c.location || '—'}</td>
      </tr>`;
    }).join('');

  } catch(e) {
    App.toast('Yüklenemedi: ' + e.message, 'error');
  }
})();

function fmtBytes(b) {
  b = parseInt(b) || 0;
  if (b === 0) return '0 B';
  const u = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(b) / Math.log(1024));
  return (b / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + ' ' + u[i];
}

// ── Müşteri Bilgi Düzenleme ──────────────────────────────────────────────────
function openEditInfo() {
  if (!custData) return;
  App.openModal(`
    <div class="modal-header"><h3>Müşteri Bilgileri</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <form id="edit-info-form">
        <div class="form-group"><label class="form-label">Ad *</label><input name="name" class="form-control" value="${custData.name}" required /></div>
        <div class="form-group"><label class="form-label">E-posta</label><input name="email" type="email" class="form-control" value="${custData.email||''}" /></div>
        <div class="form-group"><label class="form-label">Telefon</label><input name="phone" class="form-control" value="${custData.phone||''}" /></div>
        <div id="edit-info-err" class="text-red-400 text-sm hidden"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitEditInfo()">Kaydet</button>
    </div>`);
}
async function submitEditInfo() {
  const fd  = new FormData(document.getElementById('edit-info-form'));
  const err = document.getElementById('edit-info-err');
  try {
    await App.put('/customers/' + custId, { name: fd.get('name'), email: fd.get('email'), phone: fd.get('phone') });
    App.closeModal(); App.toast('Güncellendi', 'success'); location.reload();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

// ── Kayıt Kotası Düzenleme (sadece superadmin) ───────────────────────────────
function openEditQuota() {
  if (!custData) return;
  const cur = custData.storageLimitGbPerCamera ?? 10;
  App.openModal(`
    <div class="modal-header"><h3>Kayıt Kotasını Düzenle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <p class="text-sm text-zinc-400 mb-4">
        Bu müşterinin <strong class="text-zinc-200">her kamerası</strong> için ayrı bir kayıt alanı kotası belirlenir.
        Kota dolunca yeni kayıt başladığında, o kameranın <strong class="text-zinc-200">en eski kaydı</strong> otomatik olarak silinir.
      </p>
      <div class="form-group">
        <label class="form-label">Kamera Başına Limit (GB)</label>
        <div class="flex items-center gap-2">
          <input id="quota-gb" type="number" class="form-control" value="${cur}" min="1" max="100000" style="max-width:140px" />
          <span class="text-sm text-zinc-500">GB / kamera</span>
        </div>
        <p class="text-xs text-zinc-600 mt-1">Mevcut: ${cur} GB · Minimum 1 GB</p>
      </div>
      <div id="quota-err" class="text-red-400 text-sm hidden"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitEditQuota()">Kaydet</button>
    </div>`);
}
async function submitEditQuota() {
  const val = parseInt(document.getElementById('quota-gb').value);
  const err = document.getElementById('quota-err');
  if (!val || val < 1) { err.textContent = 'En az 1 GB giriniz'; err.classList.remove('hidden'); return; }
  try {
    await App.put('/customers/' + custId, { storageLimitGbPerCamera: val });
    App.closeModal();
    App.toast(`Kota ${val} GB olarak güncellendi`, 'success');
    location.reload();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
