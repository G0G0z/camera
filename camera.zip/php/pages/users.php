<?php
$pageTitle  = 'Kullanıcılar';
$activePage = 'users';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>Kullanıcılar</h1>
    <p>Sistem kullanıcılarını yönetin</p>
  </div>
  <button class="btn btn-primary" onclick="openAddUser()">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Kullanıcı Ekle
  </button>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Ad</th><th>E-posta</th><th>Rol</th><th>Eklenme</th><th style="width:100px">İşlem</th></tr></thead>
      <tbody id="users-tbody">
        <?= str_repeat('<tr>' . str_repeat('<td><div class="skeleton h-4 w-full"></div></td>', 5) . '</tr>', 5) ?>
      </tbody>
    </table>
  </div>
  <div id="users-empty" class="empty-state hidden">
    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    <h3>Kullanıcı bulunamadı</h3>
  </div>
</div>

<script>
const roleLabel = { superadmin: App.badge('Süper Admin','blue'), admin: App.badge('Admin','yellow'), viewer: App.badge('İzleyici','zinc') };

async function loadUsers() {
  const tbody = document.getElementById('users-tbody');
  const empty = document.getElementById('users-empty');
  try {
    const data = await App.get('/users');
    const list = Array.isArray(data) ? data : [];
    if (!list.length) { tbody.innerHTML = ''; empty.classList.remove('hidden'); return; }
    tbody.innerHTML = list.map(u => `<tr>
      <td class="font-medium">${u.name || '—'}</td>
      <td class="text-zinc-400">${u.email}</td>
      <td>${roleLabel[u.role] || App.badge(u.role,'zinc')}</td>
      <td class="text-zinc-500 text-sm">${App.fmtDateShort(u.createdAt)}</td>
      <td><button class="btn btn-ghost btn-sm text-red-400" onclick="deleteUser(${u.id}, '${u.email}')">🗑</button></td>
    </tr>`).join('');
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-red-400">Yüklenemedi: ${e.message}</td></tr>`;
  }
}

function openAddUser() {
  App.openModal(`
    <div class="modal-header"><h3>Kullanıcı Ekle</h3><button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button></div>
    <div class="modal-body">
      <form id="add-user-form">
        <div class="form-group"><label class="form-label">Ad Soyad</label><input name="name" class="form-control" /></div>
        <div class="form-group"><label class="form-label">E-posta *</label><input name="email" type="email" class="form-control" required /></div>
        <div class="form-group"><label class="form-label">Şifre *</label><input name="password" type="password" class="form-control" required minlength="6" /></div>
        <div class="form-group"><label class="form-label">Rol</label>
          <select name="role" class="form-control">
            <option value="viewer">İzleyici</option>
            <option value="admin">Admin</option>
            <option value="superadmin">Süper Admin</option>
          </select>
        </div>
        <div id="add-user-err" class="text-red-400 text-sm hidden"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitAddUser()">Ekle</button>
    </div>`);
}

async function submitAddUser() {
  const fd  = new FormData(document.getElementById('add-user-form'));
  const err = document.getElementById('add-user-err');
  try {
    await App.post('/users', { name: fd.get('name'), email: fd.get('email'), password: fd.get('password'), role: fd.get('role') });
    App.closeModal(); App.toast('Kullanıcı eklendi','success'); loadUsers();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

async function deleteUser(id, email) {
  App.confirm(`"${email}" kullanıcısını silmek istediğinize emin misiniz?`, async () => {
    try { await App.del('/users/' + id); App.toast('Kullanıcı silindi','success'); loadUsers(); }
    catch(e) { App.toast('Silinemedi: ' + e.message,'error'); }
  });
}

loadUsers();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
