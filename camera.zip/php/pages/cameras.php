<?php
$pageTitle  = 'Kameralar';
$activePage = 'cameras';
require __DIR__ . '/../layout.php';
?>

<div class="page-header-row page-header">
  <div>
    <h1>Kameralar</h1>
    <p>Bağlı tüm kameraları yönetin</p>
  </div>
  <button class="btn btn-primary" onclick="openAddCamera()">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Kamera Ekle
  </button>
</div>

<div id="cameras-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
  <?php for ($i = 0; $i < 6; $i++): ?>
    <div class="card skeleton h-52"></div>
  <?php endfor ?>
</div>

<script>
async function loadCameras() {
  const grid = document.getElementById('cameras-grid');
  try {
    const cameras = await App.get('/cameras');
    const list = Array.isArray(cameras) ? cameras : [];
    if (!list.length) {
      grid.innerHTML = `
        <div class="col-span-full card">
          <div class="empty-state">
            <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
            <h3>Kamera bulunamadı</h3>
            <p>Yukarıdaki butonu kullanarak ilk kameranızı ekleyin.</p>
          </div>
        </div>`;
      return;
    }
    grid.innerHTML = list.map(cam => `
      <a href="/cameras/${cam.id}" class="camera-card block bg-zinc-900 hover:no-underline">
        <div class="camera-thumb bg-zinc-950 flex items-center justify-center text-zinc-700">
          ${cam.snapshotUrl
            ? `<img src="${cam.snapshotUrl}" class="w-full h-full object-cover" />`
            : `<svg class="w-10 h-10 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>`}
          <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,.65),transparent);pointer-events:none"></div>
          <div style="position:absolute;top:.75rem;left:.75rem;">${App.statusBadge(cam.status)}</div>
          <div style="position:absolute;bottom:.75rem;left:.75rem;right:.75rem">
            <div class="text-white text-sm font-semibold truncate drop-shadow">${cam.name}</div>
            <div class="text-white/60 text-xs truncate">${cam.location || cam.ip}</div>
          </div>
        </div>
        <div class="p-3 flex items-center gap-4 text-xs text-zinc-500">
          <span class="${cam.ptzEnabled ? 'text-blue-400 font-medium' : 'opacity-40'}">PTZ</span>
          <span class="${cam.recordingEnabled ? 'text-red-400 font-medium' : 'opacity-40'}">● REC</span>
          <span class="ml-auto">${cam.ip}</span>
        </div>
      </a>`).join('');
  } catch (e) {
    grid.innerHTML = `<div class="col-span-full text-red-400 text-sm card">Kameralar yüklenemedi: ${e.message}</div>`;
  }
}

function openAddCamera() {
  App.openModal(`
    <div class="modal-header">
      <h3>Kamera Ekle</h3>
      <button class="btn btn-ghost btn-sm" onclick="App.closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <form id="add-cam-form">
        <div class="grid grid-cols-2 gap-4">
          <div class="form-group col-span-2"><label class="form-label">Kamera Adı *</label><input name="name" class="form-control" required placeholder="Ön Kapı" /></div>
          <div class="form-group col-span-2 sm:col-span-1"><label class="form-label">IP Adresi *</label><input name="ip" class="form-control" required placeholder="192.168.1.100" /></div>
          <div class="form-group col-span-2 sm:col-span-1"><label class="form-label">RTSP Port</label><input name="rtspPort" type="number" class="form-control" value="554" /></div>
          <div class="form-group col-span-2 sm:col-span-1"><label class="form-label">Kullanıcı Adı</label><input name="username" class="form-control" placeholder="admin" /></div>
          <div class="form-group col-span-2 sm:col-span-1"><label class="form-label">Şifre</label><input name="password" type="password" class="form-control" /></div>
          <div class="form-group col-span-2"><label class="form-label">Konum</label><input name="location" class="form-control" placeholder="Giriş kapısı" /></div>
        </div>
        <div id="add-cam-err" class="text-red-400 text-sm hidden mb-3"></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
      <button class="btn btn-primary" onclick="submitAddCamera()">Ekle</button>
    </div>`);
}

async function submitAddCamera() {
  const form = document.getElementById('add-cam-form');
  const err  = document.getElementById('add-cam-err');
  const fd   = new FormData(form);
  const body = { name: fd.get('name'), ip: fd.get('ip'), rtspPort: parseInt(fd.get('rtspPort')||'554'), username: fd.get('username'), password: fd.get('password'), location: fd.get('location') };
  try {
    await App.post('/cameras', body);
    App.closeModal();
    App.toast('Kamera eklendi', 'success');
    loadCameras();
  } catch(e) {
    err.textContent = e.message; err.classList.remove('hidden');
  }
}

loadCameras();
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
