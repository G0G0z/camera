<?php
$pageTitle  = 'Profil';
$activePage = '';
require __DIR__ . '/../layout.php';
?>

<div class="page-header">
  <h1>Hesap Ayarları</h1>
  <p>Profil bilgilerinizi ve şifrenizi güncelleyin</p>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

  <!-- Profile update -->
  <div class="card">
    <div class="card-header"><span class="card-title">Profil Bilgileri</span></div>
    <form id="profile-form">
      <div class="form-group"><label class="form-label">Ad Soyad</label><input name="name" id="prof-name" class="form-control" /></div>
      <div class="form-group"><label class="form-label">E-posta</label><input name="email" id="prof-email" type="email" class="form-control" /></div>
      <div id="prof-err" class="text-red-400 text-sm hidden mb-3"></div>
      <button type="button" class="btn btn-primary" onclick="saveProfile()">Kaydet</button>
    </form>
  </div>

  <!-- Password change -->
  <div class="card">
    <div class="card-header"><span class="card-title">Şifre Değiştir</span></div>
    <form id="pass-form">
      <div class="form-group"><label class="form-label">Mevcut Şifre</label><input name="currentPassword" type="password" class="form-control" /></div>
      <div class="form-group"><label class="form-label">Yeni Şifre</label><input name="newPassword" type="password" class="form-control" minlength="6" /></div>
      <div id="pass-err" class="text-red-400 text-sm hidden mb-3"></div>
      <button type="button" class="btn btn-secondary" onclick="changePassword()">Şifreyi Güncelle</button>
    </form>
  </div>

  <!-- Info card -->
  <div class="card lg:col-span-2" id="acc-info">
    <div class="skeleton h-24 rounded-lg"></div>
  </div>

</div>

<script>
(async () => {
  try {
    const me = await App.get('/auth/me');
    document.getElementById('prof-name').value  = me.name  || '';
    document.getElementById('prof-email').value = me.email || '';
    document.getElementById('acc-info').innerHTML = `
      <div class="flex flex-wrap items-center gap-6">
        <div class="w-14 h-14 rounded-full bg-blue-600/20 text-blue-400 text-xl font-bold flex items-center justify-center shrink-0">
          ${(me.name||me.email||'?')[0].toUpperCase()}
        </div>
        <div>
          <div class="text-lg font-semibold">${me.name || '—'}</div>
          <div class="text-zinc-400 text-sm">${me.email}</div>
          <div class="mt-1 flex gap-2">
            ${App.badge(me.role || '—', me.role === 'superadmin' ? 'blue' : me.role === 'admin' ? 'yellow' : 'zinc')}
            <span class="text-xs text-zinc-500">Üyelik: ${App.fmtDateShort(me.createdAt)}</span>
          </div>
        </div>
        <div class="ml-auto">
          <button class="btn btn-danger btn-sm" onclick="App.confirm('Hesabınızı silmek istediğinize emin misiniz? Bu işlem geri alınamaz!', async () => {
            try { await App.del(\'/auth/me\'); await fetch(\'/auth/session\',{method:\'DELETE\'}); location.href=\'/login\'; } catch(e) { App.toast(e.message,\'error\'); }
          })">Hesabı Sil</button>
        </div>
      </div>`;
  } catch(e) { App.toast('Profil yüklenemedi: ' + e.message, 'error'); }
})();

async function saveProfile() {
  const fd  = new FormData(document.getElementById('profile-form'));
  const err = document.getElementById('prof-err');
  err.classList.add('hidden');
  try {
    await App.post('/auth/profile', { name: fd.get('name'), email: fd.get('email') });
    App.toast('Profil güncellendi', 'success');
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}

async function changePassword() {
  const fd  = new FormData(document.getElementById('pass-form'));
  const err = document.getElementById('pass-err');
  err.classList.add('hidden');
  try {
    await App.post('/auth/change-password', { currentPassword: fd.get('currentPassword'), newPassword: fd.get('newPassword') });
    App.toast('Şifre değiştirildi', 'success');
    document.getElementById('pass-form').reset();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
}
</script>

<?php require __DIR__ . '/../layout-footer.php'; ?>
