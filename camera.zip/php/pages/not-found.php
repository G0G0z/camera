<?php
$pageTitle  = '404 — Sayfa Bulunamadı';
$activePage = '';
require __DIR__ . '/../layout.php';
?>

<div class="flex flex-col items-center justify-center py-24 text-center">
  <div class="text-7xl font-black text-zinc-800 mb-4">404</div>
  <h1 class="text-2xl font-bold text-zinc-200 mb-2">Sayfa bulunamadı</h1>
  <p class="text-zinc-500 mb-8">Aradığınız sayfa mevcut değil veya taşınmış.</p>
  <a href="/" class="btn btn-primary">← Dashboard'a Dön</a>
</div>

<?php require __DIR__ . '/../layout-footer.php'; ?>
