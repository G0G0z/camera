  </div><!-- /overflow-y-auto -->
</main>

<!-- Alarm flash overlay -->
<div id="alarm-flash"></div>

<!-- Toast container -->
<div id="toast-container" class="fixed bottom-4 right-4 z-50 space-y-2 pointer-events-none"></div>

<!-- Modal container -->
<div id="modal-overlay" class="fixed inset-0 bg-black/60 z-40 hidden items-center justify-center p-4">
  <div id="modal-box" class="bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
    <div id="modal-content"></div>
  </div>
</div>

</body>
</html>
