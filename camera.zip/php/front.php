<?php
declare(strict_types=1);
session_start();

// ─── Session endpoints ────────────────────────────────────────────────────────
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

// Set session from JS after login
if ($uri === '/auth/session' && $method === 'POST') {
    header('Content-Type: application/json');
    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    if (!empty($body['token'])) {
        $_SESSION['token'] = $body['token'];
        $_SESSION['user']  = $body['user'] ?? null;
        echo json_encode(['ok' => true]);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'token required']);
    }
    exit;
}

// Destroy session on logout
if ($uri === '/auth/session' && $method === 'DELETE') {
    header('Content-Type: application/json');
    session_destroy();
    echo json_encode(['ok' => true]);
    exit;
}

// ─── Auth helpers ─────────────────────────────────────────────────────────────
$token = $_SESSION['token'] ?? null;
$user  = $_SESSION['user']  ?? null;
$isAuth = !empty($token);

// Pages that don't require auth
$publicPages = ['/login', '/register'];
$isPublic = in_array($uri, $publicPages, true) || str_starts_with($uri, '/register');

if (!$isAuth && !$isPublic) {
    header('Location: /login');
    exit;
}

if ($isAuth && in_array($uri, ['/login', '/register'], true)) {
    header('Location: /');
    exit;
}

// ─── Router ──────────────────────────────────────────────────────────────────
$pagesDir = __DIR__ . '/pages';

function routePage(string $uri, bool $isAuth, ?string $token, ?array $user, string $pagesDir): void {
    // Extract path segments
    $parts = array_values(array_filter(explode('/', trim($uri, '/'))));

    if ($uri === '/' || $uri === '') {
        require $pagesDir . '/dashboard.php';
    } elseif ($uri === '/login') {
        require $pagesDir . '/login.php';
    } elseif ($uri === '/register') {
        require $pagesDir . '/register.php';
    } elseif ($uri === '/cameras') {
        require $pagesDir . '/cameras.php';
    } elseif (isset($parts[0], $parts[1]) && $parts[0] === 'cameras' && is_numeric($parts[1])) {
        $cameraId = (int)$parts[1];
        require $pagesDir . '/camera-detail.php';
    } elseif ($uri === '/recordings') {
        require $pagesDir . '/recordings.php';
    } elseif ($uri === '/events') {
        require $pagesDir . '/events.php';
    } elseif ($uri === '/customers') {
        require $pagesDir . '/customers.php';
    } elseif (isset($parts[0], $parts[1]) && $parts[0] === 'customers' && is_numeric($parts[1])) {
        $customerId = (int)$parts[1];
        require $pagesDir . '/customer-detail.php';
    } elseif ($uri === '/users') {
        require $pagesDir . '/users.php';
    } elseif ($uri === '/firmware') {
        require $pagesDir . '/firmware.php';
    } elseif ($uri === '/profile') {
        require $pagesDir . '/profile.php';
    } elseif ($uri === '/wifi-setup') {
        require $pagesDir . '/wifi.php';
    } elseif ($uri === '/setup') {
        require $pagesDir . '/setup.php';
    } elseif ($uri === '/provision') {
        require $pagesDir . '/provision.php';
    } elseif ($uri === '/patrol') {
        require $pagesDir . '/patrol.php';
    } elseif ($uri === '/alarms') {
        require $pagesDir . '/alarms.php';
    } elseif ($uri === '/monitor') {
        require $pagesDir . '/monitor.php';
    } else {
        http_response_code(404);
        require $pagesDir . '/not-found.php';
    }
}

routePage($uri, $isAuth, $token, $user, $pagesDir);
