<?php
declare(strict_types=1);

// ─── Bootstrap (JWT doğrulama için) ──────────────────────────────────────────
require_once __DIR__ . '/config.php';

$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

// ─── Cookie yardımcıları ──────────────────────────────────────────────────────
define('AUTH_COOKIE', 'os_auth');

function setAuthCookie(string $token): void
{
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    setcookie(AUTH_COOKIE, $token, [
        'expires'  => time() + JWT_TTL,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function clearAuthCookie(): void
{
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    setcookie(AUTH_COOKIE, '', [
        'expires'  => time() - 3600,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

// ─── JWT doğrulama (Auth sınıfı olmadan, DB bağımlılığı yok) ─────────────────
function verifyJwt(string $token): ?array
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$hdr, $body, $sig] = $parts;

    $b64d     = fn($d) => base64_decode(strtr($d, '-_', '+/') . str_repeat('=', (4 - strlen($d) % 4) % 4));
    $expected = rtrim(strtr(base64_encode(hash_hmac('sha256', "$hdr.$body", JWT_SECRET, true)), '+/', '-_'), '=');

    if (!hash_equals($expected, $sig)) return null;

    $payload = json_decode($b64d($body), true);
    if (!$payload || ($payload['exp'] ?? 0) < time()) return null;

    return $payload;
}

// ─── Session endpoint: JS login sonrası cookie set eder ──────────────────────
if ($uri === '/auth/session' && $method === 'POST') {
    header('Content-Type: application/json');
    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    if (!empty($body['token'])) {
        setAuthCookie($body['token']);
        echo json_encode(['ok' => true]);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'token required']);
    }
    exit;
}

// ─── Session endpoint: logout ─────────────────────────────────────────────────
if ($uri === '/auth/session' && $method === 'DELETE') {
    header('Content-Type: application/json');
    clearAuthCookie();
    echo json_encode(['ok' => true]);
    exit;
}

// ─── Auth kontrolü ───────────────────────────────────────────────────────────
$token   = $_COOKIE[AUTH_COOKIE] ?? null;
$payload = $token ? verifyJwt($token) : null;
$isAuth  = ($payload !== null);
$user    = $payload ? [
    'id'          => (int)($payload['sub'] ?? 0),
    'email'       => $payload['email']       ?? '',
    'name'        => $payload['name']        ?? '',
    'role'        => $payload['role']        ?? 'viewer',
    'customer_id' => isset($payload['customer_id']) ? (int)$payload['customer_id'] : null,
] : null;

// ─── Yönlendirme ─────────────────────────────────────────────────────────────
$publicPages = ['/login', '/register'];
$isPublic    = in_array($uri, $publicPages, true) || str_starts_with($uri, '/register');

if (!$isAuth && !$isPublic) {
    header('Location: /login');
    exit;
}

if ($isAuth && in_array($uri, ['/login', '/register'], true)) {
    header('Location: /');
    exit;
}

// ─── Router ──────────────────────────────────────────────────────────────────
$pagesDir = __DIR__ . '/pages';

function routePage(string $uri, bool $isAuth, ?string $token, ?array $user, string $pagesDir): void
{
    $parts = array_values(array_filter(explode('/', trim($uri, '/'))));

    if ($uri === '/' || $uri === '') {
        require $pagesDir . '/dashboard.php';
    } elseif ($uri === '/login') {
        require $pagesDir . '/login.php';
    } elseif ($uri === '/register') {
        require $pagesDir . '/register.php';
    } elseif ($uri === '/cameras') {
        require $pagesDir . '/cameras.php';
    } elseif (isset($parts[0], $parts[1]) && $parts[0] === 'cameras' && is_numeric($parts[1])) {
        $cameraId = (int)$parts[1];
        require $pagesDir . '/camera-detail.php';
    } elseif ($uri === '/recordings') {
        require $pagesDir . '/recordings.php';
    } elseif ($uri === '/events') {
        require $pagesDir . '/events.php';
    } elseif ($uri === '/customers') {
        require $pagesDir . '/customers.php';
    } elseif (isset($parts[0], $parts[1]) && $parts[0] === 'customers' && is_numeric($parts[1])) {
        $customerId = (int)$parts[1];
        require $pagesDir . '/customer-detail.php';
    } elseif ($uri === '/users') {
        require $pagesDir . '/users.php';
    } elseif ($uri === '/firmware') {
        require $pagesDir . '/firmware.php';
    } elseif ($uri === '/profile') {
        require $pagesDir . '/profile.php';
    } elseif ($uri === '/wifi-setup') {
        require $pagesDir . '/wifi.php';
    } elseif ($uri === '/setup') {
        require $pagesDir . '/setup.php';
    } elseif ($uri === '/provision') {
        require $pagesDir . '/provision.php';
    } elseif ($uri === '/patrol') {
        require $pagesDir . '/patrol.php';
    } elseif ($uri === '/alarms') {
        require $pagesDir . '/alarms.php';
    } elseif ($uri === '/monitor') {
        require $pagesDir . '/monitor.php';
    } else {
        http_response_code(404);
        require $pagesDir . '/not-found.php';
    }
}

routePage($uri, $isAuth, $token, $user, $pagesDir);
