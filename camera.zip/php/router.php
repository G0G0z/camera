<?php
// PHP built-in server router — replaces .htaccess logic
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Block protected dirs (only when accessing the actual directory/files, not the /recordings page)
if (preg_match('!^/(data|vendor|flashing)/!', $uri) ||
    preg_match('!^/recordings/.!', $uri)) {
    http_response_code(403);
    echo '403 Forbidden';
    exit;
}

// Session & auth endpoints handled by front.php
if ($uri === '/auth/session') {
    require __DIR__ . '/front.php';
    exit;
}

// API requests → index.php
if (str_starts_with($uri, '/api/')) {
    require __DIR__ . '/index.php';
    exit;
}

// Serve existing static files directly (CSS, JS, images, etc.)
$file = __DIR__ . $uri;
if ($uri !== '/' && file_exists($file) && is_file($file)) {
    // Set mime type for common extensions
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $mimes = [
        'css'  => 'text/css',
        'js'   => 'application/javascript',
        'svg'  => 'image/svg+xml',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'ico'  => 'image/x-icon',
        'json' => 'application/json',
        'woff' => 'font/woff',
        'woff2'=> 'font/woff2',
    ];
    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
    }
    return false; // serve natively
}

// All other routes → PHP frontend
require __DIR__ . '/front.php';
