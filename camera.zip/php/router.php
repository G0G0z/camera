<?php
// PHP built-in server router — replaces .htaccess logic
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Block protected dirs
if (preg_match('!^/(data|vendor|flashing)/!', $uri) ||
    preg_match('!^/recordings/.!', $uri)) {
    http_response_code(403);
    echo '403 Forbidden';
    exit;
}

// Session & auth endpoints handled by front.php
if ($uri === '/auth/session') {
    require __DIR__ . '/front.php';
    exit;
}

// API requests → index.php
if (str_starts_with($uri, '/api/')) {
    require __DIR__ . '/index.php';
    exit;
}

// ── Statik dosyalar ────────────────────────────────────────────────────────────
$file = __DIR__ . $uri;
if ($uri !== '/' && file_exists($file) && is_file($file)) {
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    $mimes = [
        'css'   => 'text/css',
        'js'    => 'application/javascript',
        'svg'   => 'image/svg+xml',
        'png'   => 'image/png',
        'jpg'   => 'image/jpeg',
        'jpeg'  => 'image/jpeg',
        'ico'   => 'image/x-icon',
        'json'  => 'application/json',
        'woff'  => 'font/woff',
        'woff2' => 'font/woff2',
        'webp'  => 'image/webp',
    ];

    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
    }

    // ── HTTP önbellekleme ──────────────────────────────────────────────────────
    // İmmutable varlıklar (URL'e ?v= versiyonu eklenerek cache-bust yapılır)
    $immutable = ['css', 'js', 'woff', 'woff2', 'png', 'jpg', 'jpeg', 'webp', 'ico'];
    if (in_array($ext, $immutable, true)) {
        // 1 yıl cache — layout.php ?v= parametresiyle güncellenince yeni URL oluşur
        header('Cache-Control: public, max-age=31536000, immutable');
    } elseif ($ext === 'svg') {
        header('Cache-Control: public, max-age=86400'); // 1 gün
    }

    // ETag: dosya boyutu + mtime hash
    $mtime = filemtime($file);
    $etag  = '"' . dechex($mtime) . '-' . dechex(filesize($file)) . '"';
    header('ETag: ' . $etag);

    // 304 Not Modified kontrolü
    $ifNoneMatch = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
    if ($ifNoneMatch === $etag) {
        http_response_code(304);
        exit;
    }

    // Gzip — tarayıcı destekliyorsa
    header('Vary: Accept-Encoding');

    return false; // built-in server dosyayı servis eder
}

// PHP frontend
require __DIR__ . '/front.php';
