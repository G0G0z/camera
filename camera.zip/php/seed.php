<?php
declare(strict_types=1);
/**
 * Başlangıç verisini oluşturur.
 * Çalıştırma: php seed.php
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/Database.php';
require_once __DIR__ . '/lib/Auth.php';

$db   = Database::getInstance();
$auth = new Auth($db);

// Zaten veri varsa çalıştırma
if (count($db->all('users')) > 0) {
    echo "Veri zaten mevcut, seed atlandı.\n";
    exit;
}

echo "Seed verisi oluşturuluyor...\n";

// ── Müşteriler ────────────────────────────────────────────────────────────────
$c1 = $db->insert('customers', ['name' => 'AVM Güvenlik A.Ş.',  'email' => 'info@avmguvenlik.com', 'phone' => '0212 555 0101']);
$c2 = $db->insert('customers', ['name' => 'Liman Tesisleri',    'email' => 'ops@limantesisleri.com','phone' => '0216 555 0202']);
$c3 = $db->insert('customers', ['name' => 'Hastane Güvenlik',   'email' => 'guvenlik@hastane.com', 'phone' => '0312 555 0303']);

// ── Kullanıcılar ──────────────────────────────────────────────────────────────
$db->insert('users', [
    'email'         => 'admin@example.com',
    'name'          => 'Sistem Yöneticisi',
    'password_hash' => $auth->hashPassword('admin123'),
    'role'          => 'superadmin',
    'customer_id'   => null,
]);
$db->insert('users', [
    'email'         => 'avm@example.com',
    'name'          => 'AVM Sorumlusu',
    'password_hash' => $auth->hashPassword('avm123'),
    'role'          => 'admin',
    'customer_id'   => $c1['id'],
]);
$db->insert('users', [
    'email'         => 'izleyici@example.com',
    'name'          => 'İzleyici',
    'password_hash' => $auth->hashPassword('izleyici123'),
    'role'          => 'viewer',
    'customer_id'   => $c1['id'],
]);

// ── Kameralar ─────────────────────────────────────────────────────────────────
$cams = [
    ['customer_id' => $c1['id'], 'name' => 'Ana Giriş PTZ',   'ip' => '192.168.1.101', 'ptz_enabled' => true,  'location' => 'B Kapısı'],
    ['customer_id' => $c1['id'], 'name' => 'Otopark Kuzeyi',  'ip' => '192.168.1.102', 'ptz_enabled' => true,  'location' => 'Otopark K1'],
    ['customer_id' => $c1['id'], 'name' => 'Mağaza Girişi',   'ip' => '192.168.1.103', 'ptz_enabled' => false, 'location' => 'Kat 1'],
    ['customer_id' => $c2['id'], 'name' => 'Rıhtım PTZ',      'ip' => '10.0.0.201',    'ptz_enabled' => true,  'location' => 'Rıhtım A'],
    ['customer_id' => $c2['id'], 'name' => 'Depo Güneyi',     'ip' => '10.0.0.202',    'ptz_enabled' => false, 'location' => 'Depo 2'],
    ['customer_id' => $c3['id'], 'name' => 'Acil Servis PTZ', 'ip' => '172.16.0.11',   'ptz_enabled' => true,  'location' => 'Acil Giriş'],
];

$statuses = ['online', 'online', 'offline', 'online', 'unknown', 'online'];
foreach ($cams as $i => $cam) {
    $db->insert('cameras', array_merge($cam, [
        'onvif_port'        => 80,
        'rtsp_port'         => 554,
        'username'          => 'admin',
        'password_encrypted'=> base64_encode('admin123'),
        'recording_enabled' => true,
        'status'            => $statuses[$i],
    ]));
}

// ── Kayıtlar ──────────────────────────────────────────────────────────────────
$db->insert('recordings', ['camera_id' => 1, 'status' => 'completed', 'start_time' => date('c', strtotime('-2 hours')), 'end_time' => date('c', strtotime('-1 hour')),  'duration' => 3600, 'trigger' => 'motion']);
$db->insert('recordings', ['camera_id' => 2, 'status' => 'completed', 'start_time' => date('c', strtotime('-5 hours')), 'end_time' => date('c', strtotime('-4 hours')),  'duration' => 3600, 'trigger' => 'schedule']);
$db->insert('recordings', ['camera_id' => 4, 'status' => 'recording', 'start_time' => date('c', strtotime('-30 mins')), 'trigger' => 'manual']);

// ── AI Olayları ───────────────────────────────────────────────────────────────
$types = ['person', 'motion', 'vehicle', 'person', 'tamper', 'motion', 'vehicle', 'person'];
for ($i = 0; $i < 8; $i++) {
    $db->insert('camera_events', [
        'camera_id'  => ($i % 4) + 1,
        'type'       => $types[$i],
        'confidence' => round(0.70 + lcg_value() * 0.29, 2),
        'timestamp'  => date('c', strtotime("-{$i} hours")),
    ]);
}

echo "✓ 3 müşteri\n✓ 3 kullanıcı\n✓ 6 kamera\n✓ 3 kayıt\n✓ 8 AI olayı oluşturuldu.\n";
echo "\nGiriş: admin@example.com / admin123\n";
