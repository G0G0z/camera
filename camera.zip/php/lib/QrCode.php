<?php
declare(strict_types=1);

/**
 * Saf PHP QR Kodu üretici — harici bağımlılık yok.
 * Gereksinimler: PHP 8.0+, GD eklentisi.
 * Desteklenen: byte modu, EC seviyesi M, sürüm 1-15.
 */
class QrCode
{
    // GF(256) tabloları (ilkel polinom x^8+x^4+x^3+x^2+1 = 0x11D)
    private static array $EXP = [];
    private static array $LOG = [];

    // EC seviyesi M: sürüm => [blok_başına_EC_codeword, [[grup_sayısı, veri_cw], ...]]
    private const ECM = [
         1 => [10, [[1, 16]]],
         2 => [16, [[1, 28]]],
         3 => [26, [[1, 44]]],
         4 => [18, [[2, 32]]],
         5 => [24, [[2, 43]]],
         6 => [16, [[4, 27]]],
         7 => [18, [[4, 31]]],
         8 => [22, [[2, 38], [2, 39]]],
         9 => [22, [[3, 36], [2, 37]]],
        10 => [26, [[4, 43], [1, 44]]],
        11 => [30, [[1, 50], [4, 51]]],
        12 => [22, [[6, 36], [2, 37]]],
        13 => [22, [[8, 37], [1, 38]]],
        14 => [24, [[4, 40], [5, 41]]],
        15 => [24, [[5, 41], [5, 42]]],
    ];

    // Hizalama deseni merkez konumları (sürüme göre)
    private const AP = [
         1 => [],
         2 => [6,18],  3 => [6,22],  4 => [6,26],  5 => [6,30],
         6 => [6,34],  7 => [6,22,38],  8 => [6,24,42],  9 => [6,26,46],
        10 => [6,28,50], 11 => [6,30,54], 12 => [6,32,58], 13 => [6,34,62],
        14 => [6,26,46,66], 15 => [6,26,48,70],
    ];

    // ── GF(256) ─────────────────────────────────────────────────────────────

    private static function gfInit(): void
    {
        if (self::$EXP) return;
        $x = 1;
        for ($i = 0; $i < 255; $i++) {
            self::$EXP[$i] = $x;
            self::$LOG[$x]  = $i;
            $x = ($x << 1) ^ (($x & 0x80) ? 0x11D : 0);
            $x &= 0xFF;
        }
        self::$EXP[255] = self::$EXP[0];
    }

    private static function gfMul(int $a, int $b): int
    {
        if ($a === 0 || $b === 0) return 0;
        return self::$EXP[(self::$LOG[$a] + self::$LOG[$b]) % 255];
    }

    // ── Reed-Solomon ─────────────────────────────────────────────────────────

    /** g(x) = (x+α^0)(x+α^1)...(x+α^(n-1)) üret */
    private static function rsGen(int $n): array
    {
        $g = [1];
        for ($i = 0; $i < $n; $i++) {
            $ai = self::$EXP[$i];
            $ng = array_fill(0, count($g) + 1, 0);
            foreach ($g as $k => $c) {
                $ng[$k]     ^= $c;
                $ng[$k + 1] ^= self::gfMul($c, $ai);
            }
            $g = $ng;
        }
        return $g; // uzunluk n+1
    }

    /** data / gen bölümünden kalanı döner (EC codeword'ler) */
    private static function rsRem(array $data, array $gen): array
    {
        $n = count($gen) - 1;
        $r = array_merge($data, array_fill(0, $n, 0));
        foreach ($data as $i => $_) {
            if ($r[$i] === 0) continue;
            $c = $r[$i];
            for ($j = 1; $j <= $n; $j++) {
                $r[$i + $j] ^= self::gfMul($gen[$j], $c);
            }
        }
        return array_slice($r, count($data));
    }

    // ── Kapasite / sürüm seçimi ──────────────────────────────────────────────

    private static function dataCW(int $v): int
    {
        $t = 0;
        foreach (self::ECM[$v][1] as [$cnt, $dcw]) $t += $cnt * $dcw;
        return $t;
    }

    private static function pickVersion(int $len): int
    {
        foreach (self::ECM as $v => [$ecpb, $_]) {
            $bits     = self::dataCW($v) * 8;
            $overhead = 4 + ($v <= 9 ? 8 : 16);
            if ((int)(($bits - $overhead) / 8) >= $len) return $v;
        }
        throw new \OverflowException("Veri çok uzun (maks " . (int)(((self::dataCW(15)*8)-20)/8) . " byte, EC-M v15)");
    }

    // ── Bit akışı kodlaması ──────────────────────────────────────────────────

    private static function encodeStream(string $data, int $v): array
    {
        $len      = strlen($data);
        $cntBits  = $v <= 9 ? 8 : 16;
        $totalCW  = self::dataCW($v);
        $target   = $totalCW * 8;

        $bits  = sprintf('%04b', 4);                      // mod: byte = 0100
        $bits .= sprintf("%0{$cntBits}b", $len);          // karakter sayısı
        for ($i = 0; $i < $len; $i++) {
            $bits .= sprintf('%08b', ord($data[$i]));
        }
        // Sonlandırıcı
        $bits .= str_repeat('0', min(4, max(0, $target - strlen($bits))));
        // Byte sınırına doldur
        while (strlen($bits) % 8) $bits .= '0';
        // Dolgu codeword'leri
        $pads = ['11101100', '00010001'];
        $pi   = 0;
        while (strlen($bits) < $target) $bits .= $pads[$pi++ & 1];

        $cw = [];
        for ($i = 0; $i < strlen($bits); $i += 8) {
            $cw[] = (int)bindec(substr($bits, $i, 8));
        }
        return $cw;
    }

    // ── Codeword karıştırması (data + EC interleave) ─────────────────────────

    private static function buildCW(string $data, int $v): array
    {
        [$ecpb, $groups] = self::ECM[$v];
        $dataCW = self::encodeStream($data, $v);
        $gen    = self::rsGen($ecpb);

        $dBlocks = [];
        $eBlocks = [];
        $off     = 0;
        foreach ($groups as [$cnt, $dcw]) {
            for ($b = 0; $b < $cnt; $b++) {
                $blk       = array_slice($dataCW, $off, $dcw);
                $off      += $dcw;
                $dBlocks[] = $blk;
                $eBlocks[] = self::rsRem($blk, $gen);
            }
        }

        $result = [];
        $maxD   = max(array_map('count', $dBlocks));
        for ($i = 0; $i < $maxD; $i++) {
            foreach ($dBlocks as $b) { if (isset($b[$i])) $result[] = $b[$i]; }
        }
        for ($i = 0; $i < $ecpb; $i++) {
            foreach ($eBlocks as $b) { if (isset($b[$i])) $result[] = $b[$i]; }
        }
        return $result;
    }

    // ── Matris yerleşim yardımcıları ─────────────────────────────────────────

    private static function put(array &$m, array &$r, int $row, int $col, int $v): void
    {
        $m[$row][$col] = $v;
        $r[$row][$col] = true;
    }

    private static function finder(array &$m, array &$r, int $tr, int $tc): void
    {
        static $f = [[1,1,1,1,1,1,1],[1,0,0,0,0,0,1],[1,0,1,1,1,0,1],
                     [1,0,1,1,1,0,1],[1,0,1,1,1,0,1],[1,0,0,0,0,0,1],[1,1,1,1,1,1,1]];
        for ($dr = 0; $dr < 7; $dr++) {
            for ($dc = 0; $dc < 7; $dc++) {
                self::put($m, $r, $tr + $dr, $tc + $dc, $f[$dr][$dc]);
            }
        }
    }

    private static function align(array &$m, array &$r, int $cr, int $cc): void
    {
        static $f = [[1,1,1,1,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,0,0,1],[1,1,1,1,1]];
        for ($dr = -2; $dr <= 2; $dr++) {
            for ($dc = -2; $dc <= 2; $dc++) {
                self::put($m, $r, $cr + $dr, $cc + $dc, $f[$dr+2][$dc+2]);
            }
        }
    }

    // ── BCH format bilgisi (EC-M, maske 0-7) ────────────────────────────────

    private static function fmtInfo(int $mask): int
    {
        // 5-bit veri: EC=M (00) + maske
        $d = $mask;
        $rem = $d << 10;
        for ($i = 14; $i >= 10; $i--) {
            if (($rem >> $i) & 1) $rem ^= (0x537 << ($i - 10));
        }
        return (($d << 10) | ($rem & 0x3FF)) ^ 0x5412;
    }

    // ── BCH sürüm bilgisi (sürüm 7+) ────────────────────────────────────────

    private static function verInfo(int $v): int
    {
        $rem = $v << 12;
        for ($i = 17; $i >= 12; $i--) {
            if (($rem >> $i) & 1) $rem ^= (0x1F25 << ($i - 12));
        }
        return ($v << 12) | ($rem & 0xFFF);
    }

    // ── Format bilgisini matrise yerleştir ───────────────────────────────────

    private static function placeFmt(array &$m, int $mask, int $sz): void
    {
        $fi = self::fmtInfo($mask);
        $f  = [];
        for ($i = 0; $i <= 14; $i++) $f[$i] = ($fi >> $i) & 1;

        // Sol-üst kopya
        $m[8][0] = $f[0]; $m[8][1] = $f[1]; $m[8][2] = $f[2];
        $m[8][3] = $f[3]; $m[8][4] = $f[4]; $m[8][5] = $f[5];
        // col 6 = zamanlama, atla
        $m[8][7] = $f[6]; $m[8][8] = $f[7];
        $m[7][8] = $f[8];
        // row 6 = zamanlama, atla
        $m[5][8] = $f[9];  $m[4][8] = $f[10]; $m[3][8] = $f[11];
        $m[2][8] = $f[12]; $m[1][8] = $f[13]; $m[0][8] = $f[14];

        // Sağ-üst kopya (row 8, rightmost)
        $m[8][$sz-1] = $f[0]; $m[8][$sz-2] = $f[1]; $m[8][$sz-3] = $f[2];
        $m[8][$sz-4] = $f[3]; $m[8][$sz-5] = $f[4]; $m[8][$sz-6] = $f[5];
        $m[8][$sz-7] = $f[6]; $m[8][$sz-8] = $f[7];

        // Sol-alt kopya (col 8, bottom)
        $m[$sz-7][8] = $f[8];  $m[$sz-6][8] = $f[9];  $m[$sz-5][8] = $f[10];
        $m[$sz-4][8] = $f[11]; $m[$sz-3][8] = $f[12]; $m[$sz-2][8] = $f[13];
        $m[$sz-1][8] = $f[14];
    }

    // ── Maske uygula ─────────────────────────────────────────────────────────

    private static function maskOk(int $p, int $r, int $c): bool
    {
        return match ($p) {
            0 => ($r + $c) % 2 === 0,
            1 => $r % 2 === 0,
            2 => $c % 3 === 0,
            3 => ($r + $c) % 3 === 0,
            4 => (intdiv($r, 2) + intdiv($c, 3)) % 2 === 0,
            5 => ($r * $c) % 2 + ($r * $c) % 3 === 0,
            6 => (($r * $c) % 2 + ($r * $c) % 3) % 2 === 0,
            7 => (($r + $c) % 2 + ($r * $c) % 3) % 2 === 0,
        };
    }

    // ── Ceza puanı ───────────────────────────────────────────────────────────

    private static function penalty(array $m, int $sz): int
    {
        $p = 0;
        // Kural 1: 5+ ardışık aynı renk
        for ($i = 0; $i < $sz; $i++) {
            foreach ([true, false] as $h) {
                $run = 1; $prev = $h ? $m[$i][0] : $m[0][$i];
                for ($j = 1; $j < $sz; $j++) {
                    $cur = $h ? $m[$i][$j] : $m[$j][$i];
                    if ($cur === $prev) { $run++; if ($run === 5) $p += 3; elseif ($run > 5) $p++; }
                    else               { $run = 1; $prev = $cur; }
                }
            }
        }
        // Kural 2: 2×2 bloklar
        for ($r = 0; $r < $sz - 1; $r++) {
            for ($c = 0; $c < $sz - 1; $c++) {
                $v = $m[$r][$c];
                if ($v === $m[$r][$c+1] && $v === $m[$r+1][$c] && $v === $m[$r+1][$c+1]) $p += 3;
            }
        }
        // Kural 3: özel desenler
        $pa = [1,0,1,1,1,0,1,0,0,0,0];
        $pb = [0,0,0,0,1,0,1,1,1,0,1];
        for ($r = 0; $r < $sz; $r++) {
            for ($c = 0; $c <= $sz - 11; $c++) {
                $h1=$h2=$v1=$v2=true;
                for ($k = 0; $k < 11; $k++) {
                    if ($m[$r][$c+$k] !== $pa[$k]) $h1 = false;
                    if ($m[$r][$c+$k] !== $pb[$k]) $h2 = false;
                    $rk = $r + $k;
                    if ($rk < $sz) {
                        if ($m[$rk][$c] !== $pa[$k]) $v1 = false;
                        if ($m[$rk][$c] !== $pb[$k]) $v2 = false;
                    } else { $v1 = $v2 = false; }
                }
                if ($h1 || $h2) $p += 40;
                if ($v1 || $v2) $p += 40;
            }
        }
        // Kural 4: karanlık modül oranı
        $dark = 0;
        foreach ($m as $row) $dark += array_sum($row);
        $pct  = $dark * 100.0 / ($sz * $sz);
        $lo   = (int)(floor($pct / 5) * 5);
        $hi   = $lo + 5;
        $p   += (int)(min(abs($lo - 50), abs($hi - 50)) / 5) * 10;
        return $p;
    }

    // ── Tam QR matrisini oluştur ─────────────────────────────────────────────

    private static function build(string $data, int $v): array
    {
        $sz  = $v * 4 + 17;
        $cws = self::buildCW($data, $v);

        $m = array_fill(0, $sz, array_fill(0, $sz, 0));
        $r = array_fill(0, $sz, array_fill(0, $sz, false));

        // Bulucu desenler
        self::finder($m, $r, 0, 0);
        self::finder($m, $r, 0, $sz - 7);
        self::finder($m, $r, $sz - 7, 0);

        // Ayırıcılar
        for ($i = 0; $i <= 7; $i++) {
            self::put($m, $r, 7, $i, 0);           self::put($m, $r, $i, 7, 0);           // TL
            self::put($m, $r, 7, $sz - 1 - $i, 0); self::put($m, $r, $i, $sz - 8, 0);    // TR
            self::put($m, $r, $sz - 8, $i, 0);     self::put($m, $r, $sz - 1 - $i, 7, 0);// BL
        }

        // Zamanlama desenleri
        for ($i = 8; $i <= $sz - 9; $i++) {
            $bit = $i % 2 === 0 ? 1 : 0;
            self::put($m, $r, 6, $i, $bit);
            self::put($m, $r, $i, 6, $bit);
        }

        // Hizalama desenleri (bulucu çakışmaları atla)
        $ap = self::AP[$v];
        foreach ($ap as $ar) {
            foreach ($ap as $ac) {
                if ($ar <= 8 && $ac <= 8)           continue; // TL
                if ($ar <= 8 && $ac >= $sz - 9)     continue; // TR
                if ($ar >= $sz - 9 && $ac <= 8)     continue; // BL
                self::align($m, $r, $ar, $ac);
            }
        }

        // Karanlık modül
        self::put($m, $r, $sz - 8, 8, 1);

        // Format bilgisi alanını rezerve et
        for ($i = 0; $i <= 8; $i++) { $r[8][$i] = true; $r[$i][8] = true; }
        for ($i = 0; $i < 8; $i++)  { $r[8][$sz-1-$i] = true; $r[$sz-1-$i][8] = true; }

        // Sürüm bilgisi (sürüm 7+)
        if ($v >= 7) {
            $vi = self::verInfo($v);
            for ($i = 0; $i < 6; $i++) {
                for ($j = 0; $j < 3; $j++) {
                    $bit = ($vi >> ($i * 3 + $j)) & 1;
                    self::put($m, $r, $sz - 11 + $j, $i, $bit); // BL
                    self::put($m, $r, $i, $sz - 11 + $j, $bit); // TR
                }
            }
        }

        // Veri bitlerini zigzag yerleştir
        $bits = '';
        foreach ($cws as $byte) $bits .= sprintf('%08b', $byte);
        $bi  = 0;
        $dir = -1; // -1=yukarı, 1=aşağı
        $col = $sz - 1;
        while ($col >= 0) {
            if ($col === 6) $col--; // zamanlama sütununu atla
            for ($step = 0; $step < $sz; $step++) {
                $ro = $dir === -1 ? $sz - 1 - $step : $step;
                for ($dc = 0; $dc <= 1; $dc++) {
                    $c = $col - $dc;
                    if ($c >= 0 && !$r[$ro][$c] && $bi < strlen($bits)) {
                        $m[$ro][$c] = (int)$bits[$bi++];
                    }
                }
            }
            $dir = -$dir;
            $col -= 2;
        }

        // En iyi maskeyi bul (en düşük ceza)
        $best  = null;
        $bestP = PHP_INT_MAX;
        for ($mask = 0; $mask < 8; $mask++) {
            $mm = $m;
            for ($ro = 0; $ro < $sz; $ro++) {
                for ($co = 0; $co < $sz; $co++) {
                    if (!$r[$ro][$co] && self::maskOk($mask, $ro, $co)) {
                        $mm[$ro][$co] ^= 1;
                    }
                }
            }
            self::placeFmt($mm, $mask, $sz);
            $p = self::penalty($mm, $sz);
            if ($p < $bestP) { $bestP = $p; $best = $mm; }
        }

        return $best;
    }

    // ── Genel API ────────────────────────────────────────────────────────────

    /**
     * Ham PNG ikili verisi döner.
     * @param string $data    Kodlanacak veri
     * @param int    $scale   Modül başına piksel (varsayılan 8)
     * @param int    $margin  Sessiz bölge modülü sayısı (varsayılan 4)
     */
    public static function png(string $data, int $scale = 8, int $margin = 4): string
    {
        self::gfInit();
        $v   = self::pickVersion(strlen($data));
        $sz  = $v * 4 + 17;
        $mat = self::build($data, $v);

        $px  = ($sz + $margin * 2) * $scale;
        $img = imagecreatetruecolor($px, $px);
        $white = imagecolorallocate($img, 255, 255, 255);
        $black = imagecolorallocate($img, 0,   0,   0);
        imagefilledrectangle($img, 0, 0, $px - 1, $px - 1, $white);

        for ($ro = 0; $ro < $sz; $ro++) {
            for ($co = 0; $co < $sz; $co++) {
                if ($mat[$ro][$co]) {
                    $x = ($co + $margin) * $scale;
                    $y = ($ro + $margin) * $scale;
                    imagefilledrectangle($img, $x, $y, $x + $scale - 1, $y + $scale - 1, $black);
                }
            }
        }

        ob_start();
        imagepng($img);
        imagedestroy($img);
        return (string)ob_get_clean();
    }
}
