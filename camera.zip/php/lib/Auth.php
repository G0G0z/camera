<?php
declare(strict_types=1);

class Auth
{
    public function __construct(private Database $db) {}

    // ── JWT ──────────────────────────────────────────────────────────────────

    public function createToken(array $payload): string
    {
        $header  = $this->b64(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload['iat'] = time();
        $payload['exp'] = time() + JWT_TTL;
        $body    = $this->b64(json_encode($payload));
        $sig     = $this->b64(hash_hmac('sha256', "$header.$body", JWT_SECRET, true));
        return "$header.$body.$sig";
    }

    public function verifyToken(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        [$header, $body, $sig] = $parts;
        $expected = $this->b64(hash_hmac('sha256', "$header.$body", JWT_SECRET, true));
        if (!hash_equals($expected, $sig)) return null;
        $payload = json_decode($this->b64d($body), true);
        if (!$payload || ($payload['exp'] ?? 0) < time()) return null;
        return $payload;
    }

    private function b64(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function b64d(string $data): string
    {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4));
    }

    // ── Middleware ────────────────────────────────────────────────────────────

    /** Require valid JWT — returns user payload or sends 401 */
    public function requireAuth(): array
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!preg_match('/^Bearer\s+(.+)$/i', $header, $m)) {
            Response::abort(401, 'Unauthorized');
        }
        $payload = $this->verifyToken($m[1]);
        if (!$payload) Response::abort(401, 'Invalid or expired token');

        // Refresh user from DB
        $user = $this->db->find('users', (int)$payload['sub']);
        if (!$user) Response::abort(401, 'User not found');

        return $user;
    }

    /** Require role — superadmin | admin | viewer */
    public function requireRole(array $user, string ...$roles): void
    {
        if (!in_array($user['role'], $roles, true)) {
            Response::abort(403, 'Forbidden');
        }
    }

    /** Hash password */
    public function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    /** Verify password */
    public function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }
}
