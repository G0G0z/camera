<?php
declare(strict_types=1);

class Auth
{
    public function __construct(private Database $db) {}

    // ── JWT ──────────────────────────────────────────────────────────────────

    public function createToken(array $payload): string
    {
        $header          = $this->b64(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload['iat']  = time();
        $payload['exp']  = time() + JWT_TTL;
        $body            = $this->b64(json_encode($payload));
        $sig             = $this->b64(hash_hmac('sha256', "$header.$body", JWT_SECRET, true));
        return "$header.$body.$sig";
    }

    public function verifyToken(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        [$header, $body, $sig] = $parts;
        $expected = $this->b64(hash_hmac('sha256', "$header.$body", JWT_SECRET, true));
        if (!hash_equals($expected, $sig)) return null;
        $payload = json_decode($this->b64d($body), true);
        if (!$payload || ($payload['exp'] ?? 0) < time()) return null;
        return $payload;
    }

    private function b64(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function b64d(string $data): string
    {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4));
    }

    // ── Middleware ────────────────────────────────────────────────────────────

    /**
     * JWT'yi doğrular ve claim'leri döndürür.
     * Kullanıcı bilgileri (rol, customer_id, email, name) doğrudan JWT'den
     * okunur — DB'ye gidilmez. Bu sayede her API isteğindeki ekstra disk I/O
     * ortadan kalkar.
     *
     * Token'ın içerdiği claim'ler: sub, role, customer_id, email, name
     * (AuthController::login() tarafından yerleştirilir).
     */
    public function requireAuth(): array
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!preg_match('/^Bearer\s+(.+)$/i', $header, $m)) {
            Response::abort(401, 'Unauthorized');
        }
        $payload = $this->verifyToken($m[1]);
        if (!$payload) Response::abort(401, 'Invalid or expired token');

        // JWT claim'lerini doğrudan dön — DB okuma yok
        return [
            'id'          => (int)($payload['sub'] ?? 0),
            'email'       => $payload['email']       ?? '',
            'name'        => $payload['name']        ?? '',
            'role'        => $payload['role']        ?? 'viewer',
            'customer_id' => isset($payload['customer_id']) && $payload['customer_id'] !== null
                                ? (int)$payload['customer_id']
                                : null,
        ];
    }

    /** Require role — superadmin | admin | viewer */
    public function requireRole(array $user, string ...$roles): void
    {
        if (!in_array($user['role'], $roles, true)) {
            Response::abort(403, 'Forbidden');
        }
    }

    public function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    public function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }
}
