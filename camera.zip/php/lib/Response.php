<?php
declare(strict_types=1);

class Response
{
    public static function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function noContent(): void
    {
        http_response_code(204);
        exit;
    }

    /** Throw an HTTP exception — caught by router */
    public static function abort(int $status, string $message): never
    {
        http_response_code($status);
        echo json_encode(['error' => $message]);
        exit;
    }

    /** Parse request body as JSON */
    public static function body(): array
    {
        $raw = file_get_contents('php://input');
        if (!$raw) return [];
        $data = json_decode($raw, true);
        if (!is_array($data)) return [];
        return $data;
    }

    /** Get query param */
    public static function query(string $key, mixed $default = null): mixed
    {
        return $_GET[$key] ?? $default;
    }
}
