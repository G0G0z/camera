<?php
declare(strict_types=1);

/**
 * Basit ONVIF PTZ SOAP istemcisi.
 * Harici kütüphane gerektirmez.
 */
class Onvif
{
    private string $host;
    private int    $port;
    private string $user;
    private string $pass;

    public function __construct(string $ip, int $port = 80, string $user = 'admin', string $pass = '')
    {
        $this->host = $ip;
        $this->port = $port;
        $this->user = $user;
        $this->pass = $pass;
    }

    // ── PTZ ──────────────────────────────────────────────────────────────────

    public function continuousMove(string $profileToken, float $panX, float $panY, float $zoom = 0.0): bool
    {
        $body = "<ContinuousMove xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <Velocity>
                <PanTilt x=\"{$panX}\" y=\"{$panY}\" xmlns=\"http://www.onvif.org/ver10/schema\"/>
                <Zoom x=\"{$zoom}\" xmlns=\"http://www.onvif.org/ver10/schema\"/>
            </Velocity>
        </ContinuousMove>";

        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    public function stop(string $profileToken): bool
    {
        $body = "<Stop xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <PanTilt>true</PanTilt>
            <Zoom>true</Zoom>
        </Stop>";

        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    public function gotoPreset(string $profileToken, string $presetToken): bool
    {
        $body = "<GotoPreset xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <PresetToken>{$presetToken}</PresetToken>
        </GotoPreset>";

        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    public function setPreset(string $profileToken, string $presetName): ?string
    {
        $body = "<SetPreset xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <PresetName>{$presetName}</PresetName>
        </SetPreset>";

        $resp = $this->soap('/onvif/PTZ', $body);
        if (!$resp) return null;

        preg_match('/<PresetToken[^>]*>([^<]+)<\/PresetToken>/i', $resp, $m);
        return $m[1] ?? null;
    }

    public function gotoHomePosition(string $profileToken): bool
    {
        $body = "<GotoHomePosition xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
        </GotoHomePosition>";

        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    public function getProfiles(): ?array
    {
        $body   = '<GetProfiles xmlns="http://www.onvif.org/ver10/media/wsdl"/>';
        $resp   = $this->soap('/onvif/media', $body);
        if (!$resp) return null;

        preg_match_all('/<Profiles[^>]+token="([^"]+)"/', $resp, $m);
        return $m[1] ?? [];
    }

    public function getSnapshotUri(string $profileToken): ?string
    {
        $body = "<GetSnapshotUri xmlns=\"http://www.onvif.org/ver10/media/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
        </GetSnapshotUri>";

        $resp = $this->soap('/onvif/media', $body);
        if (!$resp) return null;

        preg_match('/<Uri[^>]*>([^<]+)<\/Uri>/i', $resp, $m);
        return $m[1] ?? null;
    }

    public function getStreamUri(string $profileToken): ?string
    {
        $body = "<GetStreamUri xmlns=\"http://www.onvif.org/ver10/media/wsdl\">
            <StreamSetup>
                <Stream xmlns=\"http://www.onvif.org/ver10/schema\">RTP-Unicast</Stream>
                <Transport xmlns=\"http://www.onvif.org/ver10/schema\"><Protocol>RTSP</Protocol></Transport>
            </StreamSetup>
            <ProfileToken>{$profileToken}</ProfileToken>
        </GetStreamUri>";

        $resp = $this->soap('/onvif/media', $body);
        if (!$resp) return null;

        preg_match('/<Uri[^>]*>([^<]+)<\/Uri>/i', $resp, $m);
        return $m[1] ?? null;
    }

    // ── Focus / Iris ─────────────────────────────────────────────────────────

    /** Focus'u sürekli hareket ettirir: pozitif = uzak, negatif = yakın */
    public function continuousFocus(string $profileToken, float $speed): bool
    {
        $body = "<ContinuousMove xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <Velocity>
                <Focus x=\"{$speed}\" xmlns=\"http://www.onvif.org/ver10/schema\"/>
            </Velocity>
        </ContinuousMove>";
        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    /** Iris sürekli: pozitif = aç, negatif = kapat */
    public function continuousIris(string $profileToken, float $speed): bool
    {
        $body = "<Move xmlns=\"http://www.onvif.org/ver20/imaging/wsdl\">
            <VideoSourceToken>{$profileToken}</VideoSourceToken>
            <Focus><Continuous><Speed>{$speed}</Speed></Continuous></Focus>
        </Move>";
        return $this->soap('/onvif/imaging', $body) !== null;
    }

    /** Focus/Iris hareketini durdur */
    public function stopImaging(string $profileToken): bool
    {
        $body = "<Stop xmlns=\"http://www.onvif.org/ver20/imaging/wsdl\">
            <VideoSourceToken>{$profileToken}</VideoSourceToken>
        </Stop>";
        return $this->soap('/onvif/imaging', $body) !== null;
    }

    /** Otomatik odaklama tetikle */
    public function autoFocus(string $profileToken): bool
    {
        $body = "<SetImagingSettings xmlns=\"http://www.onvif.org/ver20/imaging/wsdl\">
            <VideoSourceToken>{$profileToken}</VideoSourceToken>
            <ImagingSettings>
                <Focus><AutoFocusMode>AUTO</AutoFocusMode></Focus>
            </ImagingSettings>
        </SetImagingSettings>";
        return $this->soap('/onvif/imaging', $body) !== null;
    }

    // ── Preset yönetimi ───────────────────────────────────────────────────────

    /** Kameradaki preset listesini çek */
    public function getPresetsFromCamera(string $profileToken): array
    {
        $body = "<GetPresets xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
        </GetPresets>";
        $resp = $this->soap('/onvif/PTZ', $body);
        if (!$resp) return [];

        preg_match_all('/<Preset[^>]+token="([^"]+)"[^>]*>\s*<Name>([^<]+)<\/Name>/si', $resp, $m);
        $result = [];
        foreach ($m[1] as $i => $tok) {
            $result[] = ['token' => $tok, 'name' => trim($m[2][$i])];
        }
        return $result;
    }

    /** Preset sil */
    public function removePreset(string $profileToken, string $presetToken): bool
    {
        $body = "<RemovePreset xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <PresetToken>{$presetToken}</PresetToken>
        </RemovePreset>";
        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    /** Mevcut konumu ev pozisyonu olarak kaydet */
    public function setHomePosition(string $profileToken): bool
    {
        $body = "<SetHomePosition xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
        </SetHomePosition>";
        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    /** Mutlak pozisyona git (-1…+1 arası) */
    public function absoluteMove(string $profileToken, float $panX, float $panY, float $zoom = 0.0): bool
    {
        $body = "<AbsoluteMove xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\">
            <ProfileToken>{$profileToken}</ProfileToken>
            <Position>
                <PanTilt x=\"{$panX}\" y=\"{$panY}\" xmlns=\"http://www.onvif.org/ver10/schema\"/>
                <Zoom x=\"{$zoom}\" xmlns=\"http://www.onvif.org/ver10/schema\"/>
            </Position>
        </AbsoluteMove>";
        return $this->soap('/onvif/PTZ', $body) !== null;
    }

    // ── SOAP yardımcı ─────────────────────────────────────────────────────────

    private function soap(string $path, string $body): ?string
    {
        $nonce    = base64_encode(random_bytes(16));
        $created  = gmdate('Y-m-d\TH:i:s\Z');
        $digest   = base64_encode(sha1($nonce . $created . $this->pass, true));

        $envelope = '<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
            xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
  <s:Header>
    <wsse:Security>
      <wsse:UsernameToken>
        <wsse:Username>' . htmlspecialchars($this->user) . '</wsse:Username>
        <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">' . $digest . '</wsse:Password>
        <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">' . base64_encode($nonce) . '</wsse:Nonce>
        <wsu:Created>' . $created . '</wsu:Created>
      </wsse:UsernameToken>
    </wsse:Security>
  </s:Header>
  <s:Body>' . $body . '</s:Body>
</s:Envelope>';

        $url  = "http://{$this->host}:{$this->port}{$path}";
        $ctx  = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/soap+xml; charset=utf-8\r\nContent-Length: " . strlen($envelope),
                'content' => $envelope,
                'timeout' => 5,
            ],
        ]);

        $resp = @file_get_contents($url, false, $ctx);
        return $resp !== false ? $resp : null;
    }
}
