<?php
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use phpseclib3\Net\SSH2;
use phpseclib3\Exception\UnableToConnectException;

/**
 * OpenIPC kamera yöneticisi.
 * SSH bağlantısı için phpseclib3 (saf PHP, extension gerektirmez).
 * Port kontrolü için curl kullanılır.
 */
class OpenIpc
{
    private string $ip;
    private int    $port;
    private string $user;
    private string $pass;

    // OpenIPC varsayılan bilgileri
    public const DEFAULT_USER = 'root';
    public const DEFAULT_PASS = '12345';
    public const DEFAULT_SSH  = 22;
    public const DEFAULT_WEB  = 80;
    public const RTSP_PORT    = 554;

    // Desteklenen SoC'lar ve firmware URL'leri
    public const SUPPORTED_SOC = [
        'gk7205v300' => [
            'name'     => 'Goke GK7205V300',
            'sensors'  => ['imx335', 'imx415'],
            'flash'    => '16m',
            'url_base' => 'https://github.com/OpenIPC/firmware/releases/download/latest',
            'files'    => [
                'uboot'  => 'openipc.gk7205v300-br.{flash}.uboot',
                'rootfs' => 'openipc.gk7205v300-br.{flash}.tgz',
            ],
            'uboot_cmds' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "setenv netmask 255.255.255.0",
                "run setnor16m",
                "run uknor16m",
            ],
        ],
        'gk7205v200' => [
            'name'     => 'Goke GK7205V200',
            'sensors'  => ['imx307', 'imx335'],
            'flash'    => '8m',
            'url_base' => 'https://github.com/OpenIPC/firmware/releases/download/latest',
            'uboot_cmds' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "run setnor8m",
                "run uknor8m",
            ],
        ],
        'hi3516ev300' => [
            'name'    => 'HiSilicon Hi3516EV300',
            'sensors' => ['imx335'],
            'flash'   => '16m',
            'uboot_cmds' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "run setnor16m",
                "run uknor16m",
            ],
        ],

        // ── XiongMai XM530 (ANA HEDEF SoC) ──────────────────────────────────────
        'xm530' => [
            'name'     => 'XiongMai XM530',
            'sensors'  => ['sc2235', 'imx307', 'ov2718', 'gc2053'],
            'flash'    => '8m',
            'url_base' => 'https://github.com/OpenIPC/firmware/releases/download/latest',
            'files'    => [
                'uboot'  => 'openipc.xm530-br.8m.uboot',
                'rootfs' => 'openipc.xm530-br.8m.tgz',
            ],
            'notes'    => 'XiongMai XM530 — 2MP SoC. UART: 115200 8N1. TX/RX/GND pinleri kartın kenarında. U-Boot: güç verince 1-2 sn içinde Enter.',
            'uart'     => ['baud' => 115200, 'bits' => 8, 'parity' => 'N', 'stop' => 1],
            'uboot_cmds' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "setenv netmask 255.255.255.0",
                "run setnor8m",
                "run uknor8m",
            ],
            'uboot_cmds_manual' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "setenv netmask 255.255.255.0",
                "tftpboot 0x82000000 openipc.xm530-br.8m.uboot",
                "sf probe 0",
                "sf erase 0x0 0x50000",
                "sf write 0x82000000 0x0 \${filesize}",
                "tftpboot 0x82000000 openipc.xm530-br.8m.tgz",
                "sf erase 0x50000 0x7b0000",
                "sf write 0x82000000 0x50000 \${filesize}",
                "reset",
            ],
        ],
        'xm550' => [
            'name'     => 'XiongMai XM550',
            'sensors'  => ['imx335', 'gc4653'],
            'flash'    => '16m',
            'notes'    => 'XM550 — XiongMai 4MP SoC. 16MB NOR flash.',
            'uboot_cmds' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "run setnor16m",
                "run uknor16m",
            ],
        ],
        'xm580' => [
            'name'     => 'XiongMai XM580',
            'sensors'  => ['imx415', 'imx335', 'sc500ai'],
            'flash'    => '16m',
            'notes'    => 'XM580 — XiongMai 5MP SoC. 16MB NOR flash.',
            'uboot_cmds' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "setenv netmask 255.255.255.0",
                "run setnor16m",
                "run uknor16m",
            ],
            'uboot_cmds_manual' => [
                "setenv serverip {serverip}",
                "setenv ipaddr {ipaddr}",
                "tftpboot 0x82000000 openipc.xm580-br.16m.uboot",
                "sf probe 0",
                "sf erase 0x0 0x50000",
                "sf write 0x82000000 0x0 \${filesize}",
                "tftpboot 0x82000000 openipc.xm580-br.16m.tgz",
                "sf erase 0x50000 0xfb0000",
                "sf write 0x82000000 0x50000 \${filesize}",
                "reset",
            ],
        ],
    ];

    public function __construct(string $ip, int $port = self::DEFAULT_SSH, string $user = self::DEFAULT_USER, string $pass = self::DEFAULT_PASS)
    {
        $this->ip   = $ip;
        $this->port = $port;
        $this->user = $user;
        $this->pass = $pass;
    }

    // ── Bağlantı ─────────────────────────────────────────────────────────────

    /**
     * Curl ile TCP port erişilebilirlik kontrolü.
     * fsockopen veya shell araçları gerektirmez.
     */
    public function isReachable(int $timeout = 3): bool
    {
        if (!function_exists('curl_init')) {
            return false;
        }
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => "http://{$this->ip}:{$this->port}",
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_NOBODY         => true,
            CURLOPT_RETURNTRANSFER => true,
        ]);
        curl_exec($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        // CURLE_COULDNT_CONNECT (7) → port kapalı, diğer hatalar porta ulaşıldı demek
        return $errno !== CURLE_COULDNT_CONNECT;
    }

    // ── SSH komut çalıştırma (phpseclib3 — saf PHP) ──────────────────────────

    public function exec(string $command): array
    {
        try {
            $ssh = new SSH2($this->ip, $this->port, 5);
            if (!$ssh->login($this->user, $this->pass)) {
                return ['success' => false, 'output' => 'SSH kimlik doğrulaması başarısız'];
            }
            $output = $ssh->exec($command);
            $ssh->disconnect();
            return ['success' => true, 'output' => $output];
        } catch (UnableToConnectException $e) {
            return ['success' => false, 'output' => 'SSH bağlantısı kurulamadı: ' . $e->getMessage()];
        } catch (\Throwable $e) {
            return ['success' => false, 'output' => 'SSH hatası: ' . $e->getMessage()];
        }
    }

    // ── Sistem bilgisi al ─────────────────────────────────────────────────────

    public function getSystemInfo(): array
    {
        $cmds = [
            'hostname'       => 'hostname',
            'uptime'         => 'uptime -s',
            'firmware'       => 'cat /etc/openipc_version 2>/dev/null || echo unknown',
            'kernel'         => 'uname -r',
            'soc'            => 'cat /proc/cpuinfo | grep -i "Hardware" | head -1',
            'sensor'         => 'cli -g .isp.sensorConfig 2>/dev/null | head -1 || echo unknown',
            'ip'             => 'ip addr show eth0 | grep "inet " | awk \'{print $2}\'',
            'mac'            => 'cat /sys/class/net/eth0/address',
            'majestic_run'   => 'pidof majestic && echo running || echo stopped',
            'free_space'     => 'df -h / | tail -1',
        ];

        $info = [];
        foreach ($cmds as $key => $cmd) {
            $r = $this->exec($cmd);
            $info[$key] = trim($r['output'] ?? '');
        }
        return $info;
    }

    // ── Majestic streamer yapılandırma ────────────────────────────────────────

    public function getMajesticConfig(): array
    {
        $r = $this->exec('cat /etc/majestic.yaml');
        if (!$r['success']) return ['error' => $r['output']];

        $lines   = explode("\n", $r['output']);
        $config  = [];
        $section = '';
        foreach ($lines as $line) {
            if (preg_match('/^([a-zA-Z][^:]+):$/', trim($line), $m)) {
                $section = trim($m[1]);
                $config[$section] = [];
            } elseif (preg_match('/^\s+([^:]+):\s*(.*)$/', $line, $m)) {
                $config[$section][trim($m[1])] = trim($m[2]);
            }
        }
        return ['config' => $config, 'raw' => $r['output']];
    }

    public function setMajesticValue(string $section, string $key, string $value): bool
    {
        $path = ".{$section}.{$key}";
        $r    = $this->exec("cli -s " . escapeshellarg($path) . " " . escapeshellarg($value));
        return $r['success'];
    }

    public function restartMajestic(): bool
    {
        $r = $this->exec('killall -1 majestic 2>/dev/null; sleep 1; majestic &');
        return $r['success'];
    }

    // ── Ağ yapılandırma ───────────────────────────────────────────────────────

    public function setNetworkStatic(string $ip, string $mask = '255.255.255.0', string $gateway = ''): bool
    {
        $gw = $gateway ?: (preg_replace('/\.\d+$/', '.1', $ip));
        $r  = $this->exec(
            "fw_setenv ipaddr $ip; " .
            "fw_setenv netmask $mask; " .
            "fw_setenv gatewayip $gw; " .
            "cli -s .network.ipaddr $ip; " .
            "cli -s .network.netmask $mask; " .
            "cli -s .network.gateway $gw"
        );
        return $r['success'];
    }

    public function setHostname(string $hostname): bool
    {
        $r = $this->exec("hostname $hostname; cli -s .system.hostname $hostname");
        return $r['success'];
    }

    // ── Parola değiştir ───────────────────────────────────────────────────────

    public function changePassword(string $newPassword): bool
    {
        $safe = escapeshellarg("root:$newPassword");
        $r    = $this->exec("echo $safe | chpasswd");
        return $r['success'];
    }

    // ── RTSP URL üret ─────────────────────────────────────────────────────────

    public function getRtspUrl(int $channel = 0): string
    {
        return "rtsp://{$this->user}:{$this->pass}@{$this->ip}:" . self::RTSP_PORT . "/stream{$channel}";
    }

    // ── Otomatik kurulum (flash sonrası ilk yapılandırma) ─────────────────────

    public function autoSetup(array $options): array
    {
        $results = [];

        if (!empty($options['hostname'])) {
            $results['hostname'] = $this->setHostname($options['hostname']);
        }

        if (!empty($options['static_ip'])) {
            $results['network'] = $this->setNetworkStatic(
                $options['static_ip'],
                $options['netmask'] ?? '255.255.255.0',
                $options['gateway'] ?? ''
            );
        }

        if (!empty($options['new_password'])) {
            $results['password'] = $this->changePassword($options['new_password']);
        }

        if (!empty($options['bitrate'])) {
            $results['bitrate'] = $this->setMajesticValue('video0', 'bitrate', (string)$options['bitrate']);
        }
        if (!empty($options['fps'])) {
            $results['fps'] = $this->setMajesticValue('video0', 'fps', (string)$options['fps']);
        }
        if (!empty($options['codec'])) {
            $results['codec'] = $this->setMajesticValue('video0', 'codec', $options['codec']);
        }

        if (!empty($options['ntp_server'])) {
            $this->exec("cli -s .system.ntpServer " . escapeshellarg($options['ntp_server']));
            $results['ntp'] = true;
        }

        $results['restart'] = $this->restartMajestic();

        return $results;
    }

    // ── Firmware güncelle ─────────────────────────────────────────────────────

    public function updateFirmware(): array
    {
        $r = $this->exec('sysupgrade --force_ver -k -r 2>&1 &');
        return ['started' => $r['success'], 'output' => $r['output']];
    }

    public function getFirmwareVersion(): string
    {
        $r = $this->exec('cat /etc/openipc_version 2>/dev/null || echo "unknown"');
        return trim($r['output']);
    }
}
