<?php
declare(strict_types=1);

/**
 * JSON tabanlı basit veritabanı.
 * Her tablo = DATA_DIR/{table}.json dosyası.
 * Framework, composer veya herhangi bir extension gerektirmez.
 */
class Database
{
    private static ?self $instance = null;
    private array $cache = [];

    private function __construct()
    {
        if (!is_dir(DATA_DIR)) {
            mkdir(DATA_DIR, 0755, true);
        }
    }

    public static function getInstance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    // ── Dosya yolu ────────────────────────────────────────────────────────────

    private function path(string $table): string
    {
        return DATA_DIR . '/' . $table . '.json';
    }

    // ── Okuma ─────────────────────────────────────────────────────────────────

    public function all(string $table): array
    {
        if (isset($this->cache[$table])) return $this->cache[$table];

        $file = $this->path($table);
        if (!file_exists($file)) return [];

        $data = json_decode(file_get_contents($file), true) ?? [];
        $this->cache[$table] = $data;
        return $data;
    }

    public function find(string $table, int $id): ?array
    {
        foreach ($this->all($table) as $row) {
            if ((int)($row['id'] ?? 0) === $id) return $row;
        }
        return null;
    }

    public function findBy(string $table, string $field, mixed $value): ?array
    {
        foreach ($this->all($table) as $row) {
            if (($row[$field] ?? null) == $value) return $row;
        }
        return null;
    }

    public function where(string $table, array $conditions): array
    {
        return array_values(array_filter(
            $this->all($table),
            function (array $row) use ($conditions): bool {
                foreach ($conditions as $field => $value) {
                    if ($value === null) {
                        if (($row[$field] ?? 'NOT_NULL') !== null) return false;
                    } elseif (($row[$field] ?? null) != $value) {
                        return false;
                    }
                }
                return true;
            }
        ));
    }

    // ── Yazma ─────────────────────────────────────────────────────────────────

    private function save(string $table, array $data): void
    {
        $this->cache[$table] = array_values($data);
        file_put_contents(
            $this->path($table),
            json_encode(array_values($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    /** Yeni kayıt ekle — ID otomatik atanır, kaydı döner */
    public function insert(string $table, array $row): array
    {
        $rows  = $this->all($table);
        $maxId = 0;
        foreach ($rows as $r) {
            if ((int)($r['id'] ?? 0) > $maxId) $maxId = (int)$r['id'];
        }
        $row['id'] = $maxId + 1;
        if (!isset($row['created_at'])) {
            $row['created_at'] = date('c');
        }
        $rows[] = $row;
        $this->save($table, $rows);
        return $row;
    }

    /** Kayıt güncelle — güncellenmiş kaydı döner veya null */
    public function update(string $table, int $id, array $changes): ?array
    {
        $rows = $this->all($table);
        $found = false;
        foreach ($rows as &$row) {
            if ((int)($row['id'] ?? 0) === $id) {
                $row   = array_merge($row, $changes);
                $found = true;
                $updated = $row;
                break;
            }
        }
        unset($row);
        if (!$found) return null;
        $this->save($table, $rows);
        return $updated;
    }

    /** Kayıt sil — başarılı ise true */
    public function delete(string $table, int $id): bool
    {
        $rows = $this->all($table);
        $new  = array_filter($rows, fn($r) => (int)($r['id'] ?? 0) !== $id);
        if (count($new) === count($rows)) return false;
        $this->save($table, $new);
        return true;
    }

    /** Alan değerine göre kayıtları sil */
    public function deleteWhere(string $table, string $field, mixed $value): int
    {
        $rows    = $this->all($table);
        $new     = array_filter($rows, fn($r) => ($r[$field] ?? null) != $value);
        $deleted = count($rows) - count($new);
        if ($deleted > 0) $this->save($table, $new);
        return $deleted;
    }

    /** Sayfa + limit ile liste döner */
    public function paginate(string $table, array $conditions = [], int $page = 1, int $limit = 20): array
    {
        $rows  = $conditions ? $this->where($table, $conditions) : $this->all($table);
        $total = count($rows);
        $rows  = array_slice($rows, ($page - 1) * $limit, $limit);
        return ['items' => $rows, 'total' => $total, 'page' => $page];
    }

    /** Cache'i temizle (testler için) */
    public function clearCache(string $table = ''): void
    {
        if ($table) unset($this->cache[$table]);
        else $this->cache = [];
    }
}
