<?php
declare(strict_types=1);

/**
 * PostgreSQL tabanlı veritabanı katmanı.
 * JSON / SQLite ile aynı public API'yi korur — drop-in replacement.
 *
 * Bağlantı: DATABASE_URL ortam değişkeni (Replit managed PostgreSQL)
 */
class Database
{
    private static ?self $instance = null;
    private PDO $pdo;
    /** @var array<string, array<string,string>> tablo → [kolon → tür] */
    private array $meta = [];

    private function __construct()
    {
        $url = getenv('DATABASE_URL');
        if (!$url) {
            throw new \RuntimeException('DATABASE_URL ortam değişkeni tanımlı değil.');
        }

        $p   = parse_url($url);
        $dsn = sprintf(
            'pgsql:host=%s;port=%d;dbname=%s',
            $p['host'],
            $p['port'] ?? 5432,
            ltrim($p['path'] ?? '', '/')
        );

        $this->pdo = new PDO($dsn, $p['user'] ?? null, $p['pass'] ?? null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    public static function getInstance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    // ── Tablo / kolon yönetimi ────────────────────────────────────────────────

    private function ensureTable(string $table): void
    {
        if (isset($this->meta[$table])) return;

        $this->pdo->exec(
            "CREATE TABLE IF NOT EXISTS \"$table\" (" .
            "id SERIAL PRIMARY KEY, " .
            "created_at TEXT DEFAULT to_char(NOW(),'YYYY-MM-DD\"T\"HH24:MI:SSOF')" .
            ")"
        );
        $this->loadMeta($table);
    }

    private function loadMeta(string $table): void
    {
        $s = $this->pdo->prepare(
            "SELECT column_name, data_type
             FROM information_schema.columns
             WHERE table_schema = 'public' AND table_name = ?"
        );
        $s->execute([$table]);
        $cols = [];
        foreach ($s->fetchAll() as $row) {
            $cols[$row['column_name']] = $row['data_type'];
        }
        $this->meta[$table] = $cols;
    }

    private function ensureColumns(string $table, array $row): void
    {
        $existing = $this->meta[$table] ?? [];
        $changed  = false;

        foreach ($row as $col => $val) {
            if ($col === 'id' || isset($existing[$col])) continue;

            if (in_array($col, ['ptz_enabled', 'recording_enabled', 'hidden'], true) || is_bool($val)) {
                $type = 'BOOLEAN';
            } elseif (str_ends_with($col, '_id') || is_int($val)) {
                $type = 'INTEGER';
            } elseif (is_float($val)) {
                $type = 'REAL';
            } else {
                $type = 'TEXT';
            }

            $this->pdo->exec("ALTER TABLE \"$table\" ADD COLUMN IF NOT EXISTS \"$col\" $type");
            $existing[$col] = strtolower($type);
            $changed = true;
        }

        if ($changed) $this->meta[$table] = $existing;
    }

    // ── WHERE yardımcısı ──────────────────────────────────────────────────────

    /** @return array{string, list<mixed>} */
    private function buildWhere(array $conditions): array
    {
        $parts  = [];
        $params = [];

        foreach ($conditions as $field => $value) {
            if ($value === null) {
                $parts[] = "\"$field\" IS NULL";
            } else {
                $parts[] = "\"$field\" = ?";
                $params[] = $value;
            }
        }

        return [$parts ? ' WHERE ' . implode(' AND ', $parts) : '', $params];
    }

    /** PDO execute — bool değerleri düzgün bağlar */
    private function exec(string $sql, array $params = []): \PDOStatement
    {
        $s = $this->pdo->prepare($sql);
        foreach ($params as $i => $v) {
            $idx = $i + 1;
            if (is_bool($v))      $s->bindValue($idx, $v, PDO::PARAM_BOOL);
            elseif (is_null($v))  $s->bindValue($idx, null, PDO::PARAM_NULL);
            elseif (is_int($v))   $s->bindValue($idx, $v, PDO::PARAM_INT);
            else                  $s->bindValue($idx, $v, PDO::PARAM_STR);
        }
        $s->execute();
        return $s;
    }

    // ── Okuma ─────────────────────────────────────────────────────────────────

    public function all(string $table): array
    {
        $this->ensureTable($table);
        return $this->exec("SELECT * FROM \"$table\" ORDER BY id")->fetchAll();
    }

    public function find(string $table, int $id): ?array
    {
        $this->ensureTable($table);
        return $this->exec("SELECT * FROM \"$table\" WHERE id = ?", [$id])->fetch() ?: null;
    }

    public function findBy(string $table, string $field, mixed $value): ?array
    {
        $this->ensureTable($table);

        if ($value === null) {
            return $this->exec("SELECT * FROM \"$table\" WHERE \"$field\" IS NULL LIMIT 1")->fetch() ?: null;
        }
        return $this->exec("SELECT * FROM \"$table\" WHERE \"$field\" = ? LIMIT 1", [$value])->fetch() ?: null;
    }

    public function where(string $table, array $conditions): array
    {
        $this->ensureTable($table);
        [$where, $params] = $this->buildWhere($conditions);
        return $this->exec("SELECT * FROM \"$table\"$where ORDER BY id", $params)->fetchAll();
    }

    // ── Yazma ─────────────────────────────────────────────────────────────────

    public function insert(string $table, array $row): array
    {
        $this->ensureTable($table);

        if (!isset($row['created_at'])) $row['created_at'] = date('c');
        unset($row['id']); // SERIAL atamalı

        $this->ensureColumns($table, $row);

        $cols   = array_keys($row);
        $phs    = implode(', ', array_fill(0, count($cols), '?'));
        $colSql = implode(', ', array_map(fn($c) => "\"$c\"", $cols));
        $sql    = "INSERT INTO \"$table\" ($colSql) VALUES ($phs) RETURNING id";

        $s      = $this->exec($sql, array_values($row));
        $row['id'] = (int)$s->fetchColumn();
        return $row;
    }

    public function update(string $table, int $id, array $changes): ?array
    {
        $this->ensureTable($table);
        $this->ensureColumns($table, $changes);

        $sets   = array_map(fn($c) => "\"$c\" = ?", array_keys($changes));
        $params = array_merge(array_values($changes), [$id]);

        $this->exec(
            "UPDATE \"$table\" SET " . implode(', ', $sets) . " WHERE id = ?",
            $params
        );

        return $this->find($table, $id);
    }

    public function delete(string $table, int $id): bool
    {
        $this->ensureTable($table);
        return $this->exec("DELETE FROM \"$table\" WHERE id = ?", [$id])->rowCount() > 0;
    }

    public function deleteWhere(string $table, string $field, mixed $value): int
    {
        $this->ensureTable($table);

        if ($value === null) {
            return $this->exec("DELETE FROM \"$table\" WHERE \"$field\" IS NULL")->rowCount();
        }
        return $this->exec("DELETE FROM \"$table\" WHERE \"$field\" = ?", [$value])->rowCount();
    }

    public function paginate(string $table, array $conditions = [], int $page = 1, int $limit = 20): array
    {
        $this->ensureTable($table);
        [$where, $params] = $this->buildWhere($conditions);

        $total  = (int)$this->exec("SELECT COUNT(*) FROM \"$table\"$where", $params)->fetchColumn();
        $offset = ($page - 1) * $limit;

        $items = $this->exec(
            "SELECT * FROM \"$table\"$where ORDER BY id LIMIT ? OFFSET ?",
            array_merge($params, [$limit, $offset])
        )->fetchAll();

        return ['items' => $items, 'total' => $total, 'page' => $page];
    }

    /** API uyumluluğu için saklı — PostgreSQL kendi önbelleğini yönetir */
    public function clearCache(string $table = ''): void {}
}
