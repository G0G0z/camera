<?php
declare(strict_types=1);

/**
 * JSON flat-file veritabanı.
 * Her tablo data/{table}.json dosyasında saklanır.
 *
 * Per-request in-memory cache: aynı request içinde aynı tablo ikinci kez
 * okunmaz — tek bir json_decode + file_get_contents yeterlidir.
 * save() cache'i günceller, böylece request boyunca tutarlılık korunur.
 */
class Database
{
    private static ?self $instance = null;
    private string $dir;

    /** Per-request tablo cache'i: ['table' => [...rows]] */
    private array $cache = [];

    private function __construct()
    {
        $this->dir = DATA_DIR;

        if (!is_dir($this->dir)) {
            @mkdir($this->dir, 0755, true);
        }

        $htaccess = $this->dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Order deny,allow\nDeny from all\n");
        }

        $this->maybeBootstrap();
    }

    public static function getInstance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    // ── Dosya yolu ────────────────────────────────────────────────────────────

    private function file(string $table): string
    {
        $safe = preg_replace('/[^a-z0-9_]/', '', strtolower($table));
        return $this->dir . '/' . $safe . '.json';
    }

    // ── Okuma / Yazma ─────────────────────────────────────────────────────────

    /**
     * Tabloyu cache'ten döndürür; yoksa diskten okur ve cache'e alır.
     * Tek bir request içinde aynı tabloyu kaç kez çağırırsanız çağırın:
     * disk I/O ve json_decode sadece bir kez yapılır.
     */
    private function load(string $table): array
    {
        if (array_key_exists($table, $this->cache)) {
            return $this->cache[$table];
        }

        $file = $this->file($table);
        if (!file_exists($file)) {
            return $this->cache[$table] = [];
        }

        $fh = fopen($file, 'rb');
        if (!$fh) return $this->cache[$table] = [];

        // Shared lock — eş zamanlı yazma sırasında yarım veri okunmasını engelle
        flock($fh, LOCK_SH);
        $raw = stream_get_contents($fh);
        flock($fh, LOCK_UN);
        fclose($fh);

        $data = $raw ? json_decode($raw, true) : null;
        return $this->cache[$table] = (is_array($data) ? $data : []);
    }

    /**
     * Diski günceller ve cache'i de günceller (tutarlılık için).
     */
    private function save(string $table, array $rows): void
    {
        $rows = array_values($rows);
        $this->cache[$table] = $rows;          // önce cache'i güncelle

        file_put_contents(
            $this->file($table),
            json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            LOCK_EX
        );
    }

    private function nextId(array $rows): int
    {
        if (empty($rows)) return 1;
        $ids = array_column($rows, 'id');
        return $ids ? (int)max($ids) + 1 : 1;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public function all(string $table): array
    {
        return array_values($this->load($table));
    }

    public function find(string $table, int $id): ?array
    {
        foreach ($this->load($table) as $row) {
            if ((int)($row['id'] ?? 0) === $id) return $row;
        }
        return null;
    }

    public function findBy(string $table, string $field, mixed $value): ?array
    {
        foreach ($this->load($table) as $row) {
            $cell = $row[$field] ?? null;
            $match = $value === null ? $cell === null : (string)$cell === (string)$value;
            if ($match) return $row;
        }
        return null;
    }

    public function where(string $table, array $conditions): array
    {
        $result = [];
        foreach ($this->load($table) as $row) {
            $match = true;
            foreach ($conditions as $k => $v) {
                $cell  = $row[$k] ?? null;
                $ok    = $v === null ? $cell === null : (string)$cell === (string)$v;
                if (!$ok) { $match = false; break; }
            }
            if ($match) $result[] = $row;
        }
        return $result;
    }

    public function insert(string $table, array $row): array
    {
        $rows = $this->load($table);
        $row['id']         ??= $this->nextId($rows);
        $row['created_at'] ??= date('c');
        $rows[] = $row;
        $this->save($table, $rows);
        return $row;
    }

    public function update(string $table, int $id, array $changes): ?array
    {
        $rows = $this->load($table);
        foreach ($rows as &$row) {
            if ((int)($row['id'] ?? 0) === $id) {
                $row = array_merge($row, $changes);
                $this->save($table, $rows);
                return $row;
            }
        }
        return null;
    }

    public function delete(string $table, int $id): bool
    {
        $rows = $this->load($table);
        $new  = array_values(array_filter($rows, fn($r) => (int)($r['id'] ?? 0) !== $id));
        if (count($new) === count($rows)) return false;
        $this->save($table, $new);
        return true;
    }

    public function deleteWhere(string $table, string $field, mixed $value): int
    {
        $rows  = $this->load($table);
        $new   = array_values(array_filter($rows, function ($r) use ($field, $value) {
            $cell = $r[$field] ?? null;
            return $value === null ? $cell !== null : (string)$cell !== (string)$value;
        }));
        $count = count($rows) - count($new);
        if ($count > 0) $this->save($table, $new);
        return $count;
    }

    public function paginate(string $table, array $conditions = [], int $page = 1, int $limit = 20): array
    {
        $all   = empty($conditions) ? $this->all($table) : $this->where($table, $conditions);
        $total = count($all);
        $items = array_slice($all, ($page - 1) * $limit, $limit);
        return ['items' => $items, 'total' => $total, 'page' => $page];
    }

    /** Belirli bir tabloyu ya da tüm cache'i temizle (gerekirse) */
    public function clearCache(string $table = ''): void
    {
        if ($table === '') {
            $this->cache = [];
        } else {
            unset($this->cache[$table]);
        }
    }

    // ── Bootstrap ─────────────────────────────────────────────────────────────

    private function maybeBootstrap(): void
    {
        if (!empty($this->load('users'))) return;

        $hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 10]);
        $this->insert('users', [
            'email'         => 'admin@example.com',
            'name'          => 'Sistem Yöneticisi',
            'password_hash' => $hash,
            'role'          => 'superadmin',
            'customer_id'   => null,
        ]);
    }
}
