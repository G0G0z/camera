<?php
declare(strict_types=1);

/**
 * JSON flat-file veritabanı.
 * Her tablo data/{table}.json dosyasında saklanır.
 * Kurulum gerektirmez — data/ dizini yazılabilir olmalı.
 */
class Database
{
    private static ?self $instance = null;
    private string $dir;

    private function __construct()
    {
        $this->dir = DATA_DIR;

        // data/ dizinini oluştur (ilk çalıştırmada)
        if (!is_dir($this->dir)) {
            @mkdir($this->dir, 0755, true);
        }

        // data/.htaccess — web üzerinden doğrudan erişimi engelle
        $htaccess = $this->dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Order deny,allow\nDeny from all\n");
        }

        // İlk çalıştırmada varsayılan admin kullanıcısını ekle
        $this->maybeBootstrap();
    }

    public static function getInstance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    // ── Dosya yolu ────────────────────────────────────────────────────────────

    private function file(string $table): string
    {
        // Tablo adında yalnızca güvenli karakterlere izin ver
        $safe = preg_replace('/[^a-z0-9_]/', '', strtolower($table));
        return $this->dir . '/' . $safe . '.json';
    }

    // ── Okuma / Yazma ─────────────────────────────────────────────────────────

    private function load(string $table): array
    {
        $file = $this->file($table);
        if (!file_exists($file)) return [];
        $raw = @file_get_contents($file);
        if (!$raw) return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    private function save(string $table, array $rows): void
    {
        file_put_contents(
            $this->file($table),
            json_encode(array_values($rows), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            LOCK_EX
        );
    }

    private function nextId(array $rows): int
    {
        if (empty($rows)) return 1;
        $ids = array_column($rows, 'id');
        return $ids ? (int)max($ids) + 1 : 1;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public function all(string $table): array
    {
        return array_values($this->load($table));
    }

    public function find(string $table, int $id): ?array
    {
        foreach ($this->load($table) as $row) {
            if ((int)($row['id'] ?? 0) === $id) return $row;
        }
        return null;
    }

    public function findBy(string $table, string $field, mixed $value): ?array
    {
        foreach ($this->load($table) as $row) {
            $cellValue = $row[$field] ?? null;
            $matches   = $value === null
                ? $cellValue === null
                : (string)$cellValue === (string)$value;
            if ($matches) return $row;
        }
        return null;
    }

    public function where(string $table, array $conditions): array
    {
        $result = [];
        foreach ($this->load($table) as $row) {
            $match = true;
            foreach ($conditions as $k => $v) {
                $cell    = $row[$k] ?? null;
                $matches = $v === null
                    ? $cell === null
                    : (string)$cell === (string)$v;
                if (!$matches) { $match = false; break; }
            }
            if ($match) $result[] = $row;
        }
        return $result;
    }

    public function insert(string $table, array $row): array
    {
        $rows = $this->load($table);
        $row['id'] ??= $this->nextId($rows);
        $row['created_at'] ??= date('c');
        $rows[] = $row;
        $this->save($table, $rows);
        return $row;
    }

    public function update(string $table, int $id, array $changes): ?array
    {
        $rows = $this->load($table);
        foreach ($rows as &$row) {
            if ((int)($row['id'] ?? 0) === $id) {
                $row = array_merge($row, $changes);
                $this->save($table, $rows);
                return $row;
            }
        }
        return null;
    }

    public function delete(string $table, int $id): bool
    {
        $rows = $this->load($table);
        $new  = array_values(array_filter($rows, fn($r) => (int)($r['id'] ?? 0) !== $id));
        if (count($new) === count($rows)) return false;
        $this->save($table, $new);
        return true;
    }

    public function deleteWhere(string $table, string $field, mixed $value): int
    {
        $rows  = $this->load($table);
        $new   = array_values(array_filter($rows, function ($r) use ($field, $value) {
            $cell = $r[$field] ?? null;
            return $value === null ? $cell !== null : (string)$cell !== (string)$value;
        }));
        $count = count($rows) - count($new);
        if ($count > 0) $this->save($table, $new);
        return $count;
    }

    public function paginate(string $table, array $conditions = [], int $page = 1, int $limit = 20): array
    {
        $all   = empty($conditions) ? $this->all($table) : $this->where($table, $conditions);
        $total = count($all);
        $items = array_slice($all, ($page - 1) * $limit, $limit);
        return ['items' => $items, 'total' => $total, 'page' => $page];
    }

    /** PostgreSQL sürümüyle uyumluluk için — JSON'da gerekmiyor */
    public function clearCache(string $table = ''): void {}

    // ── İlk çalıştırma bootstrap ──────────────────────────────────────────────

    /**
     * users.json yoksa veya boşsa varsayılan admin kullanıcısı ekler.
     * Böylece sunucuya yükleyip tarayıcıyı açmak yeterli olur.
     */
    private function maybeBootstrap(): void
    {
        if (!empty($this->load('users'))) return;

        // Auth sınıfına bağımlılık yoktur — doğrudan bcrypt kullan
        $hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 10]);

        $this->insert('users', [
            'email'         => 'admin@example.com',
            'name'          => 'Sistem Yöneticisi',
            'password_hash' => $hash,
            'role'          => 'superadmin',
            'customer_id'   => null,
        ]);
    }
}
