<?php
declare(strict_types=1);

class Router
{
    private array $routes = [];

    public function get(string $pattern, callable $handler): void
    {
        $this->add('GET', $pattern, $handler);
    }

    public function post(string $pattern, callable $handler): void
    {
        $this->add('POST', $pattern, $handler);
    }

    public function put(string $pattern, callable $handler): void
    {
        $this->add('PUT', $pattern, $handler);
    }

    public function delete(string $pattern, callable $handler): void
    {
        $this->add('DELETE', $pattern, $handler);
    }

    private function add(string $method, string $pattern, callable $handler): void
    {
        // Convert {param} to named capture groups
        $regex = preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[^/]+)', $pattern);
        $regex = '#^' . $regex . '$#';
        $this->routes[] = compact('method', 'pattern', 'regex', 'handler');
    }

    public function dispatch(string $method, string $uri): void
    {
        // Strip query string and decode
        $path = parse_url($uri, PHP_URL_PATH);
        $path = rtrim(rawurldecode($path), '/') ?: '/';

        foreach ($this->routes as $route) {
            if ($route['method'] !== strtoupper($method)) continue;
            if (!preg_match($route['regex'], $path, $matches)) continue;

            // Extract named params
            $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

            try {
                ($route['handler'])($params);
            } catch (Throwable $e) {
                if ($e->getCode() >= 400) {
                    http_response_code($e->getCode());
                    echo json_encode(['error' => $e->getMessage()]);
                } else {
                    http_response_code(500);
                    echo json_encode(['error' => 'Internal server error']);
                    error_log($e->getMessage() . "\n" . $e->getTraceAsString());
                }
            }
            return;
        }

        http_response_code(404);
        echo json_encode(['error' => 'Not found']);
    }
}
