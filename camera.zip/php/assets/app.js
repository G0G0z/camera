// OpticSight — shared frontend JS

const App = (() => {
  // ─── API helpers ──────────────────────────────────────────────────────────
  function token() {
    return window.__TOKEN__ || localStorage.getItem('os_token');
  }

  async function api(method, path, body = null) {
    const opts = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token()}`,
      },
    };
    if (body !== null) opts.body = JSON.stringify(body);
    const res = await fetch('/api' + path, opts);
    if (res.status === 401) {
      await fetch('/auth/session', { method: 'DELETE' });
      window.location.href = '/login';
      return;
    }
    if (!res.ok) {
      let msg = `HTTP ${res.status}`;
      try { const d = await res.json(); msg = d.error || d.message || msg; } catch(e) {}
      throw new Error(msg);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  const get  = (p)    => api('GET',    p);
  const post = (p, b) => api('POST',   p, b);
  const put  = (p, b) => api('PUT',    p, b);
  const del  = (p)    => api('DELETE', p);

  // ─── Toast ────────────────────────────────────────────────────────────────
  function toast(msg, type = 'info') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  // ─── Modal ────────────────────────────────────────────────────────────────
  function openModal(html, wide = false) {
    const box = document.getElementById('modal-box');
    if (wide) box.classList.add('max-w-2xl'); else box.classList.remove('max-w-2xl');
    document.getElementById('modal-content').innerHTML = html;
    document.getElementById('modal-overlay').classList.add('active');
  }
  function closeModal() {
    document.getElementById('modal-overlay').classList.remove('active');
  }
  document.addEventListener('click', e => {
    if (e.target.id === 'modal-overlay') closeModal();
  });

  // ─── Auth ─────────────────────────────────────────────────────────────────
  async function logout() {
    try { await post('/auth/logout'); } catch(e) {}
    await fetch('/auth/session', { method: 'DELETE' });
    localStorage.removeItem('os_token');
    window.location.href = '/login';
  }

  // ─── Skeleton ─────────────────────────────────────────────────────────────
  function skeletonRows(cols, rows = 5) {
    let html = '';
    for (let i = 0; i < rows; i++) {
      html += '<tr>' + Array(cols).fill('<td><div class="skeleton h-4 w-full"></div></td>').join('') + '</tr>';
    }
    return html;
  }
  function skeletonCards(n = 4) {
    return Array(n).fill('<div class="card skeleton h-32"></div>').join('');
  }

  // ─── Format helpers ───────────────────────────────────────────────────────
  function fmtDate(d) {
    if (!d) return '—';
    try { return new Date(d).toLocaleString('tr-TR'); } catch(e) { return d; }
  }
  function fmtDateShort(d) {
    if (!d) return '—';
    try { return new Date(d).toLocaleDateString('tr-TR'); } catch(e) { return d; }
  }
  function fmtDuration(s) {
    if (!s) return '—';
    const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
    if (h > 0) return `${h}s ${m}d`;
    if (m > 0) return `${m}d ${sec}sn`;
    return `${sec}sn`;
  }

  function badge(label, color = 'zinc') {
    return `<span class="badge badge-${color}">${label}</span>`;
  }
  function statusBadge(status) {
    if (status === 'online')  return badge('<span class="dot dot-green dot-pulse"></span> Online', 'green');
    if (status === 'offline') return badge('<span class="dot dot-red"></span> Offline', 'red');
    return badge(status || 'unknown', 'zinc');
  }
  function eventBadge(type) {
    const map = { person: ['blue','👤'], vehicle: ['orange','🚗'], motion: ['yellow','📡'], face: ['purple','🎭'], tamper: ['red','⚠️'] };
    const [col, icon] = map[type] || ['zinc','❓'];
    return badge(`${icon} ${type}`, col);
  }

  // ─── Confirm dialog ───────────────────────────────────────────────────────
  let _pendingConfirm = null;
  function confirm(msg, onOk, label = 'Sil') {
    _pendingConfirm = onOk;
    openModal(`
      <div class="modal-header"><h3>Onay</h3></div>
      <div class="modal-body"><p class="text-zinc-300">${msg}</p></div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
        <button class="btn btn-danger" onclick="App._runConfirm()">${label}</button>
      </div>`);
  }
  function _runConfirm() {
    const cb = _pendingConfirm; _pendingConfirm = null; closeModal(); if (cb) cb();
  }

  // ─── Tabs ─────────────────────────────────────────────────────────────────
  function initTabs(container) {
    const btns   = container.querySelectorAll('.tab-btn');
    const panels = container.querySelectorAll('.tab-panel');
    btns.forEach(btn => {
      btn.addEventListener('click', () => {
        btns.forEach(b => b.classList.remove('active'));
        panels.forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        const panel = container.querySelector('#' + btn.dataset.tab);
        if (panel) panel.classList.add('active');
      });
    });
    if (btns.length) { btns[0].classList.add('active'); if (panels.length) panels[0].classList.add('active'); }
  }

  return { token, api, get, post, put, del, toast, openModal, closeModal, logout,
           skeletonRows, skeletonCards, fmtDate, fmtDateShort, fmtDuration,
           badge, statusBadge, eventBadge, confirm, _runConfirm, initTabs };
})();

// ════════════════════════════════════════════════════════════════════════════
// AudioManager — Web Audio API ile dosyasız ses üretimi
// ════════════════════════════════════════════════════════════════════════════
const AudioManager = (() => {
  let ctx = null;

  function getCtx() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, duration, type = 'sine', volume = 0.3, delay = 0) {
    try {
      const c = getCtx();
      const osc  = c.createOscillator();
      const gain = c.createGain();
      osc.connect(gain);
      gain.connect(c.destination);
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(volume, c.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + delay + duration / 1000);
      osc.start(c.currentTime + delay);
      osc.stop(c.currentTime + delay + duration / 1000 + 0.05);
    } catch(e) {}
  }

  function playAlert(type) {
    try {
      switch (type) {
        case 'beep':
          tone(880, 180);
          break;
        case 'double_beep':
          tone(880, 150, 'sine', 0.3, 0);
          tone(880, 150, 'sine', 0.3, 0.25);
          break;
        case 'siren':
          for (let i = 0; i < 8; i++) {
            tone(i % 2 === 0 ? 660 : 990, 320, 'sawtooth', 0.25, i * 0.38);
          }
          break;
        case 'voice':
          if ('speechSynthesis' in window) {
            const u = new SpeechSynthesisUtterance('Alarm! Hareket tespit edildi.');
            u.lang = 'tr-TR'; u.rate = 1.1; u.volume = 1;
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(u);
          }
          break;
      }
    } catch(e) {}
  }

  function preview(type) { playAlert(type); }

  return { playAlert, preview, tone };
})();

// ════════════════════════════════════════════════════════════════════════════
// AlarmEngine — olay izleme + ses/görsel uyarı
// Optimizasyon: kurallar ve olaylar ayrı aralıklarla yüklenir.
// Kurallar 5 dakikada bir yenilenir; olay poll'u 20s'de bir çalışır.
// ════════════════════════════════════════════════════════════════════════════
const AlarmEngine = (() => {
  let rules = [];
  let lastEventId = 0;
  let cooldowns  = {};  // ruleId → timestamp
  let eventTimer = null;
  let rulesTimer = null;

  async function loadRules() {
    try { rules = await App.get('/alarms'); } catch(e) { /* sessiz hata */ }
  }

  async function poll() {
    try {
      const recent = await App.get('/events/recent');
      if (!Array.isArray(recent) || !recent.length) return;
      const newEvts = recent.filter(e => e.id > lastEventId);
      if (!newEvts.length) return;
      lastEventId = Math.max(...recent.map(e => e.id));
      newEvts.forEach(trigger);
    } catch(e) {}
  }

  function trigger(evt) {
    const matched = rules.filter(r => {
      if (!r.enabled) return false;
      if (r.cameraId && r.cameraId !== evt.cameraId) return false;
      if (r.eventType && r.eventType !== evt.type) return false;
      const now = Date.now();
      if (cooldowns[r.id] && now - cooldowns[r.id] < r.cooldownSeconds * 1000) return false;
      return true;
    });
    matched.forEach(r => {
      cooldowns[r.id] = Date.now();
      if (r.sound && r.sound !== 'none') AudioManager.playAlert(r.sound);
      flashAlarm();
      showNotification(evt, r);
    });
  }

  function flashAlarm() {
    const el = document.getElementById('alarm-flash');
    if (!el) return;
    el.classList.remove('active');
    void el.offsetWidth;
    el.classList.add('active');
    setTimeout(() => el.classList.remove('active'), 2500);
  }

  function showNotification(evt, rule) {
    const icons = { person:'👤', vehicle:'🚗', motion:'📡', face:'🎭', tamper:'⚠️' };
    App.toast(`🔔 ${rule.name}: ${icons[evt.type] || '❗'} ${evt.type}${evt.cameraName ? ' — '+evt.cameraName : ''}`, 'warning');
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(`OpticSight — ${rule.name}`, {
        body: `${icons[evt.type] || ''} ${evt.type} tespit edildi${evt.cameraName ? ' (' + evt.cameraName + ')' : ''}`,
        icon: '/assets/favicon.svg',
      });
    }
  }

  async function start() {
    // Başlangıçta mevcut en yüksek ID'yi al (eski olayları tekrar tetikleme)
    await loadRules();
    try {
      const r = await App.get('/events/recent');
      if (Array.isArray(r) && r.length) lastEventId = Math.max(...r.map(e => e.id));
    } catch(e) {}

    // Olay poll'u: 20s (yalnızca yeni olayları çeker — hafif sorgu)
    if (eventTimer) clearInterval(eventTimer);
    eventTimer = setInterval(poll, 20000);

    // Kural yenileme: 5 dakikada bir (kural seti nadiren değişir)
    if (rulesTimer) clearInterval(rulesTimer);
    rulesTimer = setInterval(loadRules, 300000);

    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }

  function stop() {
    if (eventTimer) { clearInterval(eventTimer); eventTimer = null; }
    if (rulesTimer) { clearInterval(rulesTimer); rulesTimer = null; }
  }

  // Kural listesi güncellendikten sonra anında yenile (ör. alarm ayarları sayfası)
  function reload() { loadRules(); }

  return { start, stop, reload, trigger };
})();

// ════════════════════════════════════════════════════════════════════════════
// PatrolEngine — kamera-taraflı devriye yönetimi
//
// Optimizasyon: Devriye artık tarayıcıda setTimeout döngüleriyle değil,
// kamera ajanının kendisi (camera-agent.sh) tarafından yürütülür.
// Tarayıcı yalnızca "başlat / durdur" sinyali gönderir; PTZ komutları
// PHP sunucusundan değil, doğrudan kameradan ONVIF aracılığıyla çalışır.
// ════════════════════════════════════════════════════════════════════════════
const PatrolEngine = (() => {
  // Kamera ajanı olan kameralar için sunucu taraflı devriye
  async function start(patrol) {
    if (!patrol || !patrol.id) return;
    if (!(patrol.presetIds || []).length) {
      App.toast('Devriyeye preset eklenmemiş', 'error');
      return;
    }
    try {
      await App.post(`/patrol-routes/${patrol.id}/start`, {});
      App.toast(`▶ ${patrol.name} devriyesi kamerada başlatıldı`, 'success');
    } catch(e) {
      App.toast(`Devriye başlatılamadı: ${e.message}`, 'error');
    }
  }

  async function stop(patrolId, name) {
    try {
      await App.post(`/patrol-routes/${patrolId}/stop`, {});
      if (name) App.toast(`⏹ ${name} devriyesi durduruldu`, 'info');
    } catch(e) {
      App.toast(`Devriye durdurulamadı: ${e.message}`, 'error');
    }
  }

  // Devriyenin aktif olup olmadığını obje üzerinden kontrol et
  function isRunning(patrol) {
    return !!(patrol && patrol.active);
  }

  return { start, stop, isRunning };
})();

// AlarmEngine'i sayfa yüklendiğinde başlat
document.addEventListener('DOMContentLoaded', () => {
  if (window.__TOKEN__) AlarmEngine.start();
});
