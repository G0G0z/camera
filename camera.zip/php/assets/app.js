// OpticSight — shared frontend JS

const App = (() => {
  // ─── API helpers ──────────────────────────────────────────────────────────
  function token() {
    return window.__TOKEN__ || localStorage.getItem('os_token');
  }

  async function api(method, path, body = null) {
    const opts = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token()}`,
      },
    };
    if (body !== null) opts.body = JSON.stringify(body);
    const res = await fetch('/api' + path, opts);
    if (res.status === 401) {
      await fetch('/auth/session', { method: 'DELETE' });
      window.location.href = '/login';
      return;
    }
    if (!res.ok) {
      let msg = `HTTP ${res.status}`;
      try { const d = await res.json(); msg = d.error || d.message || msg; } catch(e) {}
      throw new Error(msg);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  const get    = (p)    => api('GET',    p);
  const post   = (p, b) => api('POST',   p, b);
  const put    = (p, b) => api('PUT',    p, b);
  const del    = (p)    => api('DELETE', p);

  // ─── Toast ────────────────────────────────────────────────────────────────
  function toast(msg, type = 'info') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  // ─── Modal ────────────────────────────────────────────────────────────────
  function openModal(html) {
    document.getElementById('modal-content').innerHTML = html;
    document.getElementById('modal-overlay').classList.add('active');
  }
  function closeModal() {
    document.getElementById('modal-overlay').classList.remove('active');
  }
  document.addEventListener('click', e => {
    if (e.target.id === 'modal-overlay') closeModal();
  });

  // ─── Auth ─────────────────────────────────────────────────────────────────
  async function logout() {
    try { await post('/auth/logout'); } catch(e) {}
    await fetch('/auth/session', { method: 'DELETE' });
    localStorage.removeItem('os_token');
    window.location.href = '/login';
  }

  // ─── Skeleton ─────────────────────────────────────────────────────────────
  function skeletonRows(cols, rows = 5) {
    let html = '';
    for (let i = 0; i < rows; i++) {
      html += '<tr>' + Array(cols).fill('<td><div class="skeleton h-4 w-full"></div></td>').join('') + '</tr>';
    }
    return html;
  }

  function skeletonCards(n = 4) {
    return Array(n).fill('<div class="card skeleton h-32"></div>').join('');
  }

  // ─── Format helpers ───────────────────────────────────────────────────────
  function fmtDate(d) {
    if (!d) return '—';
    try { return new Date(d).toLocaleString('tr-TR'); } catch(e) { return d; }
  }
  function fmtDateShort(d) {
    if (!d) return '—';
    try { return new Date(d).toLocaleDateString('tr-TR'); } catch(e) { return d; }
  }

  function badge(label, color = 'zinc') {
    return `<span class="badge badge-${color}">${label}</span>`;
  }

  function statusBadge(status) {
    if (status === 'online')  return badge('<span class="dot dot-green"></span> Online', 'green');
    if (status === 'offline') return badge('<span class="dot dot-red"></span> Offline', 'red');
    return badge(status || 'unknown', 'zinc');
  }

  // ─── Confirm dialog ───────────────────────────────────────────────────────
  function confirm(msg, onOk) {
    openModal(`
      <div class="modal-header"><h3>Onay</h3></div>
      <div class="modal-body"><p class="text-zinc-300">${msg}</p></div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="App.closeModal()">İptal</button>
        <button class="btn btn-danger" onclick="(${onOk.toString()})(); App.closeModal();">Sil</button>
      </div>`);
  }

  return { token, api, get, post, put, del, toast, openModal, closeModal, logout, skeletonRows, skeletonCards, fmtDate, fmtDateShort, badge, statusBadge, confirm };
})();
