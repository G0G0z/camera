# OpticSight PTZ — Kamera Yönetim Paneli

## Overview

A full-stack PHP camera management platform for OpenIPC-enabled IP cameras. The entire stack is now PHP — no Node.js, React, or TypeScript dependencies.

## Architecture

```
php/
  index.php          ← API router (all /api/* routes)
  front.php          ← HTML frontend router (all page routes)
  router.php         ← PHP built-in server router (replaces .htaccess)
  layout.php         ← Shared sidebar/nav HTML layout (header)
  layout-footer.php  ← Shared layout closing tags + JS
  config.php         ← JWT secret, data paths, MediaMTX config
  pages/             ← One PHP file per page
    login.php        → /login
    register.php     → /register
    dashboard.php    → /
    cameras.php      → /cameras
    camera-detail.php→ /cameras/{id}
    recordings.php   → /recordings
    events.php       → /events
    customers.php    → /customers
    customer-detail.php → /customers/{id}
    users.php        → /users
    firmware.php     → /firmware
    profile.php      → /profile
    wifi.php         → /wifi-setup
    setup.php        → /setup
    provision.php    → /provision
    not-found.php    → 404
  assets/
    app.js           ← Shared vanilla JS (API client, toast, modal, helpers)
    app.css          ← Custom CSS (cards, buttons, table, badges, etc.)
    favicon.svg
  controllers/       ← PHP API controllers
  lib/               ← Auth, Database, Router, Onvif helpers
  data/              ← JSON flat-file storage (cameras, users, events, etc.)
flasher/             ← Java/Maven Windows desktop firmware flasher (not web)
```

## How to run

**Workflow:** `Start application`  
**Command:** `php -S 0.0.0.0:5000 -t /home/runner/workspace/php /home/runner/workspace/php/router.php`

The PHP built-in server serves the app on port 5000. `router.php` routes:
- `/api/*` → `index.php` (JSON API with JWT auth)
- `/auth/session` → `front.php` (sets/destroys PHP session)
- Static files → served directly
- Everything else → `front.php` (PHP-rendered HTML pages)

## Auth flow

1. Login page POSTs credentials to `/api/auth/login` → gets JWT
2. JS calls `/auth/session` (POST) to store JWT in PHP session + localStorage
3. PHP pages check `$_SESSION['token']` — redirect to `/login` if missing
4. JS reads `window.__TOKEN__` (injected by layout.php) for API calls

## Default credentials (seed data)

| Email | Password | Role |
|---|---|---|
| admin@example.com | admin123 | superadmin |
| avm@example.com | (see data/users.json hash) | admin |

## Styling

- Tailwind CSS via CDN (dark mode, zinc palette)
- Custom CSS in `assets/app.css` (cards, buttons, badges, tables, modals, toasts)
- No build step required

## User preferences

- Full PHP stack — no React, TypeScript, or Node.js
- Turkish UI language
