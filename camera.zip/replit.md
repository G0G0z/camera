# OpticSight PTZ — Kamera Yönetim Paneli

FTP Username
if0_42446591 
FTP Password
20192019aAa   
FTP Hostname
ftpupload.net
FTP Port (optional)
21



replit ortamında python3 << 'EOF' import ftplib, io ftp = ftplib... ile dosyaları oku düzenle kontrol et.


## Overview

XiongMai / OpenIPC IP kameralar için tam PHP kamera yönetim platformu.
Kamera ajanlı devriye, alarm yönetimi, ONVIF PTZ kontrolü ve firmware yönetimi içerir.

## Architecture

```
php/                         ← Web panel (PHP 8.2, vanilla JS)
  index.php                  ← API router (all /api/* routes)
  front.php                  ← HTML frontend router (all page routes)
  router.php                 ← PHP built-in server router
  layout.php                 ← Shared sidebar/nav layout
  layout-footer.php          ← Layout kapanış + JS
  config.php                 ← JWT secret, veri dizinleri, MediaMTX
  pages/                     ← Her sayfa için bir PHP dosyası
    login.php                → /login
    register.php             → /register
    dashboard.php            → /
    cameras.php              → /cameras
    camera-detail.php        → /cameras/{id}  (PTZ, preset, devriye)
    patrol.php               → /patrol
    alarms.php               → /alarms
    monitor.php              → /monitor
    recordings.php           → /recordings
    events.php               → /events
    customers.php            → /customers
    customer-detail.php      → /customers/{id}
    users.php                → /users
    firmware.php             → /firmware
    profile.php              → /profile
    wifi.php                 → /wifi-setup
    setup.php                → /setup
    provision.php            → /provision
    not-found.php            → 404
  assets/
    app.js                   ← Shared JS (App, AlarmEngine, PatrolEngine, AudioManager)
    app.css                  ← Custom CSS
    favicon.svg
  controllers/               ← PHP API controllers
    CameraController.php     ← heartbeat, configForAgent, CRUD
    PatrolController.php     ← startPatrol, stopPatrol, CRUD
    AlarmController.php      ← CRUD alarm kuralları
    PtzController.php        ← ONVIF PTZ komutları, preset yönetimi
    ...diğerleri
  lib/                       ← Auth, Database (JSON flat-file), Router, Onvif
  data/                      ← JSON flat-file storage (cameras.json, users.json, ...)

flasher/                     ← Java/Maven Windows masaüstü firmware flasher (web değil)
  src/main/resources/scripts/
    camera-agent.sh          ← Kamera ajanı (OpenIPC'ye kurulur)
    provision.sh             ← İlk kurulum scripti
```

## How to run

**Workflow:** `Start application`
**Komut:** `php -S 0.0.0.0:5000 -t php php/router.php`

`router.php` yönlendirmesi:
- `/api/*` → `index.php` (JWT kimlik doğrulamalı JSON API)
- `/auth/session` → `front.php` (PHP session yönetimi)
- Static dosyalar → doğrudan servis
- Diğer her şey → `front.php` (PHP HTML sayfaları)

## Default credentials

| E-posta | Şifre | Rol |
|---|---|---|
| admin@example.com | admin123 | superadmin |

## Kamera-Panel optimizasyon mimarisi

### Eski mimari (v1):
- Devriye: Tarayıcı → setTimeout döngüsü → PHP → Kamera (ONVIF)
- Tarayıcı sekme kapatılırsa devriye durur
- Alarm kuralları + olaylar her 20s'de bir tek istekle çekilir

### Yeni mimari (v2):
- **Devriye:** Tarayıcı `POST /api/patrol-routes/{id}/start` → DB flag → Kamera ajanı okur → Kamera kendi ONVIF'i ile devriye yapar
- **Config senkronizasyonu:** Kamera ajanı heartbeat yanıtındaki `configVersion` hash'ini izler; değişirse `GET /api/cameras/config` çekerek ayarları günceller
- **Alarm kuralları:** Kameraların kendi ajanında önbelleğe alınır; PHP her tetiklemede sorgulanmaz
- **AlarmEngine:** Kural yenileme 5dk'da bir, olay poll'u 20s'de bir (ayrı zamanlayıcılar)

## Kamera Ajanı (camera-agent.sh)

Kameraya kurulum:
```sh
camera-agent.sh install https://panel.domain.com <CAMERA_TOKEN> "Kamera Adı"
```

Komutlar:
- `start` — Ajanı başlat (heartbeat + webhook dinleyici + devriye)
- `stop` — Durdur
- `sync` — Config'i panelden hemen çek ve uygula
- `status` — Çalışma durumu + config versiyonu
- `logs [N]` — Son N satır log

## API Endpoints (yeni)

| Metod | URL | Açıklama |
|---|---|---|
| GET | /api/cameras/config | Kamera ajanı config çekme (token auth) |
| POST | /api/cameras/heartbeat | Heartbeat + configVersion yanıtı |
| GET | /api/patrol-routes | Devriye listesi |
| POST | /api/patrol-routes | Devriye oluştur |
| POST | /api/patrol-routes/{id}/start | Devriyeyi kamerada başlat |
| POST | /api/patrol-routes/{id}/stop | Devriyeyi durdur |
| GET | /api/alarms | Alarm kuralları listesi |
| POST | /api/alarms | Alarm kuralı oluştur |

## User preferences

- Full PHP stack — React, TypeScript, Node.js yok
- Türkçe UI dili
- Flat-file JSON DB (data/ dizini) — kurulum gerektirmez
