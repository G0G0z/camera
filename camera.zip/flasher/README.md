# OpticSight Camera Flasher

XiongMai XM530 kameralarına OpenIPC firmware yükleyen ve otomatik olarak
`provision.sh` + `camera-agent.sh` kuran Windows masaüstü uygulaması.

---

## Gereksinimler

| Gereksinim | Detay |
|---|---|
| **Java 11+** | [Adoptium JDK 11](https://adoptium.net/) veya üstü |
| **Maven 3.8+** | Derleme için |
| **USB-TTL adaptör** | CP2102 / CH340G / FT232R |
| **Ethernet kablosu** | PC ↔ Kamera (switch üzerinden veya direkt) |
| **Yönetici hakları** | TFTP port 69 için |
| **İnternet bağlantısı** | Firmware GitHub'dan indirilir |

---

## Kurulum ve Çalıştırma

### 1. Derleme

```cmd
cd camera-flasher
mvn package -q
```

Çıktı: `target/camera-flasher-1.0.0.jar` (tek çalıştırılabilir JAR)

### 2. Başlatma

**Normal (port 6969 — 69 açılamazsa):**
```cmd
java -jar target/camera-flasher-1.0.0.jar
```

**Yönetici olarak (port 69, U-Boot uyumlu):**
```cmd
:: Komut İstemi'ni Yönetici olarak aç, sonra:
java -jar target/camera-flasher-1.0.0.jar
```

Veya sağ tıklayıp **"Yönetici olarak çalıştır"** seçin.

---

## Kullanım Adımları

```
1. USB-TTL adaptörü PC'ye tak
2. Kamera TX→PC RX, Kamera RX→PC TX, GND→GND bağla
3. Ethernet kablosunu PC ve kamerayı aynı switche bağla
4. Uygulamayı Yönetici olarak aç
5. COM portunu seç (↺ ile yenile)
6. SoC: xm530, Flash: 8m seç
7. Kamera IP: 192.168.1.200 (veya boş alana istediğin IP)
8. "BAŞLAT"a bas
9. Firmware indiriliyor + TFTP başlıyor...
10. "Kameranın gücünü TAKIN" mesajı çıkınca kamerayı fişe tak
11. U-Boot yakalanır, firmware otomatik yazılır
12. Kamera yeniden açılır, SSH beklenir
13. provision.sh ve camera-agent.sh otomatik kopyalanır
14. ✓ TAMAMLANDI — QR ile panele bağla!
```

---

## Bağlantı Şeması

```
USB-TTL Adaptör          XM530 Kart (UART pinleri)
───────────────          ──────────────────────────
     TX     ─────────→        RX
     RX     ←─────────        TX
    GND     ─────────         GND
    VCC     ✗ BAĞLAMA         (kamera kendi adaptöründen beslenir)
```

> **Dikkat:** TX çapraz bağlanır (senin TX → onun RX).

---

## Ağ Topolojisi

```
[PC] ──ethernet── [Switch/Router] ──ethernet── [Kamera]
  ↑                                               ↑
  TFTP Server                             192.168.1.200
  192.168.1.xxx                           (U-Boot'ta ayarlanır)
```

---

## Proje Yapısı

```
camera-flasher/
├── pom.xml                          Maven build dosyası
├── README.md
└── src/main/
    ├── java/com/opticsight/flasher/
    │   ├── Main.java                Giriş noktası
    │   ├── model/
    │   │   └── FlashConfig.java    Kullanıcı parametreleri
    │   ├── core/
    │   │   ├── LogSink.java         Log arayüzü
    │   │   ├── FirmwareDownloader.java  GitHub'dan indirme
    │   │   ├── TftpServer.java      RFC 1350 TFTP (UDP:69)
    │   │   ├── SerialManager.java   COM port + U-Boot iletişimi
    │   │   ├── UBootFlasher.java    U-Boot komut dizisi
    │   │   ├── SshDeployer.java     SCP + SSH kurulum
    │   │   └── FlashOrchestrator.java  Tüm akışı yönetir
    │   └── gui/
    │       ├── FlasherWindow.java   Ana Swing penceresi
    │       ├── StepIndicator.java   Üst adım göstergesi
    │       └── LogPanel.java        Renkli log çıktısı
    └── resources/
        └── scripts/
            ├── provision.sh         QR → WiFi → Panel kaydı
            └── camera-agent.sh      Heartbeat + event agent
```

---

## Desteklenen SoC'lar

| SoC | Flash | Durum |
|-----|-------|-------|
| xm530 | 8m / 16m | ✅ Test edildi |
| xm550 | 8m / 16m | ✅ |
| xm580 | 16m | ✅ |
| gk7205v200 | 8m / 16m | ✅ |
| gk7205v300 | 8m / 16m | ✅ |
| hi3516ev300 | 16m | ✅ |

---

## Sorun Giderme

### "U-Boot prompt yakalanamadı"
- TX/RX çapraz mı bağlandı kontrol et
- GND mutlaka bağlı olmalı
- Doğru COM port seçili mi? Aygıt Yöneticisi'nden kontrol et
- Kameranın gücünü **"Kameranın gücünü TAKIN"** mesajı çıkınca tak

### "Port 69 açılamadı"
- Uygulamayı Yönetici olarak başlat
- Windows Defender Güvenlik Duvarı UDP:69 portunu engelliyor olabilir
- Güvenlik Duvarı > Gelen Kurallar > UDP 69 izin ver

### "SSH bağlantısı kurulamadı"
- Kamera IP'si doğru mu? (varsayılan: 192.168.1.200)
- Ethernet kablosu takılı mı?
- OpenIPC'nin tam açılması 60-120 saniye sürer

### Firmware indirme başarısız
- İnternet bağlantısı var mı?
- `~/opticsight-firmware/` klasöründe yarım dosya varsa sil, tekrar dene

---

## Lisans

MIT — OpticSight projesi kapsamında geliştirilmiştir.
