@echo off
REM ─────────────────────────────────────────────────────────────────────────────
REM  OpticSight Camera Flasher — YÖNETİCİ OLARAK BAŞLAT
REM  TFTP port 69 için Yönetici hakları gerekir.
REM  Bu dosyaya çift tıklayın veya sağ tık → Yönetici olarak çalıştır
REM ─────────────────────────────────────────────────────────────────────────────

REM Yönetici kontrolü
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Yonetici haklari gerekiyor. Otomatik olarak yukseltiliyor...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

REM JAR dosyası derlenmiş mi?
if not exist "target\camera-flasher-1.0.0.jar" (
    echo JAR bulunamadi. Derleniyor...
    call mvn package -q
    if %ERRORLEVEL% NEQ 0 (
        echo Derleme basarisiz! Java 11+ ve Maven kurulu olmali.
        pause
        exit /b 1
    )
)

echo OpticSight Camera Flasher baslatiliyor ^(Yonetici^)...
java -jar target\camera-flasher-1.0.0.jar

pause
