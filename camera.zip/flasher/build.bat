@echo off
REM ─────────────────────────────────────────────────
REM  OpticSight Camera Flasher — Windows Derleme
REM  Kullanım: build.bat
REM ─────────────────────────────────────────────────

echo.
echo  OpticSight Camera Flasher - Derleniyor...
echo  ==========================================

mvn package -q

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  HATA: Derleme basarisiz!
    echo  Java 11+ ve Maven 3.8+ kurulu olmali.
    pause
    exit /b 1
)

echo.
echo  BASARILI! JAR olusturuldu:
echo  target\camera-flasher-1.0.0.jar
echo.
echo  Calistirmak icin:
echo  java -jar target\camera-flasher-1.0.0.jar
echo.
pause
