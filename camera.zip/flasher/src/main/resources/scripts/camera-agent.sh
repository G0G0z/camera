#!/bin/sh
# =============================================================================
# OpticSight Kamera Ajanı — OpenIPC / Majestic
# v2.0 — Kamera-taraflı devriye + config senkronizasyonu
#
# Değişiklikler (v2.0):
#   - Devriye artık PHP panelin değil, kameranın kendisi yürütür
#   - Heartbeat yanıtındaki configVersion ile config değişimini algılar
#   - /api/cameras/config endpoint'inden patrol + alarm ayarlarını çeker
#   - Python3 kullanarak ONVIF SOAP GotoPreset gönderir
#   - Alarm kuralları kamerada önbelleğe alınır, panel sürekli sorgulanmaz
# =============================================================================
# Kurulum:
#   camera-agent.sh install <PANEL_URL> <CAMERA_TOKEN> [KAMERA_ADI]
# =============================================================================

set -e

AGENT_VERSION="2.0.0"
CONFIG_FILE="/etc/opticsight.conf"
CONFIG_CACHE_FILE="/etc/opticsight-config.json"
CONFIG_VERSION_FILE="/etc/opticsight-config-version"
PATROL_PID_FILE="/var/run/camera-patrol.pid"
PID_FILE="/var/run/camera-agent.pid"
LOG_FILE="/var/log/camera-agent.log"
MAJESTIC_YAML="/etc/majestic.yaml"

# Config senkronizasyon aralığı (saniye) — heartbeat versiyon değişmese bile
CONFIG_SYNC_INTERVAL=300

# ─── Log ─────────────────────────────────────────────────────────────────────
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

# ─── Config oku ──────────────────────────────────────────────────────────────
load_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        log "HATA: Config dosyası bulunamadı: $CONFIG_FILE"
        log "      Kurulum için: $0 install <PANEL_URL> <CAMERA_TOKEN>"
        exit 1
    fi
    . "$CONFIG_FILE"
    : "${PANEL_URL:?CONFIG_FILE içinde PANEL_URL tanımlanmamış}"
    : "${CAMERA_TOKEN:?CONFIG_FILE içinde CAMERA_TOKEN tanımlanmamış}"
    PANEL_URL="${PANEL_URL%/}"
}

# ─── Panel API ────────────────────────────────────────────────────────────────
api_post() {
    curl -s -S --max-time 8 \
        -H "Content-Type: application/json" \
        -H "X-Camera-Token: ${CAMERA_TOKEN}" \
        -d "$2" \
        "${PANEL_URL}$1" 2>&1
}

api_get() {
    curl -s -S --max-time 8 \
        -H "X-Camera-Token: ${CAMERA_TOKEN}" \
        "${PANEL_URL}$1" 2>&1
}

# ─── Olay gönder ─────────────────────────────────────────────────────────────
send_event() {
    TYPE="$1"
    CONFIDENCE="${2:-}"
    SNAPSHOT_URL="${3:-}"

    BODY="{\"type\":\"${TYPE}\""
    [ -n "$CONFIDENCE" ]   && BODY="${BODY},\"confidence\":${CONFIDENCE}"
    [ -n "$SNAPSHOT_URL" ] && BODY="${BODY},\"snapshotUrl\":\"${SNAPSHOT_URL}\""
    BODY="${BODY}}"

    RESULT=$(api_post "/api/events" "$BODY")
    log "Olay gönderildi: type=$TYPE conf=$CONFIDENCE → $RESULT"
}

# ─── Anlık görüntü URL ────────────────────────────────────────────────────────
get_snapshot_url() {
    # eth0 (ethernet) veya wlan0 (WiFi) hangisi IP almışsa onu kullan
    MY_IP=$(ip addr show eth0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    [ -z "$MY_IP" ] && MY_IP=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    echo "http://${MY_IP:-127.0.0.1}/image.jpg"
}

# ─── Heartbeat ────────────────────────────────────────────────────────────────
send_heartbeat() {
    UPTIME=$(cat /proc/uptime 2>/dev/null | cut -d. -f1 || echo "0")
    MEM_FREE=$(grep MemFree /proc/meminfo 2>/dev/null | awk '{print $2}' || echo "0")
    DISK_FREE=$(df / 2>/dev/null | tail -1 | awk '{print $4}' || echo "0")
    # Boş değerlere 0 varsayılanı — boş bırakılırsa JSON geçersiz olur
    UPTIME="${UPTIME:-0}"
    MEM_FREE="${MEM_FREE:-0}"
    DISK_FREE="${DISK_FREE:-0}"
    FW_VER=$(cat /etc/openipc_version 2>/dev/null | head -1 || echo "unknown")
    # eth0 yoksa wlan0'ı dene
    MY_IP=$(ip addr show eth0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    [ -z "$MY_IP" ] && MY_IP=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)

    BODY="{\"status\":\"online\",\"ip\":\"${MY_IP:-}\",\"uptime\":${UPTIME},\"memFreeKb\":${MEM_FREE},\"diskFreeKb\":${DISK_FREE},\"firmware\":\"${FW_VER}\"}"

    RESULT=$(api_post "/api/cameras/heartbeat" "$BODY" 2>/dev/null || echo "{}")

    # Panelden gelen configVersion'ı kontrol et
    REMOTE_VER=$(echo "$RESULT" | grep -o '"configVersion":"[^"]*"' | cut -d'"' -f4)
    LOCAL_VER=$(cat "$CONFIG_VERSION_FILE" 2>/dev/null || echo "")

    if [ -n "$REMOTE_VER" ] && [ "$REMOTE_VER" != "$LOCAL_VER" ]; then
        log "Config değişti (${LOCAL_VER} → ${REMOTE_VER}), yeniden çekiliyor..."
        fetch_config
    fi

    log "Heartbeat → status=online ver=${REMOTE_VER}"
}

# ─── Panel'den config çek ve önbelleğe al ─────────────────────────────────────
fetch_config() {
    RESULT=$(api_get "/api/cameras/config" 2>/dev/null || echo "")

    # Geçerli JSON mi?
    if echo "$RESULT" | grep -q '"configVersion"'; then
        echo "$RESULT" > "$CONFIG_CACHE_FILE"
        # configVersion'ı kaydet
        NEW_VER=$(echo "$RESULT" | grep -o '"configVersion":"[^"]*"' | cut -d'"' -f4)
        echo "$NEW_VER" > "$CONFIG_VERSION_FILE"
        log "Config güncellendi (version: $NEW_VER)"
        apply_config
    else
        log "Config çekme başarısız: $RESULT"
    fi
}

# ─── Çekilen config'i uygula ──────────────────────────────────────────────────
apply_config() {
    if [ ! -f "$CONFIG_CACHE_FILE" ]; then return; fi

    # Devriye aktif mi kontrol et
    PATROL_ACTIVE=$(python3 -c "
import json, sys
with open('$CONFIG_CACHE_FILE') as f:
    d = json.load(f)
p = d.get('patrol')
print('yes' if p and p.get('presets') else 'no')
" 2>/dev/null || echo "no")

    if [ "$PATROL_ACTIVE" = "yes" ]; then
        start_patrol_loop
    else
        stop_patrol_loop
        log "Aktif devriye yok"
    fi
}

# ─── Devriye döngüsünü başlat (kamera tarafında) ──────────────────────────────
start_patrol_loop() {
    # Önce mevcut devriyeyi durdur
    stop_patrol_loop

    log "Kamera taraflı devriye başlatılıyor..."

    # Python3 ile ONVIF GotoPreset döngüsü arka planda çalışır
    python3 << 'PYEOF' &
import json, time, subprocess, sys, os

CONFIG_CACHE_FILE = '/etc/opticsight-config.json'
LOG_FILE = '/var/log/camera-agent.log'

def log(msg):
    try:
        with open(LOG_FILE, 'a') as f:
            from datetime import datetime
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [PATROL] {msg}\n")
    except Exception:
        pass

def onvif_goto_preset(port, user, pw, prof_token, preset_token, speed):
    """ONVIF PTZ GotoPreset — HTTP Basic auth ile (Majestic/OpenIPC uyumlu)"""
    soap = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"'
        ' xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl"'
        ' xmlns:tt="http://www.onvif.org/ver10/schema">'
        '<s:Body><tptz:GotoPreset>'
        f'<tptz:ProfileToken>{prof_token}</tptz:ProfileToken>'
        f'<tptz:PresetToken>{preset_token}</tptz:PresetToken>'
        f'<tptz:Speed><tt:PanTilt x="{speed}" y="{speed}"/>'
        '<tt:Zoom x="0"/></tptz:Speed>'
        '</tptz:GotoPreset></s:Body></s:Envelope>'
    )
    cmd = [
        'curl', '-s', '--max-time', '5',
        '-u', f'{user}:{pw}',
        '-H', 'Content-Type: application/soap+xml; charset=utf-8',
        '-d', soap,
        f'http://127.0.0.1:{port}/onvif/PTZ',
    ]
    try:
        result = subprocess.run(cmd, timeout=10, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        log(f"GotoPreset OK: preset={preset_token}")
        return True
    except Exception as e:
        log(f"GotoPreset HATA: preset={preset_token} err={e}")
        return False

log("Devriye döngüsü başladı")

while True:
    try:
        with open(CONFIG_CACHE_FILE) as f:
            d = json.load(f)

        patrol = d.get('patrol')
        if not patrol:
            log("Devriye config'de aktif değil, duruyorum")
            break

        onvif  = d.get('onvif', {})
        presets = patrol.get('presets', [])
        dwell   = float(patrol.get('dwellSeconds', 10))
        speed   = float(patrol.get('speed', 0.5))
        port    = int(onvif.get('port', 80))
        user    = onvif.get('username', 'admin')
        pw      = onvif.get('password', '')
        prof    = onvif.get('profileToken', 'Profile_1')

        if not presets:
            log("Devriyede preset yok, duruyorum")
            break

        for preset in presets:
            token = preset.get('token', '')
            name  = preset.get('name', token)
            log(f"Preset: {name} ({token})")
            onvif_goto_preset(port, user, pw, prof, token, speed)
            time.sleep(dwell)

        # Her tur sonunda config'i yeniden oku (değişiklik varsa hemen uygula)
    except FileNotFoundError:
        log("Config dosyası bulunamadı, 10s bekleniyor...")
        time.sleep(10)
    except Exception as e:
        log(f"Döngü hatası: {e}")
        time.sleep(5)

log("Devriye döngüsü sona erdi")
PYEOF

    PATROL_PID=$!
    echo $PATROL_PID > "$PATROL_PID_FILE"
    log "Devriye başlatıldı (PID: $PATROL_PID)"
}

# ─── Devriye döngüsünü durdur ─────────────────────────────────────────────────
stop_patrol_loop() {
    if [ -f "$PATROL_PID_FILE" ]; then
        PID=$(cat "$PATROL_PID_FILE" 2>/dev/null)
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            kill "$PID" 2>/dev/null
            log "Devriye durduruldu (PID: $PID)"
        fi
        rm -f "$PATROL_PID_FILE"
    fi
}

# ─── Majestic webhook yapılandır ─────────────────────────────────────────────
configure_majestic_webhook() {
    load_config
    WEBHOOK_URL="${PANEL_URL}/api/cameras/majestic-hook?token=${CAMERA_TOKEN}"

    log "Majestic webhook ayarlanıyor: $WEBHOOK_URL"

    cli -s .motionDetect.enabled true          2>/dev/null || true
    cli -s .motionDetect.threshold 10          2>/dev/null || true
    cli -s .motionDetect.webhookURL "$WEBHOOK_URL" 2>/dev/null || true

    cli -s .objectDetect.enabled true          2>/dev/null || true
    cli -s .objectDetect.webhookURL "$WEBHOOK_URL" 2>/dev/null || true

    killall -1 majestic 2>/dev/null || true
    sleep 2
    log "Majestic yeniden başlatıldı"
}

# ─── Webhook dinleyici ────────────────────────────────────────────────────────
start_webhook_listener() {
    PORT=8484
    log "Webhook dinleyici başlatıldı: 0.0.0.0:$PORT"

    while true; do
        # printf kullan: BusyBox echo -e çalışmayabilir
        # nc -l PORT: BusyBox nc'de -p parametresi olmayabilir
        RAW=$(printf "HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK" | \
              nc -l "$PORT" 2>/dev/null) || true

        BODY=$(echo "$RAW" | awk '/^\r?$/{found=1;next} found{print}' | head -1)
        [ -z "$BODY" ] && continue

        EVENT_TYPE=$(echo "$BODY" | grep -o '"event":"[^"]*"' | cut -d'"' -f4)
        AI_CLASS=$(echo "$BODY"   | grep -o '"class":"[^"]*"'  | cut -d'"' -f4)
        CONFIDENCE=$(echo "$BODY" | grep -o '"confidence":[0-9.]*' | cut -d: -f2)

        SNAP=$(get_snapshot_url)

        case "$EVENT_TYPE" in
            md|motion)
                send_event "motion" "" "$SNAP"
                ;;
            ai)
                case "$AI_CLASS" in
                    person|human)   send_event "person"  "$CONFIDENCE" "$SNAP" ;;
                    vehicle|car)    send_event "vehicle" "$CONFIDENCE" "$SNAP" ;;
                    face)           send_event "face"    "$CONFIDENCE" "$SNAP" ;;
                    *)              send_event "motion"  "$CONFIDENCE" "$SNAP" ;;
                esac
                ;;
            tamper)
                send_event "tamper" "" "$SNAP"
                ;;
        esac
    done
}

# ─── Heartbeat döngüsü ────────────────────────────────────────────────────────
start_heartbeat_loop() {
    INTERVAL="${HEARTBEAT_INTERVAL:-60}"
    SYNC_COUNTER=0
    log "Heartbeat döngüsü başlatıldı (her ${INTERVAL}s)"

    while true; do
        send_heartbeat

        # CONFIG_SYNC_INTERVAL'da bir zorla config yenile (heartbeat yanıtından bağımsız)
        SYNC_COUNTER=$((SYNC_COUNTER + INTERVAL))
        if [ "$SYNC_COUNTER" -ge "$CONFIG_SYNC_INTERVAL" ]; then
            SYNC_COUNTER=0
            log "Periyodik config senkronizasyonu..."
            fetch_config
        fi

        sleep "$INTERVAL"
    done
}

# ─── Kurulum ─────────────────────────────────────────────────────────────────
cmd_install() {
    PANEL_URL_ARG="$1"
    TOKEN_ARG="$2"
    CAMERA_NAME_ARG="${3:-OpenIPC Kamera}"

    if [ -z "$PANEL_URL_ARG" ] || [ -z "$TOKEN_ARG" ]; then
        echo "Kullanım: $0 install <PANEL_URL> <CAMERA_TOKEN> [KAMERA_ADI]"
        echo "Örnek  : $0 install https://panel.sirketim.com abc123token 'Ana Giriş'"
        exit 1
    fi

    cat > "$CONFIG_FILE" <<EOF
# OpticSight Kamera Ajanı Yapılandırması
# Otomatik oluşturuldu: $(date)
PANEL_URL="${PANEL_URL_ARG}"
CAMERA_TOKEN="${TOKEN_ARG}"
CAMERA_NAME="${CAMERA_NAME_ARG}"
HEARTBEAT_INTERVAL=60
EOF
    chmod 600 "$CONFIG_FILE"
    log "Config yazıldı: $CONFIG_FILE"

    cp "$0" /usr/local/bin/camera-agent.sh
    chmod +x /usr/local/bin/camera-agent.sh

    configure_majestic_webhook

    cat > /etc/init.d/S99camera-agent <<'INITEOF'
#!/bin/sh
case "$1" in
    start)
        echo "OpticSight ajanı başlatılıyor..."
        /usr/local/bin/camera-agent.sh start &
        ;;
    stop)
        echo "OpticSight ajanı durduruluyor..."
        kill $(cat /var/run/camera-agent.pid 2>/dev/null) 2>/dev/null || true
        /usr/local/bin/camera-agent.sh stop-patrol 2>/dev/null || true
        ;;
    restart)
        $0 stop; sleep 1; $0 start
        ;;
    *)
        echo "Kullanım: $0 {start|stop|restart}"
        exit 1
esac
INITEOF
    chmod +x /etc/init.d/S99camera-agent

    log "Kurulum tamamlandı. Ajan başlatılıyor..."
    /etc/init.d/S99camera-agent start
}

# ─── Başlat ───────────────────────────────────────────────────────────────────
cmd_start() {
    load_config

    echo $$ > "$PID_FILE"
    log "OpticSight Kamera Ajanı v${AGENT_VERSION} başlatıldı (PID: $$)"

    # İlk config senkronizasyonu
    log "Başlangıç config senkronizasyonu yapılıyor..."
    fetch_config

    # Webhook dinleyici arka planda
    start_webhook_listener &
    LISTENER_PID=$!

    # Heartbeat döngüsü arka planda (config değişimini izler)
    start_heartbeat_loop &
    HEARTBEAT_PID=$!

    wait $LISTENER_PID $HEARTBEAT_PID
    rm -f "$PID_FILE"
}

# ─── Durdur ───────────────────────────────────────────────────────────────────
cmd_stop() {
    stop_patrol_loop
    if [ -f "$PID_FILE" ]; then
        kill "$(cat $PID_FILE)" 2>/dev/null && log "Ajan durduruldu"
        rm -f "$PID_FILE"
    else
        log "PID dosyası bulunamadı"
    fi
}

# ─── Durum ────────────────────────────────────────────────────────────────────
cmd_status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat $PID_FILE)" 2>/dev/null; then
        echo "Ajan ÇALIŞIYOR (PID: $(cat $PID_FILE))"
    else
        echo "Ajan ÇALIŞMIYOR"
    fi

    if [ -f "$PATROL_PID_FILE" ] && kill -0 "$(cat $PATROL_PID_FILE)" 2>/dev/null; then
        echo "Devriye ÇALIŞIYOR (PID: $(cat $PATROL_PID_FILE))"
    else
        echo "Devriye ÇALIŞMIYOR"
    fi

    [ -f "$CONFIG_VERSION_FILE" ] && echo "Config version: $(cat $CONFIG_VERSION_FILE)"
    [ -f "$CONFIG_FILE" ] && grep "PANEL_URL\|CAMERA_NAME" "$CONFIG_FILE"
}

# ─── Log göster ───────────────────────────────────────────────────────────────
cmd_logs() {
    tail -n "${1:-50}" "$LOG_FILE" 2>/dev/null || echo "Log dosyası yok"
}

# ─── Manuel config senkronizasyonu ───────────────────────────────────────────
cmd_sync() {
    load_config
    log "Manuel config senkronizasyonu..."
    fetch_config
    log "Senkronizasyon tamamlandı"
}

# ─── Test ────────────────────────────────────────────────────────────────────
cmd_test() {
    load_config
    log "Test olayı gönderiliyor (person, %90 güven)..."
    send_event "person" "0.90" "$(get_snapshot_url)"
    log "Test tamamlandı"
}

# ─── Ana komut yönlendirici ───────────────────────────────────────────────────
case "${1:-start}" in
    install)          cmd_install "$2" "$3" "$4" ;;
    start)            cmd_start ;;
    stop)             cmd_stop ;;
    restart)          cmd_stop; sleep 1; cmd_start ;;
    status)           cmd_status ;;
    logs)             cmd_logs "$2" ;;
    test)             cmd_test ;;
    sync)             cmd_sync ;;
    stop-patrol)      load_config; stop_patrol_loop ;;
    configure-webhook) load_config; configure_majestic_webhook ;;
    *)
        echo "Kullanım: $0 {install|start|stop|restart|status|logs|test|sync|configure-webhook}"
        echo ""
        echo "  install <URL> <TOKEN> [AD]  — Panele bağla ve başlat"
        echo "  start                       — Ajanı başlat"
        echo "  stop                        — Ajanı durdur"
        echo "  restart                     — Yeniden başlat"
        echo "  status                      — Çalışma durumunu göster"
        echo "  logs [N]                    — Son N satır log (varsayılan: 50)"
        echo "  test                        — Panele test olayı gönder"
        echo "  sync                        — Config'i panelden hemen yenile"
        echo "  configure-webhook           — Majestic webhook'unu yeniden ayarla"
        exit 1
esac
