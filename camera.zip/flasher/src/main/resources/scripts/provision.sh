#!/bin/sh
# =============================================================================
# OpticSight — Kamera İlk Kurulum (Provizyon) Scripti
# OpenIPC / XiongMai XM530 için
#
# Nasıl çalışır:
#   1. Kamera açılır, bu script çalışır
#   2. Kamera daha önce kurulmadıysa QR okuma moduna geçer
#   3. Majestic kamera görüntüsünden QR decode edilir
#   4. QR içindeki WiFi bilgileriyle ağa bağlanılır
#   5. Panel'e kayıt yapılır (POST /api/provision/register)
#   6. Alınan kamera token'ı kaydedilir
#   7. Camera agent başlatılır
#
# Kurulum (kameraya kopyalama panelden otomatik yapılır):
#   chmod +x /usr/local/bin/provision.sh
#   echo "/usr/local/bin/provision.sh" >> /etc/rc.local
# =============================================================================

set -e

CONF_FILE="/etc/opticsight.conf"
PROVISIONED_FLAG="/etc/opticsight.provisioned"
LOG_FILE="/var/log/opticsight-provision.log"
AGENT_SCRIPT="/usr/local/bin/camera-agent.sh"
WPA_CONF="/etc/wpa_supplicant.conf"
WIFI_IFACE="wlan0"

MAX_QR_ATTEMPTS=120   # 2 dakika (her 1 sn)
MAX_WIFI_WAIT=30      # saniye
SNAP_URL="http://127.0.0.1/image.jpg"
SNAP_FILE="/tmp/provision_snap.jpg"

# ─── Log ─────────────────────────────────────────────────────────────────────
log() { echo "[$(date '+%H:%M:%S')] $*" | tee -a "$LOG_FILE"; }

# ─── Zaten kuruluysa çık ─────────────────────────────────────────────────────
if [ -f "$PROVISIONED_FLAG" ] && [ -f "$CONF_FILE" ]; then
    log "Kamera zaten kurulmuş. Ajan başlatılıyor..."
    . "$CONF_FILE"
    if [ -x "$AGENT_SCRIPT" ]; then
        "$AGENT_SCRIPT" start &
    fi
    exit 0
fi

log "═══════════════════════════════════════════"
log " OpticSight Provizyon Modu — v1.0"
log "═══════════════════════════════════════════"
log "QR kodu bekleniyor... (kamerayı QR'a doğrultun)"

# ─── Majestic'in başlamasını bekle ────────────────────────────────────────────
wait_for_majestic() {
    local tries=0
    while [ $tries -lt 20 ]; do
        if curl -s --max-time 1 "$SNAP_URL" -o /dev/null 2>/dev/null; then
            return 0
        fi
        sleep 1
        tries=$((tries + 1))
    done
    return 1
}

# ─── Snapshot çek + QR decode ────────────────────────────────────────────────
try_decode_qr() {
    # Snapshot al
    curl -s --max-time 2 "$SNAP_URL" -o "$SNAP_FILE" 2>/dev/null || return 1

    # zbarimg varsa kullan (en güvenilir)
    if command -v zbarimg > /dev/null 2>&1; then
        RESULT=$(zbarimg --raw -q "$SNAP_FILE" 2>/dev/null | head -1)
        [ -n "$RESULT" ] && echo "$RESULT" && return 0
    fi

    # zbarcam ile doğrudan V4L2'den oku (alternatif)
    if command -v zbarcam > /dev/null 2>&1; then
        RESULT=$(zbarcam --raw -q --prescale=320x240 /dev/video0 2>/dev/null | head -1)
        [ -n "$RESULT" ] && echo "$RESULT" && return 0
    fi

    # Python zbar (bazı OpenIPC buildlerinde mevcut)
    if command -v python3 > /dev/null 2>&1; then
        RESULT=$(python3 -c "
import sys
try:
    from pyzbar.pyzbar import decode
    from PIL import Image
    codes = decode(Image.open('$SNAP_FILE'))
    if codes: print(codes[0].data.decode())
except: pass
" 2>/dev/null)
        [ -n "$RESULT" ] && echo "$RESULT" && return 0
    fi

    return 1
}

# ─── JSON alanı çıkar (jq gerektirmez) ───────────────────────────────────────
json_get() {
    # $1=json string, $2=key
    echo "$1" | grep -o "\"$2\":[[:space:]]*\"[^\"]*\"" | sed 's/.*":\s*"\(.*\)"/\1/'
}

# ─── WiFi bağlantısı kur ─────────────────────────────────────────────────────
configure_wifi() {
    local ssid="$1"
    local pass="$2"
    local sec="$3"

    log "WiFi yapılandırılıyor: SSID=$ssid güvenlik=$sec"

    # wpa_supplicant config
    if [ "$sec" = "NOPASS" ]; then
        cat > "$WPA_CONF" <<EOF
ctrl_interface=/var/run/wpa_supplicant
update_config=1

network={
    ssid="$ssid"
    key_mgmt=NONE
}
EOF
    else
        cat > "$WPA_CONF" <<EOF
ctrl_interface=/var/run/wpa_supplicant
update_config=1

network={
    ssid="$ssid"
    psk="$pass"
    key_mgmt=WPA-PSK
    proto=RSN WPA
    pairwise=CCMP TKIP
    group=CCMP TKIP
}
EOF
    fi

    # Arayüzü yeniden başlat
    ifconfig "$WIFI_IFACE" down 2>/dev/null || true
    sleep 1
    wpa_supplicant -B -i "$WIFI_IFACE" -c "$WPA_CONF" 2>/dev/null || true
    sleep 2
    udhcpc -i "$WIFI_IFACE" -t 10 -n 2>/dev/null || dhclient "$WIFI_IFACE" 2>/dev/null || true

    # IP alındı mı kontrol et
    local tries=0
    while [ $tries -lt $MAX_WIFI_WAIT ]; do
        MY_IP=$(ip addr show "$WIFI_IFACE" 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
        if [ -n "$MY_IP" ]; then
            log "WiFi bağlandı! IP: $MY_IP"
            return 0
        fi
        sleep 1
        tries=$((tries + 1))
    done

    log "HATA: WiFi bağlantısı kurulamadı ($MAX_WIFI_WAIT sn beklendi)"
    return 1
}

# ─── Panel'e kayıt ────────────────────────────────────────────────────────────
# NOT: Bu fonksiyon $() içinde çağrıldığı için log() çıktısı token'a karışır.
# Tüm log satırları >&2 (stderr) ile yönlendirilir — sadece token stdout'a yazılır.
register_to_panel() {
    local panel_url="$1"
    local token="$2"

    MY_IP=$(ip addr show "$WIFI_IFACE" 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1 || \
            ip addr show eth0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    MY_MAC=$(cat /sys/class/net/"$WIFI_IFACE"/address 2>/dev/null || \
             cat /sys/class/net/eth0/address 2>/dev/null || echo "")
    FW_VER=$(cat /etc/openipc_version 2>/dev/null | head -1 || echo "unknown")

    echo "[$(date '+%H:%M:%S')] Panele kayıt yapılıyor: $panel_url" | tee -a "$LOG_FILE" >&2

    BODY="{\"token\":\"$token\",\"ip\":\"$MY_IP\",\"mac\":\"$MY_MAC\",\"firmware\":\"$FW_VER\"}"

    RESPONSE=$(curl -s --max-time 15 \
        -H "Content-Type: application/json" \
        -d "$BODY" \
        "${panel_url}/api/provision/register" 2>&1)

    echo "[$(date '+%H:%M:%S')] Panel yanıtı: $RESPONSE" | tee -a "$LOG_FILE" >&2

    # cameraToken alanını çıkar — sadece bu satır stdout'a gider
    CAM_TOKEN=$(echo "$RESPONSE" | grep -o '"cameraToken":"[^"]*"' | cut -d'"' -f4)

    if [ -z "$CAM_TOKEN" ]; then
        echo "[$(date '+%H:%M:%S')] HATA: Panel'den kamera token'ı alınamadı" | tee -a "$LOG_FILE" >&2
        return 1
    fi

    echo "$CAM_TOKEN"
    return 0
}

# ─── Ana provizyon döngüsü ────────────────────────────────────────────────────

# Majestic başlayana kadar bekle
log "Majestic streamer bekleniyor..."
if ! wait_for_majestic; then
    log "UYARI: Majestic başlatılamadı, QR okuma devam ediyor..."
fi

QR_JSON=""
attempt=0

while [ $attempt -lt $MAX_QR_ATTEMPTS ]; do
    attempt=$((attempt + 1))

    if [ $((attempt % 10)) -eq 0 ]; then
        log "QR deneme $attempt/$MAX_QR_ATTEMPTS..."
    fi

    QR_JSON=$(try_decode_qr 2>/dev/null)

    if [ -n "$QR_JSON" ]; then
        # OpticSight QR'ı mı kontrol et ("p" ve "t" alanları olmalı)
        PANEL_URL=$(json_get "$QR_JSON" "p")
        TOKEN=$(json_get "$QR_JSON" "t")

        if [ -n "$PANEL_URL" ] && [ -n "$TOKEN" ]; then
            log "QR okundu! Panel: $PANEL_URL"
            break
        fi
        QR_JSON=""  # Farklı QR, tekrar dene
    fi

    sleep 1
done

if [ -z "$QR_JSON" ]; then
    log "HATA: $MAX_QR_ATTEMPTS deneme sonucunda QR okunamadı"
    exit 1
fi

# QR alanlarını ayrıştır
PANEL_URL=$(json_get "$QR_JSON" "p")
TOKEN=$(json_get "$QR_JSON" "t")
SSID=$(json_get "$QR_JSON" "s")
WIFI_PASS=$(json_get "$QR_JSON" "k")
SECURITY=$(json_get "$QR_JSON" "e")
CAM_NAME=$(json_get "$QR_JSON" "n")

log "Kamera adı: $CAM_NAME"
log "WiFi SSID : $SSID"
log "Güvenlik  : $SECURITY"

# WiFi kur
if ! configure_wifi "$SSID" "$WIFI_PASS" "${SECURITY:-WPA}"; then
    log "WiFi bağlantısı başarısız. Çıkılıyor."
    exit 1
fi

# Panel'e kayıt ol
CAM_TOKEN=$(register_to_panel "$PANEL_URL" "$TOKEN")
if [ $? -ne 0 ] || [ -z "$CAM_TOKEN" ]; then
    log "Panel kaydı başarısız. Çıkılıyor."
    exit 1
fi

# Config dosyası yaz
cat > "$CONF_FILE" <<EOF
# OpticSight Kamera Yapılandırması
# Otomatik oluşturuldu: $(date)
PANEL_URL="${PANEL_URL}"
CAMERA_TOKEN="${CAM_TOKEN}"
CAMERA_NAME="${CAM_NAME}"
WIFI_SSID="${SSID}"
HEARTBEAT_INTERVAL=60
EOF
chmod 600 "$CONF_FILE"

# Kurulmuş işaretle
touch "$PROVISIONED_FLAG"

log "✓ Provizyon tamamlandı!"
log "  Panel   : $PANEL_URL"
log "  Token   : ${CAM_TOKEN:0:8}..."

# Agent scripti indir veya mevcut olanı başlat
if [ ! -x "$AGENT_SCRIPT" ]; then
    log "Agent indiriliyor..."
    curl -s --max-time 30 \
        "${PANEL_URL}/flashing/camera-agent.sh" \
        -o "$AGENT_SCRIPT" 2>/dev/null || true
    chmod +x "$AGENT_SCRIPT" 2>/dev/null || true
fi

# Startup scripti kur + başlat
if [ -x "$AGENT_SCRIPT" ]; then
    "$AGENT_SCRIPT" configure-webhook 2>/dev/null || true

    cat > /etc/init.d/S99opticsight <<'EOF'
#!/bin/sh
case "$1" in
    start) /usr/local/bin/camera-agent.sh start & ;;
    stop)  kill $(cat /var/run/camera-agent.pid 2>/dev/null) 2>/dev/null || true ;;
    restart) $0 stop; sleep 1; $0 start ;;
esac
EOF
    chmod +x /etc/init.d/S99opticsight
    /etc/init.d/S99opticsight start
    log "Agent başlatıldı."
else
    log "UYARI: Agent scripti bulunamadı, heartbeat çalışmayacak."
fi

log "Sistem hazır."
exit 0
