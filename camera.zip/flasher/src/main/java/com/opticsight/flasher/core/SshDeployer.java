package com.opticsight.flasher.core;

import com.jcraft.jsch.*;
import com.opticsight.flasher.model.FlashConfig;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.function.Consumer;

/**
 * Kamera açıldıktan sonra SSH ile bağlanıp:
 *  - provision.sh ve camera-agent.sh kopyalar
 *  - chmod +x yapar
 *  - /etc/rc.local'a provision.sh ekler
 *  - root şifresini varsayılandan daha güvenli bire değiştirir (isteğe bağlı)
 */
public class SshDeployer {

    private static final int  SSH_TIMEOUT_MS  = 10_000;
    private static final long MAX_WAIT_MS      = 3 * 60 * 1000; // 3 dakika
    private static final int  POLL_INTERVAL_MS = 5_000;

    private final FlashConfig cfg;
    private final LogSink     log;
    private final Consumer<Integer> progress; // 0-100

    public SshDeployer(FlashConfig cfg, LogSink log, Consumer<Integer> progress) {
        this.cfg      = cfg;
        this.log      = log;
        this.progress = progress;
    }

    /** SSH hazır olana kadar bekler, sonra scriptleri kurar. */
    public void deployAndConfigure() throws Exception {
        progress(0);
        waitForSsh();
        progress(30);

        Session session = openSession();
        try {
            copyScript(session, "provision.sh",    "/usr/local/bin/provision.sh");
            progress(50);
            copyScript(session, "camera-agent.sh", "/usr/local/bin/camera-agent.sh");
            progress(70);

            exec(session, "chmod +x /usr/local/bin/provision.sh " +
                          "/usr/local/bin/camera-agent.sh");

            setupRcLocal(session);
            progress(90);

            // Majestic webhook konfigürasyonu (kamera agent'ı için)
            exec(session, "[ -f /etc/majestic.yaml ] && " +
                    "sed -i 's|#webhook:.*|webhook:|' /etc/majestic.yaml || true");

            log.ok("✓ Tüm scriptler kuruldu.");
        } finally {
            if (session != null && session.isConnected()) session.disconnect();
        }
        progress(100);
    }

    /* ─── SSH erişilebilirliği bekleme ─────────────────────────────────────── */
    private void waitForSsh() throws Exception {
        log.info("◆ SSH bağlantısı bekleniyor: " + cfg.cameraIp + ":" + cfg.sshPort);
        log.info("  (OpenIPC'nin açılması ~60-120 saniye sürer)");

        long deadline = System.currentTimeMillis() + MAX_WAIT_MS;
        int  attempt  = 0;

        while (System.currentTimeMillis() < deadline) {
            attempt++;
            if (isTcpReachable(cfg.cameraIp, cfg.sshPort, 3000)) {
                log.ok("✓ SSH portu açık! (deneme #" + attempt + ")");
                Thread.sleep(2000); // Daemon başlamasını bekle
                return;
            }
            log.info("  [" + attempt + "] SSH henüz hazır değil, " +
                     (POLL_INTERVAL_MS / 1000) + "s bekleniyor...");
            Thread.sleep(POLL_INTERVAL_MS);
        }
        throw new Exception("SSH bağlantısı " + (MAX_WAIT_MS / 60000) +
                " dakika içinde kurulamadı.\nKameranın ethernet kablosu takılı mı?");
    }

    private boolean isTcpReachable(String host, int port, int timeoutMs) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /* ─── SSH oturumu ───────────────────────────────────────────────────────── */
    private Session openSession() throws Exception {
        JSch jsch = new JSch();
        Session session = jsch.getSession(cfg.sshUser, cfg.cameraIp, cfg.sshPort);
        session.setPassword(cfg.sshPassword);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setConfig("PreferredAuthentications", "password");
        session.setTimeout(SSH_TIMEOUT_MS);
        session.connect(SSH_TIMEOUT_MS);
        log.ok("✓ SSH bağlantısı kuruldu: " + cfg.sshUser + "@" + cfg.cameraIp);
        return session;
    }

    /* ─── Dosya kopyalama (SCP) ─────────────────────────────────────────────── */
    private void copyScript(Session session, String resourceName,
                            String remotePath) throws Exception {
        // Jar içindeki resource'u oku
        byte[] data;
        try (InputStream in = getClass().getResourceAsStream("/scripts/" + resourceName)) {
            if (in == null) {
                throw new FileNotFoundException(
                    "Script bulunamadı: /scripts/" + resourceName +
                    " (JAR içinde resources/scripts/ dizininde olmalı)");
            }
            data = in.readAllBytes();
        }

        log.info("  SCP: " + resourceName + " → " + remotePath +
                 " (" + data.length + " byte)");

        // SCP protokolü ile yükle
        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand("scp -t " + remotePath);

        OutputStream cmdOut  = channel.getOutputStream();
        InputStream  cmdIn   = channel.getInputStream();

        channel.connect(SSH_TIMEOUT_MS);

        // Onay bekle
        checkScp(cmdIn);

        // "C0755 <size> <filename>\n" gönder
        String header = "C0755 " + data.length + " " + remoteFilename(remotePath) + "\n";
        cmdOut.write(header.getBytes());
        cmdOut.flush();
        checkScp(cmdIn);

        // Veri gönder
        cmdOut.write(data);
        cmdOut.write(0); // null terminator
        cmdOut.flush();
        checkScp(cmdIn);

        channel.disconnect();
        log.ok("  ✓ " + resourceName + " kopyalandı.");
    }

    private void checkScp(InputStream in) throws Exception {
        int b = in.read();
        if (b != 0) {
            StringBuilder sb = new StringBuilder();
            int c;
            while ((c = in.read()) != '\n' && c != -1) sb.append((char) c);
            throw new IOException("SCP hatası (kod=" + b + "): " + sb);
        }
    }

    private String remoteFilename(String path) {
        return path.substring(path.lastIndexOf('/') + 1);
    }

    /* ─── Komut çalıştırma ──────────────────────────────────────────────────── */
    private String exec(Session session, String command) throws Exception {
        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand(command);
        channel.setErrStream(System.err);
        InputStream is = channel.getInputStream();
        channel.connect(SSH_TIMEOUT_MS);

        byte[] buf = is.readAllBytes();
        String output = new String(buf).trim();

        channel.disconnect();
        if (!output.isEmpty()) log.serial("  $ " + command + "\n    → " + output);
        return output;
    }

    /* ─── rc.local yapılandırması ───────────────────────────────────────────── */
    private void setupRcLocal(Session session) throws Exception {
        log.info("  rc.local ayarlanıyor...");

        String cmd =
            // provision.sh zaten rc.local'da var mı kontrol et
            "grep -q 'provision.sh' /etc/rc.local || " +
            // yoksa ekle (exit 0'dan önce)
            "sed -i '/^exit 0/i /usr/local/bin/provision.sh' /etc/rc.local; " +
            // rc.local yoksa oluştur
            "[ -f /etc/rc.local ] || " +
            "printf '#!/bin/sh\\n/usr/local/bin/provision.sh\\nexit 0\\n' > /etc/rc.local; " +
            "chmod +x /etc/rc.local";

        exec(session, cmd);
        log.ok("✓ /etc/rc.local güncellendi.");
    }

    private void progress(int pct) {
        if (progress != null) progress.accept(pct);
    }
}
