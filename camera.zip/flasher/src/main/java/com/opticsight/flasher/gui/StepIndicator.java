package com.opticsight.flasher.gui;

import com.opticsight.flasher.core.FlashOrchestrator.Stage;

import javax.swing.*;
import java.awt.*;

/**
 * Üst kısımdaki adım göstergesi.
 * Her aşama için ikon + etiket gösterir.
 */
public class StepIndicator extends JPanel {

    private static final Color C_DONE    = new Color(60, 180, 90);
    private static final Color C_ACTIVE  = new Color(80, 150, 255);
    private static final Color C_PENDING = new Color(80, 80, 100);
    private static final Color C_ERROR   = new Color(220, 60, 60);
    private static final Color C_BG      = new Color(30, 30, 38);

    private final String[] labels = {
        "IP Algıla", "Firmware\nİndir", "TFTP\nSunucu",
        "U-Boot\nBekle", "Flash\nYazma", "SSH\nBekle",
        "Script\nKur", "Tamamlandı"
    };

    private final Stage[] stages = {
        Stage.DETECTING_IP, Stage.DOWNLOADING,  Stage.STARTING_TFTP,
        Stage.WAITING_UBOOT, Stage.FLASHING,    Stage.WAITING_SSH,
        Stage.DEPLOYING,     Stage.DONE
    };

    private Stage current = null;
    private boolean failed = false;

    public StepIndicator() {
        setBackground(C_BG);
        setPreferredSize(new Dimension(0, 80));
    }

    public void setStage(Stage stage) {
        this.current = stage;
        this.failed  = (stage == Stage.FAILED);
        repaint();
    }

    public void reset() {
        current = null;
        failed  = false;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                            RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);

        int n      = stages.length;
        int w      = getWidth();
        int h      = getHeight();
        int cellW  = w / n;
        int circleR= 14;

        for (int i = 0; i < n; i++) {
            int cx = cellW * i + cellW / 2;
            int cy = h / 2 - 8;

            // Bağlantı çizgisi
            if (i > 0) {
                g2.setColor(isDone(i - 1) ? C_DONE : C_PENDING);
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(cx - cellW / 2, cy, cx, cy);
            }

            // Daire
            Color c = circleColor(i);
            g2.setColor(c);
            g2.fillOval(cx - circleR, cy - circleR, circleR * 2, circleR * 2);

            // Numara veya tik
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics();
            String num = isDone(i) ? "✓" : failed && isActive(i) ? "✗" : String.valueOf(i + 1);
            int nx = cx - fm.stringWidth(num) / 2;
            g2.drawString(num, nx, cy + fm.getAscent() / 2);

            // Etiket
            g2.setColor(isActive(i) ? Color.WHITE : C_PENDING);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            String[] parts = labels[i].split("\n");
            int ly = cy + circleR + 14;
            for (String part : parts) {
                int lx = cx - g2.getFontMetrics().stringWidth(part) / 2;
                g2.drawString(part, lx, ly);
                ly += 13;
            }
        }
    }

    private boolean isDone(int i) {
        if (current == null) return false;
        for (int j = 0; j < stages.length; j++) {
            if (stages[j] == current) return j > i;
        }
        return false;
    }

    private boolean isActive(int i) {
        if (current == null) return false;
        if (failed) {
            for (int j = 0; j < stages.length; j++) {
                if (stages[j] == current) return j == i;
            }
        }
        return stages[i] == current;
    }

    private Color circleColor(int i) {
        if (isDone(i)) return C_DONE;
        if (failed && isActive(i)) return C_ERROR;
        if (isActive(i)) return C_ACTIVE;
        return C_PENDING;
    }
}
