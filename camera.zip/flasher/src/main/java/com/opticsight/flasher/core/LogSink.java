package com.opticsight.flasher.core;

/**
 * Log mesajlarını GUI'ye ileten arayüz.
 * INFO / OK / WARN / ERROR seviyeleri var.
 */
public interface LogSink {
    void info(String msg);
    void ok(String msg);
    void warn(String msg);
    void error(String msg);

    /** Ham seri çıktı (gri renk) */
    default void serial(String line) { info(line); }
}
