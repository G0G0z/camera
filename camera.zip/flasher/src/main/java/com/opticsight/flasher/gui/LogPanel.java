package com.opticsight.flasher.gui;

import com.opticsight.flasher.core.LogSink;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Renkli log çıktısı paneli.
 * SwingUtilities.invokeLater ile thread-safe yazma yapar.
 */
public class LogPanel extends JPanel implements LogSink {

    private static final Color C_BG     = new Color(18, 18, 18);
    private static final Color C_INFO   = new Color(200, 200, 200);
    private static final Color C_OK     = new Color(80, 200, 100);
    private static final Color C_WARN   = new Color(255, 190, 50);
    private static final Color C_ERROR  = new Color(255, 80, 80);
    private static final Color C_SERIAL = new Color(130, 160, 200);
    private static final Color C_TIME   = new Color(100, 100, 120);
    private static final Font  FONT     = new Font("Consolas", Font.PLAIN, 13);

    private final JTextPane  pane;
    private final StyledDocument doc;
    private final DateTimeFormatter timeFmt =
            DateTimeFormatter.ofPattern("HH:mm:ss");

    public LogPanel() {
        setLayout(new BorderLayout());
        setBackground(C_BG);

        pane = new JTextPane();
        pane.setEditable(false);
        pane.setBackground(C_BG);
        pane.setFont(FONT);
        doc = pane.getStyledDocument();

        JScrollPane scroll = new JScrollPane(pane);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        // Temizle butonu
        JButton clear = new JButton("Temizle");
        clear.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        clear.addActionListener(e -> pane.setText(""));
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 2));
        bar.setBackground(new Color(30, 30, 30));
        bar.add(clear);
        add(bar, BorderLayout.SOUTH);
    }

    /* ─── LogSink impl ──────────────────────────────────────────────────────── */
    @Override public void info(String msg)   { append(msg, C_INFO,   ""); }
    @Override public void ok(String msg)     { append(msg, C_OK,     "✓ "); }
    @Override public void warn(String msg)   { append(msg, C_WARN,   "⚠ "); }
    @Override public void error(String msg)  { append(msg, C_ERROR,  "✗ "); }
    @Override public void serial(String msg) { append(msg, C_SERIAL, "  "); }

    /* ─── Append ────────────────────────────────────────────────────────────── */
    private void append(String msg, Color color, String prefix) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Zaman damgası
                SimpleAttributeSet timeAttr = new SimpleAttributeSet();
                StyleConstants.setForeground(timeAttr, C_TIME);
                StyleConstants.setFontFamily(timeAttr, "Consolas");
                StyleConstants.setFontSize(timeAttr, 12);
                doc.insertString(doc.getLength(),
                        "[" + LocalTime.now().format(timeFmt) + "] ", timeAttr);

                // Mesaj
                SimpleAttributeSet msgAttr = new SimpleAttributeSet();
                StyleConstants.setForeground(msgAttr, color);
                StyleConstants.setFontFamily(msgAttr, "Consolas");
                StyleConstants.setFontSize(msgAttr, 13);
                doc.insertString(doc.getLength(), prefix + msg + "\n", msgAttr);

                // Otomatik kaydır
                pane.setCaretPosition(doc.getLength());
            } catch (BadLocationException ignored) {}
        });
    }

    /** Paneli temizler */
    public void clear() {
        SwingUtilities.invokeLater(() -> pane.setText(""));
    }
}
