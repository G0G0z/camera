package com.opticsight.flasher.core;

import java.io.*;
import java.net.*;
import java.nio.file.Path;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * RFC 1350 uyumlu, salt-okunur (RRQ only) TFTP sunucusu.
 * U-Boot'un firmware dosyalarını çekebilmesi için UDP 69 portunda dinler.
 * Windows'ta port 69 için Yönetici hakları gerekebilir;
 * bu durumda otomatik olarak 6969 portuna geçer.
 */
public class TftpServer {

    /* ─── TFTP Opcode sabitleri ────────────────────────────────────────────── */
    private static final int OP_RRQ  = 1;
    private static final int OP_DATA = 3;
    private static final int OP_ACK  = 4;
    private static final int OP_ERR  = 5;
    private static final int BLOCK   = 512;

    private final Path     rootDir;
    private final LogSink  log;
    private DatagramSocket serverSocket;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService pool  = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "tftp-worker");
        t.setDaemon(true);
        return t;
    });

    /** Gerçekte bağlandığı port (69 başarısız olursa 6969) */
    private int boundPort = 69;

    public TftpServer(Path rootDir, LogSink log) {
        this.rootDir = rootDir;
        this.log     = log;
    }

    /** Sunucuyu başlatır. Bağlandığı gerçek portu döndürür. */
    public int start() throws Exception {
        // Önce 69 dene, başarısız olursa 6969
        try {
            serverSocket = new DatagramSocket(69);
            boundPort = 69;
        } catch (Exception e) {
            log.warn("Port 69 açılamadı (yönetici hakları?), 6969 deneniyor...");
            serverSocket = new DatagramSocket(6969);
            boundPort = 6969;
        }
        serverSocket.setSoTimeout(500);
        running.set(true);
        log.ok("TFTP sunucusu başlatıldı → UDP:" + boundPort + " klasör=" + rootDir);

        Thread listener = new Thread(this::listenLoop, "tftp-listener");
        listener.setDaemon(true);
        listener.start();
        return boundPort;
    }

    public void stop() {
        running.set(false);
        if (serverSocket != null && !serverSocket.isClosed()) {
            serverSocket.close();
        }
        pool.shutdownNow();
        log.info("TFTP sunucusu durduruldu.");
    }

    public int getBoundPort() { return boundPort; }

    /* ─── Ana dinleme döngüsü ──────────────────────────────────────────────── */
    private void listenLoop() {
        byte[] buf = new byte[1024];
        while (running.get()) {
            DatagramPacket pkt = new DatagramPacket(buf, buf.length);
            try {
                serverSocket.receive(pkt);
            } catch (SocketTimeoutException e) {
                continue; // Normal — periyodik kontrol
            } catch (Exception e) {
                if (running.get()) log.warn("TFTP dinleme hatası: " + e.getMessage());
                break;
            }
            // Her isteği ayrı thread'de işle
            byte[] data = pkt.getData().clone();
            int    len  = pkt.getLength();
            InetAddress addr = pkt.getAddress();
            int port = pkt.getPort();
            pool.submit(() -> handleRequest(data, len, addr, port));
        }
    }

    /* ─── İstek işleyici ───────────────────────────────────────────────────── */
    private void handleRequest(byte[] data, int len, InetAddress addr, int port) {
        if (len < 4) return;
        int opcode = ((data[0] & 0xFF) << 8) | (data[1] & 0xFF);
        if (opcode != OP_RRQ) {
            sendError(addr, port, 4, "Sadece okuma destekleniyor");
            return;
        }

        // Dosya adı ve modu çıkar (null-terminated strings)
        int i = 2;
        StringBuilder sb = new StringBuilder();
        while (i < len && data[i] != 0) sb.append((char) data[i++]);
        String filename = sb.toString();
        // mode'u atla (octet bekliyoruz ama kontrol etmiyoruz)

        File file = rootDir.resolve(filename).toFile();
        if (!file.exists() || !file.isFile()) {
            log.warn("TFTP: dosya bulunamadı → " + filename);
            sendError(addr, port, 1, "Dosya bulunamadı: " + filename);
            return;
        }

        log.info("TFTP: " + addr.getHostAddress() + " → " + filename +
                 " (" + FirmwareDownloader.humanBytes(file.length()) + ")");

        try (DatagramSocket xfer = new DatagramSocket();
             InputStream fis = new BufferedInputStream(
                     new FileInputStream(file), 16 * 1024)) {

            xfer.setSoTimeout(5000);
            byte[] block = new byte[BLOCK];
            int blockNum = 1;
            int read;
            long sent = 0;

            do {
                read = readFully(fis, block);
                if (read < 0) read = 0;
                sent += read;

                // DATA paketi gönder
                byte[] pktData = new byte[4 + read];
                pktData[0] = 0; pktData[1] = OP_DATA;
                pktData[2] = (byte) (blockNum >> 8);
                pktData[3] = (byte) (blockNum & 0xFF);
                System.arraycopy(block, 0, pktData, 4, read);

                DatagramPacket dataPkt =
                        new DatagramPacket(pktData, pktData.length, addr, port);
                xfer.send(dataPkt);

                // ACK bekle
                byte[] ackBuf = new byte[4];
                DatagramPacket ackPkt = new DatagramPacket(ackBuf, 4);
                try {
                    xfer.receive(ackPkt);
                } catch (SocketTimeoutException te) {
                    log.warn("TFTP: ACK zaman aşımı, blok=" + blockNum);
                    return;
                }
                int ackBlock = ((ackBuf[2] & 0xFF) << 8) | (ackBuf[3] & 0xFF);
                if (ackBlock != blockNum) {
                    log.warn("TFTP: beklenmedik ACK blok=" + ackBlock +
                             " (beklenen=" + blockNum + ")");
                    return;
                }
                blockNum = (blockNum + 1) & 0xFFFF;

            } while (read == BLOCK);

            log.ok("TFTP: ✓ " + filename + " gönderildi (" +
                   FirmwareDownloader.humanBytes(sent) + ")");

        } catch (Exception e) {
            log.error("TFTP aktarım hatası: " + e.getMessage());
        }
    }

    private int readFully(InputStream in, byte[] buf) throws IOException {
        int total = 0;
        while (total < buf.length) {
            int n = in.read(buf, total, buf.length - total);
            if (n < 0) break;
            total += n;
        }
        return total == 0 ? -1 : total;
    }

    private void sendError(InetAddress addr, int port, int code, String msg) {
        try (DatagramSocket s = new DatagramSocket()) {
            byte[] msgBytes = msg.getBytes();
            byte[] pkt = new byte[5 + msgBytes.length];
            pkt[0] = 0; pkt[1] = OP_ERR;
            pkt[2] = 0; pkt[3] = (byte) code;
            System.arraycopy(msgBytes, 0, pkt, 4, msgBytes.length);
            pkt[pkt.length - 1] = 0;
            s.send(new DatagramPacket(pkt, pkt.length, addr, port));
        } catch (Exception ignored) {}
    }
}
