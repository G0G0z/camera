package com.opticsight.flasher.model;

/**
 * Kullanıcının girdiği tüm flash parametreleri.
 */
public class FlashConfig {

    // ── Seri Port ────────────────────────────────────────────────────────────
    public String comPort      = "";       // Örn: COM3
    public int    baudRate     = 115200;

    // ── Kamera / Firmware ────────────────────────────────────────────────────
    public String soc          = "xm530";  // xm530, xm550, hi3516ev300 ...
    public String flashSize    = "8m";     // 8m veya 16m
    public String cameraIp     = "192.168.1.200"; // U-Boot'ta atanacak IP
    public String cameraGw     = "192.168.1.1";

    // ── Ağ (TFTP) ────────────────────────────────────────────────────────────
    public String hostIp       = "";       // Otomatik algılanır

    // ── SSH (flash sonrası) ───────────────────────────────────────────────────
    public String sshUser      = "root";
    public String sshPassword  = "12345"; // OpenIPC varsayılanı
    public int    sshPort      = 22;

    // ── Kurulum seçenekleri ──────────────────────────────────────────────────
    public boolean installProvision = true;  // provision.sh kopyalanacak mı?
    public boolean installAgent     = true;  // camera-agent.sh kopyalanacak mı?

    // ── Hesaplanan alanlar ───────────────────────────────────────────────────
    /** İndirilen tek bundle dosyası, örn: openipc.xm530-nor-lite.tgz */
    public String firmwareBase() {
        return "openipc." + soc + "-nor-lite";
    }

    /** GitHub'dan indirilen tek .tgz dosyası */
    public String tgzFile() { return firmwareBase() + ".tgz"; }

    /** tgz içinden çıkan kernel dosyası — TFTP ile flash'a yazılır */
    public String kernelFile() { return "uImage." + soc; }

    /** tgz içinden çıkan rootfs dosyası — TFTP ile flash'a yazılır */
    public String rootfsFile() { return "rootfs.squashfs." + soc; }

    /** Geriye uyumluluk için (FirmwareDownloader log mesajları) */
    public String ubootFile() { return kernelFile(); }

    public String downloadBase() {
        return "https://github.com/OpenIPC/firmware/releases/download/nightly/";
    }

    /** TFTP indirme için RAM tampon boyutu */
    public String memSize() {
        return flashSize.equals("16m") ? "0x1000000" : "0x800000";
    }

    /** Kernel partition: 0x60000 (U-Boot env'den sonra) */
    public String kernelOffset() { return "0x60000"; }
    public String kernelSize()   { return "0x200000"; } // 2 MB

    /** Rootfs partition başlangıcı */
    public String rootfsOffset() { return "0x260000"; }

    /** Rootfs bölümü erase boyutu (flash sonuna kadar) */
    public String rootfsEraseSize() {
        // 8m: 0x800000 - 0x260000 = 0x5A0000
        // 16m: 0x1000000 - 0x260000 = 0xDA0000
        return flashSize.equals("16m") ? "0xDA0000" : "0x5A0000";
    }
}
