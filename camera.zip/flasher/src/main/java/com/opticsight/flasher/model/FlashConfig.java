package com.opticsight.flasher.model;

/**
 * Kullanıcının girdiği tüm flash parametreleri.
 */
public class FlashConfig {

    // ── Seri Port ────────────────────────────────────────────────────────────
    public String comPort      = "";       // Örn: COM3
    public int    baudRate     = 115200;

    // ── Kamera / Firmware ────────────────────────────────────────────────────
    public String soc          = "xm530";  // xm530, xm550, hi3516ev300 ...
    public String flashSize    = "8m";     // 8m veya 16m
    public String cameraIp     = "192.168.1.200"; // U-Boot'ta atanacak IP
    public String cameraGw     = "192.168.1.1";

    // ── Ağ (TFTP) ────────────────────────────────────────────────────────────
    public String hostIp       = "";       // Otomatik algılanır

    // ── SSH (flash sonrası) ───────────────────────────────────────────────────
    public String sshUser      = "root";
    public String sshPassword  = "12345"; // OpenIPC varsayılanı
    public int    sshPort      = 22;

    // ── Kurulum seçenekleri ──────────────────────────────────────────────────
    public boolean installProvision = true;  // provision.sh kopyalanacak mı?
    public boolean installAgent     = true;  // camera-agent.sh kopyalanacak mı?

    // ── Hesaplanan alanlar ───────────────────────────────────────────────────
    /** Firmware dosya adı tabanı, örn: openipc.xm530-br.8m */
    public String firmwareBase() {
        return "openipc." + soc + "-br." + flashSize;
    }

    public String ubootFile() { return firmwareBase() + ".uboot"; }
    public String rootfsFile() { return firmwareBase() + ".tgz";  }

    public String downloadBase() {
        return "https://github.com/OpenIPC/firmware/releases/download/latest/";
    }

    /** Flash boyutuna göre bellek adresi (hex) */
    public String memSize() {
        return flashSize.equals("16m") ? "0x1000000" : "0x800000";
    }

    /** Flash boyutuna göre rootfs erase boyutu */
    public String rootfsEraseSize() {
        return flashSize.equals("16m") ? "0xfb0000" : "0x7b0000";
    }
}
