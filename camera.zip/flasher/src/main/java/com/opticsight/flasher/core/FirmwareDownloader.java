package com.opticsight.flasher.core;

import com.opticsight.flasher.model.FlashConfig;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.BiConsumer;

/**
 * Firmware dosyalarını GitHub'dan indirir.
 * İlerleme: BiConsumer<long indirilen, long toplam>
 */
public class FirmwareDownloader {

    private final FlashConfig cfg;
    private final Path         downloadDir;
    private final BiConsumer<Long, Long> progress;  // (downloaded, total)
    private final LogSink log;

    public FirmwareDownloader(FlashConfig cfg, Path downloadDir,
                              BiConsumer<Long, Long> progress, LogSink log) {
        this.cfg         = cfg;
        this.downloadDir = downloadDir;
        this.progress    = progress;
        this.log         = log;
    }

    /**
     * Her iki firmware dosyasını indirir.
     * @return İndirilen dosyaların bulunduğu dizin
     */
    public Path downloadAll() throws Exception {
        Files.createDirectories(downloadDir);

        log.info("Firmware indirme başlıyor...");
        log.info("  U-Boot : " + cfg.ubootFile());
        log.info("  RootFS : " + cfg.rootfsFile());

        downloadFile(cfg.ubootFile());
        downloadFile(cfg.rootfsFile());

        log.ok("Firmware dosyaları indirildi → " + downloadDir);
        return downloadDir;
    }

    private void downloadFile(String filename) throws Exception {
        Path dest = downloadDir.resolve(filename);

        // Dosya zaten varsa ve boyutu > 0 ise atla
        if (Files.exists(dest) && Files.size(dest) > 0) {
            log.info("  Zaten mevcut, atlanıyor: " + filename +
                     " (" + humanBytes(Files.size(dest)) + ")");
            return;
        }

        String urlStr = cfg.downloadBase() + filename;
        log.info("  İndiriliyor: " + urlStr);

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(30_000);
        conn.setReadTimeout(120_000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent",
                "OpticSight-Flasher/1.0 (+https://opticsight.com)");
        conn.connect();

        int code = conn.getResponseCode();
        if (code == 302 || code == 301) {
            // Yönlendirme: yeni URL'den tekrar dene
            String loc = conn.getHeaderField("Location");
            conn.disconnect();
            conn = (HttpURLConnection) new URL(loc).openConnection();
            conn.setConnectTimeout(30_000);
            conn.setReadTimeout(120_000);
            conn.connect();
            code = conn.getResponseCode();
        }

        if (code != 200) {
            throw new IOException("HTTP " + code + " → " + urlStr);
        }

        long total = conn.getContentLengthLong();
        long downloaded = 0;
        byte[] buf = new byte[64 * 1024]; // 64 KB tampon

        try (InputStream in  = conn.getInputStream();
             OutputStream out = new BufferedOutputStream(
                     new FileOutputStream(dest.toFile()))) {
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                downloaded += n;
                if (progress != null) progress.accept(downloaded, total);
            }
        }

        log.ok("    ✓ " + filename + " (" + humanBytes(downloaded) + ")");
    }

    static String humanBytes(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format("%.1f KB", b / 1024.0);
        return String.format("%.2f MB", b / (1024.0 * 1024));
    }
}
