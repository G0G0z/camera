package com.opticsight.flasher.core;

import com.opticsight.flasher.model.FlashConfig;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.BiConsumer;

/**
 * Firmware dosyalarını GitHub'dan indirir.
 * İlerleme: BiConsumer<long indirilen, long toplam>
 */
public class FirmwareDownloader {

    private final FlashConfig cfg;
    private final Path         downloadDir;
    private final BiConsumer<Long, Long> progress;  // (downloaded, total)
    private final LogSink log;

    public FirmwareDownloader(FlashConfig cfg, Path downloadDir,
                              BiConsumer<Long, Long> progress, LogSink log) {
        this.cfg         = cfg;
        this.downloadDir = downloadDir;
        this.progress    = progress;
        this.log         = log;
    }

    /**
     * Firmware bundle'ı indirir ve içinden kernel + rootfs dosyalarını çıkarır.
     * @return İndirilen / çıkarılan dosyaların bulunduğu dizin
     */
    public Path downloadAll() throws Exception {
        Files.createDirectories(downloadDir);

        log.info("Firmware indirme başlıyor...");
        log.info("  Bundle : " + cfg.tgzFile());
        log.info("  URL    : " + cfg.downloadBase() + cfg.tgzFile());

        Path tgzPath = downloadFile(cfg.tgzFile());
        extractFromTgz(tgzPath);

        log.ok("Firmware dosyaları hazır → " + downloadDir);
        return downloadDir;
    }

    /**
     * tgz içinden kernel ve rootfs dosyalarını çıkarır.
     * Zaten çıkarılmışsa atlar.
     */
    private void extractFromTgz(Path tgzPath) throws Exception {
        Path kernel = downloadDir.resolve(cfg.kernelFile());
        Path rootfs = downloadDir.resolve(cfg.rootfsFile());

        if (Files.exists(kernel) && Files.size(kernel) > 0
                && Files.exists(rootfs) && Files.size(rootfs) > 0) {
            log.info("  Zaten çıkarılmış, atlanıyor: " + cfg.kernelFile()
                    + ", " + cfg.rootfsFile());
            return;
        }

        log.info("  Bundle açılıyor: " + tgzPath.getFileName());

        try (java.io.InputStream fis = new java.io.FileInputStream(tgzPath.toFile());
             java.util.zip.GZIPInputStream gis = new java.util.zip.GZIPInputStream(fis);
             org.apache.commons.compress.archivers.tar.TarArchiveInputStream tar =
                     new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(gis)) {

            org.apache.commons.compress.archivers.tar.TarArchiveEntry entry;
            while ((entry = tar.getNextTarEntry()) != null) {
                String name = entry.getName();
                // .md5sum dosyalarını atla, sadece kernel ve rootfs al
                if (name.endsWith(cfg.kernelFile()) || name.equals(cfg.kernelFile())) {
                    extractEntry(tar, downloadDir.resolve(cfg.kernelFile()));
                    log.ok("  ✓ Çıkarıldı: " + cfg.kernelFile()
                            + " (" + humanBytes(Files.size(downloadDir.resolve(cfg.kernelFile()))) + ")");
                } else if (name.endsWith(cfg.rootfsFile()) || name.equals(cfg.rootfsFile())) {
                    extractEntry(tar, downloadDir.resolve(cfg.rootfsFile()));
                    log.ok("  ✓ Çıkarıldı: " + cfg.rootfsFile()
                            + " (" + humanBytes(Files.size(downloadDir.resolve(cfg.rootfsFile()))) + ")");
                }
            }
        }

        if (!Files.exists(kernel) || Files.size(kernel) == 0) {
            throw new Exception("Bundle içinde " + cfg.kernelFile() + " bulunamadı!");
        }
        if (!Files.exists(rootfs) || Files.size(rootfs) == 0) {
            throw new Exception("Bundle içinde " + cfg.rootfsFile() + " bulunamadı!");
        }
    }

    private void extractEntry(java.io.InputStream in, Path dest) throws Exception {
        byte[] buf = new byte[64 * 1024];
        try (java.io.OutputStream out = new java.io.BufferedOutputStream(
                new java.io.FileOutputStream(dest.toFile()))) {
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
        }
    }

    private Path downloadFile(String filename) throws Exception {
        Path dest = downloadDir.resolve(filename);

        // Dosya zaten varsa ve boyutu > 0 ise atla
        if (Files.exists(dest) && Files.size(dest) > 0) {
            log.info("  Zaten mevcut, atlanıyor: " + filename +
                     " (" + humanBytes(Files.size(dest)) + ")");
            return dest;
        }

        String urlStr = cfg.downloadBase() + filename;
        log.info("  İndiriliyor: " + urlStr);

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(30_000);
        conn.setReadTimeout(120_000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent",
                "OpticSight-Flasher/1.0 (+https://opticsight.com)");
        conn.connect();

        int code = conn.getResponseCode();
        if (code == 302 || code == 301) {
            // Yönlendirme: yeni URL'den tekrar dene
            String loc = conn.getHeaderField("Location");
            conn.disconnect();
            conn = (HttpURLConnection) new URL(loc).openConnection();
            conn.setConnectTimeout(30_000);
            conn.setReadTimeout(120_000);
            conn.connect();
            code = conn.getResponseCode();
        }

        if (code != 200) {
            throw new IOException("HTTP " + code + " → " + urlStr);
        }

        long total = conn.getContentLengthLong();
        long downloaded = 0;
        byte[] buf = new byte[64 * 1024]; // 64 KB tampon

        try (InputStream in  = conn.getInputStream();
             OutputStream out = new BufferedOutputStream(
                     new FileOutputStream(dest.toFile()))) {
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                downloaded += n;
                if (progress != null) progress.accept(downloaded, total);
            }
        }

        log.ok("    ✓ " + filename + " (" + humanBytes(downloaded) + ")");
        return dest;
    }

    static String humanBytes(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format("%.1f KB", b / 1024.0);
        return String.format("%.2f MB", b / (1024.0 * 1024));
    }
}
