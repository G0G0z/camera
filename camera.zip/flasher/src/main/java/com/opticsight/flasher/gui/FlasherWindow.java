package com.opticsight.flasher.gui;

import com.opticsight.flasher.core.FlashOrchestrator;
import com.opticsight.flasher.core.FlashOrchestrator.Stage;
import com.opticsight.flasher.core.SerialManager;
import com.opticsight.flasher.model.FlashConfig;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Ana uygulama penceresi.
 *
 * Sol panel  → Konfigürasyon formu
 * Sağ panel  → Log çıktısı
 * Üst panel  → Adım göstergesi
 * Alt panel  → İlerleme çubuğu + Başlat/İptal
 */
public class FlasherWindow extends JFrame {

    /* ─── Renkler / Font ────────────────────────────────────────────────────── */
    private static final Color C_BG       = new Color(24, 24, 32);
    private static final Color C_PANEL    = new Color(32, 32, 44);
    private static final Color C_BORDER   = new Color(60, 60, 80);
    private static final Color C_ACCENT   = new Color(80, 140, 255);
    private static final Color C_BTN_OK   = new Color(50, 160, 90);
    private static final Color C_BTN_STOP = new Color(200, 60, 60);
    private static final Font  LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font  TITLE_FONT = new Font("Segoe UI", Font.BOLD,  14);

    /* ─── Form bileşenleri ──────────────────────────────────────────────────── */
    private JComboBox<String> cbPort;
    private JButton           btnRefreshPorts;
    private JComboBox<String> cbSoc;
    private JComboBox<String> cbFlash;
    private JTextField        tfCameraIp;
    private JTextField        tfCameraGw;
    private JTextField        tfHostIp;
    private JTextField        tfSshUser;
    private JPasswordField    pfSshPass;
    private JCheckBox         chkProvision;
    private JCheckBox         chkAgent;

    /* ─── Durum bileşenleri ─────────────────────────────────────────────────── */
    private StepIndicator stepIndicator;
    private LogPanel      logPanel;
    private JProgressBar  progressBar;
    private JLabel        lblStatus;
    private JButton       btnStart;
    private JButton       btnCancel;

    /* ─── İş mantığı ────────────────────────────────────────────────────────── */
    private FlashOrchestrator orchestrator;
    private Thread            workerThread;

    public FlasherWindow() {
        super("OpticSight — Kamera Flash Aracı v1.0");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 720));
        setPreferredSize(new Dimension(1200, 780));
        getContentPane().setBackground(C_BG);
        setLayout(new BorderLayout(0, 0));

        buildUI();
        pack();
        setLocationRelativeTo(null);
        refreshPorts();

        // Uygulama kapanırken temizlik
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (orchestrator != null) orchestrator.cancel();
            }
        });
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       UI İnşa
    ═══════════════════════════════════════════════════════════════════════════ */
    private void buildUI() {
        // ── Başlık ──────────────────────────────────────────────────────────
        add(buildHeader(), BorderLayout.NORTH);

        // ── İçerik (sol: form  |  sağ: log) ────────────────────────────────
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildConfigPanel(), buildLogPanel());
        split.setDividerLocation(360);
        split.setDividerSize(4);
        split.setBorder(null);
        split.setBackground(C_BG);
        add(split, BorderLayout.CENTER);

        // ── Alt bar ──────────────────────────────────────────────────────────
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    /* ─── Başlık / Adım göstergesi ──────────────────────────────────────────── */
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(20, 20, 30));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, C_BORDER));

        // Logo + isim
        JLabel title = new JLabel("  🎥 OpticSight Camera Flasher");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 0));
        header.add(title, BorderLayout.WEST);

        // Adım göstergesi
        stepIndicator = new StepIndicator();
        header.add(stepIndicator, BorderLayout.CENTER);

        return header;
    }

    /* ─── Sol: Konfigürasyon formu ──────────────────────────────────────────── */
    private JPanel buildConfigPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(C_BG);
        outer.setBorder(BorderFactory.createEmptyBorder(12, 12, 4, 6));

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(C_BG);

        // ── Seri Port ────────────────────────────────────────────────────────
        form.add(sectionTitle("🔌 Seri Port (USB-TTL)"));
        form.add(vgap(6));

        cbPort = new JComboBox<>();
        cbPort.setFont(LABEL_FONT);
        btnRefreshPorts = iconButton("↺", "Portları yenile");
        btnRefreshPorts.addActionListener(e -> refreshPorts());
        JPanel portRow = hbox(new JLabel("COM Port:"), cbPort, btnRefreshPorts);
        form.add(portRow);
        form.add(vgap(4));

        // Baud rate (sabit göster)
        form.add(hbox(new JLabel("Baud Rate:"), readonlyField("115200")));
        form.add(vgap(14));

        // ── Firmware ─────────────────────────────────────────────────────────
        form.add(sectionTitle("📦 Firmware"));
        form.add(vgap(6));

        cbSoc = new JComboBox<>(new String[]{
            "xm530", "xm550", "xm580",
            "gk7205v200", "gk7205v300", "hi3516ev300"
        });
        cbSoc.setFont(LABEL_FONT);
        cbSoc.setSelectedItem("xm530");
        form.add(hbox(new JLabel("Çip (SoC):"), cbSoc));
        form.add(vgap(4));

        cbFlash = new JComboBox<>(new String[]{"8m", "16m"});
        cbFlash.setFont(LABEL_FONT);
        form.add(hbox(new JLabel("Flash Boyutu:"), cbFlash));
        form.add(vgap(14));

        // ── Ağ Ayarları ───────────────────────────────────────────────────────
        form.add(sectionTitle("🌐 Ağ Ayarları"));
        form.add(vgap(6));

        tfCameraIp = textField("192.168.1.200");
        tfCameraGw = textField("192.168.1.1");
        tfHostIp   = textField("(otomatik algılanır)");
        tfHostIp.setForeground(new Color(150, 150, 180));

        form.add(hbox(new JLabel("Kamera IP:"),  tfCameraIp));
        form.add(vgap(4));
        form.add(hbox(new JLabel("Gateway:"),    tfCameraGw));
        form.add(vgap(4));
        form.add(hbox(new JLabel("Bilgisayar IP:"), tfHostIp));
        form.add(vgap(2));
        JLabel ipHint = new JLabel("  ℹ PC ile kamera aynı switch'e bağlı olmalı");
        ipHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        ipHint.setForeground(new Color(120, 120, 160));
        form.add(ipHint);
        form.add(vgap(14));

        // ── SSH (Flash Sonrası) ───────────────────────────────────────────────
        form.add(sectionTitle("🔐 SSH (Flash Sonrası Kurulum)"));
        form.add(vgap(6));

        tfSshUser = textField("root");
        pfSshPass = new JPasswordField("12345");
        pfSshPass.setFont(LABEL_FONT);
        styleField(pfSshPass);

        form.add(hbox(new JLabel("Kullanıcı:"), tfSshUser));
        form.add(vgap(4));
        form.add(hbox(new JLabel("Şifre:"), pfSshPass));
        form.add(vgap(14));

        // ── Kurulum Seçenekleri ───────────────────────────────────────────────
        form.add(sectionTitle("⚙  Kurulum Seçenekleri"));
        form.add(vgap(6));

        chkProvision = new JCheckBox("provision.sh kur (QR ile ilk kurulum)", true);
        chkAgent     = new JCheckBox("camera-agent.sh kur (heartbeat & event)", true);
        styleCheckbox(chkProvision);
        styleCheckbox(chkAgent);
        form.add(chkProvision);
        form.add(vgap(2));
        form.add(chkAgent);
        form.add(vgap(14));

        // ── Yardım notu ───────────────────────────────────────────────────────
        JTextArea hint = new JTextArea(
            "USB-TTL Bağlantısı:\n" +
            "  PC TX  →  Kamera RX\n" +
            "  PC RX  ←  Kamera TX\n" +
            "  PC GND —  Kamera GND\n\n" +
            "Hazır olduktan sonra\n" +
            "Başlat'a bas ve kameranın\n" +
            "gücünü TAK."
        );
        hint.setFont(new Font("Consolas", Font.PLAIN, 11));
        hint.setForeground(new Color(140, 170, 140));
        hint.setBackground(new Color(28, 36, 28));
        hint.setEditable(false);
        hint.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 80, 50), 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        hint.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
        form.add(hint);

        JScrollPane scroll = new JScrollPane(form);
        scroll.setBorder(null);
        scroll.setBackground(C_BG);
        scroll.getViewport().setBackground(C_BG);
        outer.add(scroll, BorderLayout.CENTER);
        return outer;
    }

    /* ─── Sağ: Log paneli ───────────────────────────────────────────────────── */
    private JPanel buildLogPanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(C_BG);
        p.setBorder(BorderFactory.createEmptyBorder(12, 6, 4, 12));

        JLabel lbl = new JLabel("📋 İşlem Kayıtları");
        lbl.setFont(TITLE_FONT);
        lbl.setForeground(Color.WHITE);
        lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        p.add(lbl, BorderLayout.NORTH);

        logPanel = new LogPanel();
        p.add(logPanel, BorderLayout.CENTER);
        return p;
    }

    /* ─── Alt bar ───────────────────────────────────────────────────────────── */
    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new BorderLayout(10, 0));
        bar.setBackground(new Color(20, 20, 30));
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, C_BORDER),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)
        ));

        // İlerleme
        JPanel left = new JPanel(new BorderLayout(0, 4));
        left.setOpaque(false);
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        progressBar.setPreferredSize(new Dimension(0, 24));
        lblStatus = new JLabel("Hazır — Formu doldurun ve Başlat'a basın.");
        lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblStatus.setForeground(new Color(160, 160, 200));
        left.add(lblStatus,   BorderLayout.NORTH);
        left.add(progressBar, BorderLayout.CENTER);
        bar.add(left, BorderLayout.CENTER);

        // Butonlar
        btnStart  = bigButton("▶  BAŞLAT",  C_BTN_OK);
        btnCancel = bigButton("■  İPTAL",   C_BTN_STOP);
        btnCancel.setEnabled(false);

        btnStart.addActionListener(e -> startFlash());
        btnCancel.addActionListener(e -> cancelFlash());

        JPanel buttons = new JPanel(new GridLayout(1, 2, 8, 0));
        buttons.setOpaque(false);
        buttons.setPreferredSize(new Dimension(240, 44));
        buttons.add(btnStart);
        buttons.add(btnCancel);
        bar.add(buttons, BorderLayout.EAST);

        return bar;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       İş Mantığı
    ═══════════════════════════════════════════════════════════════════════════ */

    private void startFlash() {
        if (!validateForm()) return;

        FlashConfig cfg = buildConfig();
        logPanel.clear();
        stepIndicator.reset();
        progressBar.setValue(0);
        setRunning(true);

        logPanel.info("OpticSight Camera Flasher başlatıldı.");
        logPanel.info("SoC: " + cfg.soc + "  Flash: " + cfg.flashSize +
                      "  Kamera IP: " + cfg.cameraIp);
        logPanel.info("─────────────────────────────────────────");

        orchestrator = new FlashOrchestrator(
            cfg,
            logPanel,
            stage -> SwingUtilities.invokeLater(() -> onStageChanged(stage)),
            pct   -> SwingUtilities.invokeLater(() -> progressBar.setValue(pct))
        );

        workerThread = orchestrator.startAsync();
    }

    private void cancelFlash() {
        if (orchestrator != null) orchestrator.cancel();
        logPanel.warn("Kullanıcı tarafından iptal edildi.");
        setRunning(false);
    }

    private void onStageChanged(Stage stage) {
        stepIndicator.setStage(stage);
        lblStatus.setText(stageLabel(stage));

        if (stage == Stage.DONE || stage == Stage.FAILED) {
            setRunning(false);
            if (stage == Stage.DONE) {
                JOptionPane.showMessageDialog(this,
                    "Kamera başarıyla hazırlandı!\n\n" +
                    "Kamerayı ve QR kodunu panelden tarayarak\n" +
                    "otomatik WiFi + hesap bağlantısı yapılabilir.",
                    "Kurulum Tamamlandı",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    /* ─── Yardımcılar ───────────────────────────────────────────────────────── */
    private boolean validateForm() {
        if (cbPort.getSelectedItem() == null ||
            cbPort.getSelectedItem().toString().isBlank()) {
            err("Lütfen bir COM port seçin.");
            return false;
        }
        String ip = tfCameraIp.getText().trim();
        if (!ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) {
            err("Geçersiz kamera IP adresi: " + ip);
            return false;
        }
        return true;
    }

    private FlashConfig buildConfig() {
        FlashConfig cfg = new FlashConfig();
        cfg.comPort      = cbPort.getSelectedItem().toString();
        cfg.soc          = cbSoc.getSelectedItem().toString();
        cfg.flashSize    = cbFlash.getSelectedItem().toString();
        cfg.cameraIp     = tfCameraIp.getText().trim();
        cfg.cameraGw     = tfCameraGw.getText().trim();

        String hip = tfHostIp.getText().trim();
        if (!hip.isBlank() && !hip.startsWith("(")) cfg.hostIp = hip;

        cfg.sshUser          = tfSshUser.getText().trim();
        cfg.sshPassword      = new String(pfSshPass.getPassword());
        cfg.installProvision = chkProvision.isSelected();
        cfg.installAgent     = chkAgent.isSelected();
        return cfg;
    }

    private void refreshPorts() {
        List<String> ports = SerialManager.listPorts();
        cbPort.removeAllItems();
        if (ports.isEmpty()) {
            cbPort.addItem("— Port bulunamadı —");
            logPanel.warn("USB-TTL adaptörü bağlı mı? Sürücü kurulu mu?");
        } else {
            ports.forEach(cbPort::addItem);
            logPanel.info("Bulunan portlar: " + ports);
        }
    }

    private void setRunning(boolean running) {
        btnStart.setEnabled(!running);
        btnCancel.setEnabled(running);
        cbPort.setEnabled(!running);
        cbSoc.setEnabled(!running);
        cbFlash.setEnabled(!running);
    }

    private void err(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Hata", JOptionPane.ERROR_MESSAGE);
    }

    private static String stageLabel(Stage s) {
        return switch (s) {
            case DETECTING_IP   -> "Bilgisayar IP'si algılanıyor...";
            case DOWNLOADING    -> "Firmware GitHub'dan indiriliyor...";
            case STARTING_TFTP  -> "TFTP sunucusu başlatılıyor (UDP:69)...";
            case WAITING_UBOOT  -> "U-Boot bekleniyor — kameranın gücünü TAKIN...";
            case FLASHING       -> "Firmware flash'a yazılıyor...";
            case WAITING_SSH    -> "OpenIPC açılıyor, SSH bekleniyor...";
            case DEPLOYING      -> "Scriptler kameraya yükleniyor...";
            case DONE           -> "✓ Kurulum tamamlandı!";
            case FAILED         -> "✗ Hata oluştu — log detaylarına bakın";
        };
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       UI Yardımcıları
    ═══════════════════════════════════════════════════════════════════════════ */
    private JLabel sectionTitle(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(TITLE_FONT);
        lbl.setForeground(C_ACCENT);
        lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 2, 0));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JPanel hbox(JLabel label, JComponent... fields) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(C_BG);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        label.setFont(LABEL_FONT);
        label.setForeground(new Color(190, 190, 220));
        label.setPreferredSize(new Dimension(110, 26));
        row.add(label, BorderLayout.WEST);

        if (fields.length == 1) {
            row.add(fields[0], BorderLayout.CENTER);
        } else {
            JPanel right = new JPanel(new BorderLayout(4, 0));
            right.setBackground(C_BG);
            right.add(fields[0], BorderLayout.CENTER);
            for (int i = 1; i < fields.length; i++) {
                right.add(fields[i], BorderLayout.EAST);
            }
            row.add(right, BorderLayout.CENTER);
        }
        return row;
    }

    private JTextField textField(String text) {
        JTextField tf = new JTextField(text);
        tf.setFont(LABEL_FONT);
        styleField(tf);
        return tf;
    }

    private JTextField readonlyField(String text) {
        JTextField tf = textField(text);
        tf.setEditable(false);
        tf.setForeground(new Color(140, 180, 140));
        return tf;
    }

    private void styleField(JTextField tf) {
        tf.setBackground(new Color(40, 40, 58));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_BORDER),
            BorderFactory.createEmptyBorder(3, 7, 3, 7)
        ));
    }

    private void styleCheckbox(JCheckBox cb) {
        cb.setFont(LABEL_FONT);
        cb.setForeground(new Color(190, 190, 220));
        cb.setBackground(C_BG);
        cb.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private JButton iconButton(String text, String tooltip) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setToolTipText(tooltip);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(50, 50, 70));
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton bigButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);

        // Hover efekti
        Color hover = bg.brighter();
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private Component vgap(int h) {
        return Box.createRigidArea(new Dimension(0, h));
    }
}
