package com.opticsight.flasher.core;

import com.opticsight.flasher.model.FlashConfig;

import java.util.function.Consumer;

/**
 * U-Boot üzerinden XM530 firmware yazma otomasyonu.
 *
 * Akış:
 *  1. Kamera açılırken boot sayacı görünene kadar Enter gönder
 *  2. U-Boot prompt alındıktan sonra ortam değişkenlerini ayarla
 *  3. TFTP ile firmware çek, flash'a yaz
 *  4. reset komutu gönder
 */
public class UBootFlasher {

    // U-Boot'u kesmek için ne kadar süre Enter tuşuna basacağız
    private static final long INTERRUPT_WINDOW_MS = 8_000;
    private static final long TFTP_TIMEOUT_MS     = 120_000;  // 2 dk
    private static final long FLASH_TIMEOUT_MS    = 180_000;  // 3 dk
    private static final long PROMPT_TIMEOUT_MS   = 10_000;

    private final SerialManager serial;
    private final FlashConfig   cfg;
    private final LogSink       log;
    private final Consumer<Integer> stepCallback; // 0-100 ilerleme

    public UBootFlasher(SerialManager serial, FlashConfig cfg,
                        LogSink log, Consumer<Integer> stepCallback) {
        this.serial       = serial;
        this.cfg          = cfg;
        this.log          = log;
        this.stepCallback = stepCallback;
    }

    /**
     * Tam flash akışını çalıştırır.
     * Blokleyici — arka plan thread'inde çağırın.
     */
    public void flash() throws Exception {
        step(0);
        interruptBoot();
        step(10);
        configureEnvironment();
        step(20);
        flashUboot();
        step(50);
        flashRootfs();
        step(90);
        resetCamera();
        step(100);
    }

    /* ─── 1. Boot kesmesi ───────────────────────────────────────────────────── */
    private void interruptBoot() throws Exception {
        log.info("◆ Kamera açılıyor — U-Boot yakalanmaya çalışılıyor...");
        log.info("  Kameranın gücünü şimdi takın.");

        serial.clearQueue();
        long deadline = System.currentTimeMillis() + INTERRUPT_WINDOW_MS;

        // Boot sayacı görünene kadar Enter gönder
        boolean caught = false;
        while (System.currentTimeMillis() < deadline) {
            serial.sendEnter();
            Thread.sleep(150);

            // Prompt yakalandı mı?
            String line = serial.waitFor("#", 300);
            if (line != null) {
                caught = true;
                break;
            }
            // "autoboot" veya "Hit any key" göründüyse
            line = serial.waitFor("autoboot", 100);
            if (line != null) {
                serial.sendEnter();
                caught = serial.waitForPrompt(3000);
                break;
            }
        }

        if (!caught) {
            // Son bir şans — 5 saniye daha bekle
            caught = serial.waitForPrompt(5000);
        }

        if (!caught) {
            throw new Exception(
                "U-Boot prompt yakalanamadı.\n" +
                "Kontrol listesi:\n" +
                "  • TX/RX çapraz mı bağlandı?\n" +
                "  • GND bağlı mı?\n" +
                "  • Doğru COM port seçildi mi?\n" +
                "  • Kameranın gücünü YENI takın ve tekrar deneyin."
            );
        }

        log.ok("✓ U-Boot prompt alındı!");
    }

    /* ─── 2. Ortam değişkenleri ─────────────────────────────────────────────── */
    private void configureEnvironment() throws Exception {
        log.info("◆ Ağ ortamı ayarlanıyor...");

        sendCommand("setenv serverip " + cfg.hostIp,   "");
        sendCommand("setenv ipaddr "   + cfg.cameraIp, "");
        sendCommand("setenv netmask 255.255.255.0",    "");
        sendCommand("setenv gatewayip " + cfg.cameraGw,"");

        log.ok("✓ Ağ ayarları: kamera=" + cfg.cameraIp +
               " sunucu=" + cfg.hostIp);

        // Bağlantı testi
        log.info("  Ağ bağlantısı test ediliyor (ping)...");
        sendCommand("ping " + cfg.hostIp, "");
        String pong = serial.waitFor("alive", 8000);
        if (pong == null) {
            log.warn("  Ping yanıt vermedi — ethernet kablosu takılı mı?");
            // Bloklayan değil, devam ediyoruz
        } else {
            log.ok("  ✓ Ping başarılı");
        }
    }

    /* ─── 3. U-Boot flash yazma ─────────────────────────────────────────────── */
    private void flashUboot() throws Exception {
        log.info("◆ U-Boot firmware yazılıyor: " + cfg.ubootFile());

        // Belleği temizle
        sendAndWaitPrompt("mw.b 0x82000000 ff " + cfg.memSize());

        // TFTP ile indir
        log.info("  TFTP indirme: " + cfg.ubootFile());
        sendCommand("tftp 0x82000000 " + cfg.ubootFile(), "");
        String done = serial.waitFor("Bytes transferred", TFTP_TIMEOUT_MS);
        if (done == null) {
            throw new Exception("U-Boot TFTP indirme zaman aşımına uğradı.\n" +
                    "TFTP sunucusunun çalıştığından ve kameranın " +
                    cfg.hostIp + " adresine erişebildiğinden emin olun.");
        }
        log.ok("  ✓ TFTP tamamlandı: " + done.trim());

        // Flash sürücüsünü başlat
        sendAndWaitPrompt("sf probe 0; sf lock 0");

        // Sil
        log.info("  Flash siliniyor (U-Boot bölümü)...");
        sendCommand("sf erase 0x0 0x50000", "");
        waitFlashOp("Erased", FLASH_TIMEOUT_MS);

        // Yaz
        log.info("  Flash yazılıyor...");
        sendCommand("sf write 0x82000000 0x0 0x50000", "");
        waitFlashOp("Written", FLASH_TIMEOUT_MS);

        log.ok("✓ U-Boot başarıyla yazıldı.");
    }

    /* ─── 4. RootFS flash yazma ─────────────────────────────────────────────── */
    private void flashRootfs() throws Exception {
        log.info("◆ RootFS yazılıyor: " + cfg.rootfsFile());

        // Belleği temizle
        sendAndWaitPrompt("mw.b 0x82000000 ff " + cfg.memSize());

        // TFTP
        log.info("  TFTP indirme: " + cfg.rootfsFile());
        sendCommand("tftp 0x82000000 " + cfg.rootfsFile(), "");
        String done = serial.waitFor("Bytes transferred", TFTP_TIMEOUT_MS);
        if (done == null) {
            throw new Exception("RootFS TFTP indirme zaman aşımına uğradı.");
        }
        log.ok("  ✓ TFTP tamamlandı: " + done.trim());

        // Sil
        log.info("  Flash siliniyor (RootFS bölümü)...");
        sendCommand("sf erase 0x50000 " + cfg.rootfsEraseSize(), "");
        waitFlashOp("Erased", FLASH_TIMEOUT_MS);

        // Yaz
        log.info("  Flash yazılıyor...");
        sendCommand("sf write 0x82000000 0x50000 " + cfg.rootfsEraseSize(), "");
        waitFlashOp("Written", FLASH_TIMEOUT_MS);

        log.ok("✓ RootFS başarıyla yazıldı.");
    }

    /* ─── 5. Yeniden başlatma ───────────────────────────────────────────────── */
    private void resetCamera() throws Exception {
        log.info("◆ Kamera yeniden başlatılıyor...");
        serial.writeLine("reset");
        log.ok("✓ Kamera yeniden başlatma komutu gönderildi.");
        log.info("  OpenIPC açılması ~60-90 saniye sürer...");
    }

    /* ─── Yardımcılar ───────────────────────────────────────────────────────── */
    private void sendCommand(String cmd, @SuppressWarnings("unused") String waitFor)
            throws Exception {
        Thread.sleep(200);
        serial.writeLine(cmd);
    }

    private void sendAndWaitPrompt(String cmd) throws Exception {
        Thread.sleep(200);
        serial.writeLine(cmd);
        boolean got = serial.waitForPrompt(PROMPT_TIMEOUT_MS);
        if (!got) log.warn("  Prompt bekleniyor: " + cmd);
    }

    private void waitFlashOp(String keyword, long timeout) throws InterruptedException {
        String result = serial.waitFor(keyword, timeout);
        if (result == null) {
            log.warn("  Flash işlemi çıktısı alınamadı — devam ediliyor...");
        }
    }

    private void step(int pct) {
        if (stepCallback != null) stepCallback.accept(pct);
    }
}
