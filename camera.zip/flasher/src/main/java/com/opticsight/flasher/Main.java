package com.opticsight.flasher;

import com.formdev.flatlaf.FlatDarkLaf;
import com.opticsight.flasher.gui.FlasherWindow;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // FlatLaf koyu tema — Windows'ta modern görünüm
        FlatDarkLaf.setup();

        // Swing EDT'de başlat
        SwingUtilities.invokeLater(() -> {
            FlasherWindow window = new FlasherWindow();
            window.setVisible(true);
        });
    }
}
