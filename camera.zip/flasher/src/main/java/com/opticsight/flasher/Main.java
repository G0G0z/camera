package com.opticsight.flasher;

import com.formdev.flatlaf.FlatDarkLaf;
import com.opticsight.flasher.gui.FlasherWindow;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        // L&F kurulumu — main thread'de yap (Swing EDT'den önce)
        setupLookAndFeel();

        SwingUtilities.invokeLater(() -> {
            // FlatLaf gerçekten çalışıyor mu? EDT içinde test et.
            if (UIManager.getLookAndFeel().getClass().getName().contains("Flat")) {
                try {
                    // Temel bir bileşen oluşturup UI sınıfının yüklenip
                    // yüklenmediğini kontrol et. Yüklenemediyse Error fırlatır.
                    new JLabel("probe").getUI();
                } catch (Throwable t) {
                    // FlatLaf sınıfları yüklenemedi → daha sağlam bir L&F'e geç
                    fallbackLookAndFeel();
                }
            }

            FlasherWindow window = new FlasherWindow();
            window.setVisible(true);
        });
    }

    /** FlatLaf → Nimbus → Metal → varsayılan sırasıyla dener */
    private static void setupLookAndFeel() {
        try {
            if (FlatDarkLaf.setup()) return;
        } catch (Throwable ignored) {}
        fallbackLookAndFeel();
    }

    private static void fallbackLookAndFeel() {
        // 1. Nimbus — pure-Java, tüm platformlarda çalışır, modern görünüm
        try {
            for (UIManager.LookAndFeelInfo laf : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(laf.getName())) {
                    UIManager.setLookAndFeel(laf.getClassName());
                    applyDarkNimbus();
                    return;
                }
            }
        } catch (Throwable ignored) {}

        // 2. Metal (cross-platform) — en az ortak payda
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            applyDarkMetal();
        } catch (Throwable ignored) {}
    }

    /** Nimbus'a yaklaşık bir koyu palet uygular */
    private static void applyDarkNimbus() {
        UIManager.put("nimbusBase",             new Color(24,  24,  36));
        UIManager.put("nimbusBlueGrey",         new Color(45,  45,  65));
        UIManager.put("control",                new Color(32,  32,  44));
        UIManager.put("nimbusLightBackground",  new Color(28,  28,  40));
        UIManager.put("text",                   new Color(220, 220, 240));
        UIManager.put("nimbusFocus",            new Color(80,  140, 255));
        UIManager.put("nimbusSelectedText",     Color.WHITE);
        UIManager.put("nimbusSelectionBackground", new Color(70, 110, 200));
    }

    /** Metal L&F için koyu tema */
    private static void applyDarkMetal() {
        try {
            javax.swing.plaf.metal.MetalLookAndFeel.setCurrentTheme(
                new javax.swing.plaf.metal.DefaultMetalTheme() {
                    @Override public javax.swing.plaf.ColorUIResource getWindowBackground()
                        { return new javax.swing.plaf.ColorUIResource(24, 24, 36); }
                    @Override public javax.swing.plaf.ColorUIResource getMenuBackground()
                        { return new javax.swing.plaf.ColorUIResource(32, 32, 44); }
                    @Override public javax.swing.plaf.ColorUIResource getControl()
                        { return new javax.swing.plaf.ColorUIResource(40, 40, 58); }
                    @Override public javax.swing.plaf.ColorUIResource getControlTextColor()
                        { return new javax.swing.plaf.ColorUIResource(220, 220, 240); }
                    @Override public javax.swing.plaf.ColorUIResource getSystemTextColor()
                        { return new javax.swing.plaf.ColorUIResource(200, 200, 220); }
                }
            );
        } catch (Throwable ignored) {}
    }
}
