package com.opticsight.flasher.core;

import com.fazecast.jSerialComm.SerialPort;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * USB-TTL / COM port iletişimi.
 * Gelen satırları bir kuyruğa atar; waitFor() ile belirli bir çıktıyı bekler.
 */
public class SerialManager implements AutoCloseable {

    private final SerialPort port;
    private final LogSink    log;
    private OutputStream     out;
    private final LinkedBlockingQueue<String> lineQueue = new LinkedBlockingQueue<>(4096);
    private volatile boolean opened = false;

    public SerialManager(String portName, int baud, LogSink log) throws Exception {
        this.log  = log;
        this.port = SerialPort.getCommPort(portName);
        port.setBaudRate(baud);
        port.setNumDataBits(8);
        port.setNumStopBits(SerialPort.ONE_STOP_BIT);
        port.setParity(SerialPort.NO_PARITY);
        port.setFlowControl(SerialPort.FLOW_CONTROL_DISABLED);
        port.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 200, 0);

        if (!port.openPort()) {
            throw new IOException("Port açılamadı: " + portName +
                    " (başka program kullanıyor olabilir)");
        }
        opened = true;
        out    = port.getOutputStream();
        log.ok("Seri port açıldı: " + portName + " @ " + baud + " baud");

        // Okuma thread'i
        Thread reader = new Thread(this::readLoop, "serial-reader");
        reader.setDaemon(true);
        reader.start();
    }

    /* ─── Tüm mevcut COM portlarını listele ─────────────────────────────────── */
    public static List<String> listPorts() {
        List<String> list = new ArrayList<>();
        try {
            for (SerialPort p : SerialPort.getCommPorts()) {
                list.add(p.getSystemPortName());
            }
        } catch (UnsatisfiedLinkError | ExceptionInInitializerError | NoClassDefFoundError e) {
            // jSerialComm native library yüklenemedi — boş liste döndür,
            // GUI açılmaya devam eder ve kullanıcıya uyarı gösterilir.
            System.err.println("[SerialManager] Native kütüphane yüklenemedi: " + e.getMessage());
        }
        return list;
    }

    /* ─── Satır yazma ───────────────────────────────────────────────────────── */
    public synchronized void writeLine(String line) throws IOException {
        byte[] bytes = (line + "\r\n").getBytes(StandardCharsets.US_ASCII);
        out.write(bytes);
        out.flush();
    }

    /** Sadece Enter tuşu gönder (U-Boot kesme için) */
    public synchronized void sendEnter() throws IOException {
        out.write('\r');
        out.flush();
    }

    /** Tek karakter gönder */
    public synchronized void sendChar(char c) throws IOException {
        out.write((byte) c);
        out.flush();
    }

    /* ─── Bekleme metodları ─────────────────────────────────────────────────── */

    /**
     * Belirli bir string'i içeren satır gelene kadar bekler.
     * @param pattern     aranacak metin
     * @param timeoutMs   maksimum bekleme süresi
     * @return eşleşen satır, zaman aşımında null
     */
    public String waitFor(String pattern, long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            long remaining = deadline - System.currentTimeMillis();
            if (remaining <= 0) break;
            String line = lineQueue.poll(Math.min(remaining, 500), TimeUnit.MILLISECONDS);
            if (line != null && line.contains(pattern)) {
                return line;
            }
        }
        return null;
    }

    /**
     * Regex ile eşleşen satır gelene kadar bekler.
     */
    public String waitForPattern(Pattern pattern, long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            long remaining = deadline - System.currentTimeMillis();
            if (remaining <= 0) break;
            String line = lineQueue.poll(Math.min(remaining, 500), TimeUnit.MILLISECONDS);
            if (line != null && pattern.matcher(line).find()) {
                return line;
            }
        }
        return null;
    }

    /**
     * U-Boot prompt'unu (# veya >) yakalar.
     */
    public boolean waitForPrompt(long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            long remaining = deadline - System.currentTimeMillis();
            if (remaining <= 0) break;
            String line = lineQueue.poll(Math.min(remaining, 200), TimeUnit.MILLISECONDS);
            if (line != null && (line.contains("# ") || line.endsWith("#") ||
                    line.contains("> ") || line.endsWith(">"))) {
                return true;
            }
        }
        return false;
    }

    /** Kuyruğu temizle */
    public void clearQueue() { lineQueue.clear(); }

    /* ─── Okuma döngüsü ─────────────────────────────────────────────────────── */
    private void readLoop() {
        InputStream in = port.getInputStream();
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[256];

        while (opened && port.isOpen()) {
            try {
                int n = in.read(buf);
                if (n <= 0) continue;
                String chunk = new String(buf, 0, n, StandardCharsets.US_ASCII);

                for (char c : chunk.toCharArray()) {
                    if (c == '\n') {
                        String line = sb.toString().replace("\r", "").trim();
                        if (!line.isEmpty()) {
                            log.serial(line);
                            lineQueue.offer(line);
                        }
                        sb.setLength(0);
                    } else {
                        sb.append(c);
                    }
                }
            } catch (Exception e) {
                if (opened) log.warn("Seri okuma hatası: " + e.getMessage());
                break;
            }
        }
    }

    @Override
    public void close() {
        opened = false;
        if (port != null && port.isOpen()) {
            port.closePort();
        }
        log.info("Seri port kapatıldı.");
    }
}
