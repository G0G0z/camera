package com.opticsight.flasher.core;

import com.opticsight.flasher.model.FlashConfig;

import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.function.Consumer;

/**
 * Tüm flash akışını yönetir:
 *  1. Host IP algıla
 *  2. Firmware indir
 *  3. TFTP sunucusu başlat
 *  4. Seri port aç, U-Boot flash
 *  5. SSH ile script kur
 *  6. Temizlik
 *
 * Çalışma durumu callback'ler ile bildirilir — UI doğrudan çağırmaz.
 */
public class FlashOrchestrator {

    public enum Stage {
        DETECTING_IP,
        DOWNLOADING,
        STARTING_TFTP,
        WAITING_UBOOT,
        FLASHING,
        WAITING_SSH,
        DEPLOYING,
        DONE,
        FAILED
    }

    private final FlashConfig          cfg;
    private final LogSink              log;
    private final Consumer<Stage>      stageCallback;
    private final Consumer<Integer>    progressCallback; // 0-100

    private TftpServer   tftpServer;
    private SerialManager serial;
    private boolean       cancelled = false;

    public FlashOrchestrator(FlashConfig cfg, LogSink log,
                             Consumer<Stage> stageCallback,
                             Consumer<Integer> progressCallback) {
        this.cfg              = cfg;
        this.log              = log;
        this.stageCallback    = stageCallback;
        this.progressCallback = progressCallback;
    }

    /** Asenkron başlatma — kendi thread'ini döndürür. */
    public Thread startAsync() {
        Thread t = new Thread(() -> {
            try {
                run();
            } catch (InterruptedException e) {
                log.warn("İşlem iptal edildi.");
                stage(Stage.FAILED);
            } catch (Exception e) {
                log.error("HATA: " + e.getMessage());
                // Hata mesajındaki her satırı ayrı log
                for (String line : e.getMessage().split("\n")) {
                    if (!line.equals(e.getMessage().split("\n")[0]))
                        log.error("       " + line);
                }
                stage(Stage.FAILED);
            } finally {
                cleanup();
            }
        }, "flash-orchestrator");
        t.setDaemon(true);
        t.start();
        return t;
    }

    public void cancel() { cancelled = true; }

    /* ─── Ana akış ──────────────────────────────────────────────────────────── */
    private void run() throws Exception {
        // 1. Host IP
        stage(Stage.DETECTING_IP);
        if (cfg.hostIp == null || cfg.hostIp.isBlank()) {
            cfg.hostIp = detectHostIp(cfg.cameraIp);
            log.ok("Host IP algılandı: " + cfg.hostIp);
        }
        progress(5);
        checkCancelled();

        // 2. Firmware indir
        stage(Stage.DOWNLOADING);
        Path fwDir = Paths.get(System.getProperty("user.home"),
                               "opticsight-firmware",
                               cfg.soc + "-" + cfg.flashSize);
        new FirmwareDownloader(cfg, fwDir,
                (dl, total) -> {
                    if (total > 0) progress((int)(5 + dl * 20 / total));
                }, log).downloadAll();
        progress(25);
        checkCancelled();

        // 3. TFTP sunucusu
        stage(Stage.STARTING_TFTP);
        tftpServer = new TftpServer(fwDir, log);
        int tftpPort = tftpServer.start();

        // U-Boot 69 portunu kullanır — eğer farklı port açıldıysa uyar
        if (tftpPort != 69) {
            log.warn("─────────────────────────────────────────────────────");
            log.warn("UYARI: Port 69 açılamadı — " + tftpPort + " kullanılıyor.");
            log.warn("U-Boot TFTP için port 69'u kullanır.");
            log.warn("Lütfen uygulamayı Yönetici olarak başlatın.");
            log.warn("─────────────────────────────────────────────────────");
        }
        progress(30);
        checkCancelled();

        // 4. Seri port + U-Boot
        stage(Stage.WAITING_UBOOT);
        serial = new SerialManager(cfg.comPort, cfg.baudRate, log);
        stage(Stage.FLASHING);
        new UBootFlasher(serial, cfg, log,
                p -> progress(30 + p * 50 / 100)).flash();
        progress(80);
        checkCancelled();

        // Seri portu artık kapata biliriz
        serial.close();
        serial = null;

        // 5-6. SSH kurulumu
        if (cfg.installProvision || cfg.installAgent) {
            stage(Stage.WAITING_SSH);
            new SshDeployer(cfg, log,
                    p -> progress(80 + p * 20 / 100)).deployAndConfigure();
        }

        progress(100);
        stage(Stage.DONE);
        log.ok("══════════════════════════════════════════");
        log.ok("  Kurulum TAMAMLANDI!");
        log.ok("  Kamera IP: " + cfg.cameraIp);
        log.ok("  SSH: ssh root@" + cfg.cameraIp + "  (şifre: " + cfg.sshPassword + ")");
        log.ok("  Kameranın önüne QR kodu tutun → otomatik bağlanacak");
        log.ok("══════════════════════════════════════════");
    }

    /* ─── Host IP algılama ──────────────────────────────────────────────────── */
    /**
     * Kameranın IP'siyle aynı alt ağdaki yerel IP'yi bulur.
     * Bulamazsa ilk non-loopback IPv4 adresini döndürür.
     */
    public static String detectHostIp(String targetIp) {
        try {
            // Kameranın ağına çıkabilecek arayüzü bul
            try (java.net.Socket s = new java.net.Socket()) {
                s.connect(new InetSocketAddress(targetIp, 80), 1000);
                return s.getLocalAddress().getHostAddress();
            } catch (Exception ignored) {}

            // Fallback: ilk non-loopback IPv4
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        return addr.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {
            // ignore
        }
        return "192.168.1.1";
    }

    /* ─── Yardımcılar ───────────────────────────────────────────────────────── */
    private void checkCancelled() throws InterruptedException {
        if (cancelled) throw new InterruptedException("Kullanıcı tarafından iptal edildi");
    }

    private void stage(Stage s) {
        if (stageCallback != null) stageCallback.accept(s);
    }

    private void progress(int pct) {
        if (progressCallback != null) progressCallback.accept(Math.min(100, pct));
    }

    private void cleanup() {
        if (serial != null) { serial.close(); serial = null; }
        if (tftpServer != null) { tftpServer.stop(); tftpServer = null; }
    }
}
