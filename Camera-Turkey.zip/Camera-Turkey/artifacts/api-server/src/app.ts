import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { createProxyMiddleware } from "http-proxy-middleware";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) { return { id: req.id, method: req.method, url: req.url?.split("?")[0] }; },
      res(res) { return { statusCode: res.statusCode }; },
    },
  }),
);

app.use(cors());

// Tüm istekleri PHP backend'e ilet (path prefix dahil)
const PHP_URL = process.env.PHP_BACKEND_URL ?? "http://localhost:8008";

app.use(
  "/",
  createProxyMiddleware({
    target: PHP_URL,
    changeOrigin: true,
    on: {
      error: (err, _req, res: any) => {
        logger.error({ err }, "PHP proxy error");
        res.status(502).json({ error: "PHP backend kullanılamıyor" });
      },
    },
  }),
);

export default app;
