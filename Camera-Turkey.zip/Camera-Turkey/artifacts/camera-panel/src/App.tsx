import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { Layout } from '@/components/layout';
import { useAuthStore } from '@/store/auth';
import { useEffect } from 'react';
import { useGetMe } from '@workspace/api-client-react';

import Dashboard from '@/pages/dashboard';
import Login from '@/pages/login';
import CamerasPage from '@/pages/cameras';
import CameraDetail from '@/pages/camera-detail';
import RecordingsPage from '@/pages/recordings';
import EventsPage from '@/pages/events';
import CustomersPage from '@/pages/customers';
import CustomerDetail from '@/pages/customer-detail';
import UsersPage from '@/pages/users';
import FirmwarePage from '@/pages/firmware';
import RegisterPage from '@/pages/register';
import ProfilePage from '@/pages/profile';
import WifiSetupPage from '@/pages/wifi-setup';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function ProtectedRoute({ component: Component, ...rest }: any) {
  const [location, setLocation] = useLocation();
  const isAuthenticated = useAuthStore(s => s.isAuthenticated);
  const setAuthenticated = useAuthStore(s => s.setAuthenticated);
  const { data, isError, isLoading } = useGetMe({ 
    query: { retry: false, queryKey: ['me'] } 
  });

  useEffect(() => {
    if (isError) {
      setAuthenticated(false);
      setLocation('/login');
    } else if (data) {
      setAuthenticated(true);
    }
  }, [isError, data, setLocation, setAuthenticated]);

  if (isLoading) return <div className="min-h-screen bg-background flex items-center justify-center text-muted-foreground">Checking session...</div>;
  if (!isAuthenticated) return null;

  return (
    <Route {...rest}>
      {params => (
        <Layout>
          <Component params={params} />
        </Layout>
      )}
    </Route>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={RegisterPage} />
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/cameras" component={CamerasPage} />
      <ProtectedRoute path="/cameras/:id" component={CameraDetail} />
      <ProtectedRoute path="/recordings" component={RecordingsPage} />
      <ProtectedRoute path="/events" component={EventsPage} />
      <ProtectedRoute path="/customers" component={CustomersPage} />
      <ProtectedRoute path="/customers/:id" component={CustomerDetail} />
      <ProtectedRoute path="/users" component={UsersPage} />
      <ProtectedRoute path="/firmware" component={FirmwarePage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/wifi-setup" component={WifiSetupPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
