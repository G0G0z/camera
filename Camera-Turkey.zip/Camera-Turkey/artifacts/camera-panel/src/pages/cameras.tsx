import { useGetCameras, useGetCameraStatus, useGetCameraSnapshot } from "@workspace/api-client-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Camera, Settings, ActivitySquare, AlertCircle } from "lucide-react"
import { Link } from "wouter"
import { useEffect, useState } from "react"

const CameraStatusBadge = ({ id, initialStatus }: { id: number, initialStatus: string }) => {
  const { data } = useGetCameraStatus(id, { 
    query: { refetchInterval: 30000, enabled: !!id, queryKey: ['camera-status', id] } 
  })
  
  const status = data?.status || initialStatus
  
  if (status === 'online') {
    return <Badge className="bg-emerald-500 hover:bg-emerald-600 text-white border-transparent">Online</Badge>
  } else if (status === 'offline') {
    return <Badge variant="destructive">Offline</Badge>
  }
  return <Badge variant="secondary">Unknown</Badge>
}

const CameraSnapshot = ({ id }: { id: number }) => {
  const { data, isError } = useGetCameraSnapshot(id, {
    query: { enabled: !!id, queryKey: ['camera-snapshot', id] }
  })

  if (isError || !data?.url) {
    return (
      <div className="absolute inset-0 bg-muted flex items-center justify-center text-muted-foreground flex-col">
        <Camera className="w-8 h-8 opacity-20 mb-2" />
        <span className="text-xs opacity-50">No signal</span>
      </div>
    )
  }

  return (
    <img 
      src={data.url} 
      alt="Camera stream preview" 
      className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-105 duration-700" 
    />
  )
}

export default function CamerasPage() {
  const { data: cameras, isLoading } = useGetCameras()

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Cameras</h1>
            <p className="text-muted-foreground mt-1">Manage and view all connected cameras</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="aspect-video bg-muted rounded-xl"></div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Cameras</h1>
          <p className="text-muted-foreground mt-1">Manage and view all connected cameras</p>
        </div>
      </div>

      {!cameras?.length ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <Camera className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium">No cameras found</h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-sm">
              Your system doesn't have any cameras configured yet. Contact your administrator to add cameras to your account.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {cameras.map(camera => (
            <Link key={camera.id} href={`/cameras/${camera.id}`} className="group block">
              <Card className="overflow-hidden border-border/50 hover:border-primary/30 transition-colors shadow-sm hover:shadow-md">
                <div className="aspect-video relative bg-black/90 overflow-hidden">
                  <CameraSnapshot id={camera.id} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                  
                  <div className="absolute top-3 left-3">
                    <CameraStatusBadge id={camera.id} initialStatus={camera.status} />
                  </div>
                  
                  <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                    <div className="text-white drop-shadow-md">
                      <div className="font-semibold text-sm truncate">{camera.name}</div>
                      <div className="text-xs text-white/70 truncate">{camera.location || camera.ip}</div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-3 bg-card flex items-center gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1.5" title="PTZ Support">
                    <Settings className={`w-3.5 h-3.5 ${camera.ptzEnabled ? 'text-primary' : 'opacity-30'}`} />
                    <span className={camera.ptzEnabled ? 'text-foreground font-medium' : ''}>PTZ</span>
                  </div>
                  <div className="flex items-center gap-1.5" title="Recording">
                    <ActivitySquare className={`w-3.5 h-3.5 ${camera.recordingEnabled ? 'text-red-500' : 'opacity-30'}`} />
                    <span className={camera.recordingEnabled ? 'text-foreground font-medium' : ''}>REC</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
