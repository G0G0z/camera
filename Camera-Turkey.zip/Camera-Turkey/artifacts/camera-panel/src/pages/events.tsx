import { useState } from "react"
import { useGetEvents } from "@workspace/api-client-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { UserIcon, Car, ActivitySquare, Ban, Activity, Filter, Clock } from "lucide-react"
import { format } from "date-fns"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const EventIcon = ({ type, className }: { type: string, className?: string }) => {
  switch (type) {
    case 'person': return <UserIcon className={`text-blue-500 ${className}`} />
    case 'vehicle': return <Car className={`text-orange-500 ${className}`} />
    case 'face': return <UserIcon className={`text-indigo-500 ${className}`} />
    case 'tamper': return <Ban className={`text-red-500 ${className}`} />
    case 'motion':
    default: return <ActivitySquare className={`text-emerald-500 ${className}`} />
  }
}

export default function EventsPage() {
  const [page, setPage] = useState(1)
  const [typeFilter, setTypeFilter] = useState<string>("all")
  
  const { data: events, isLoading } = useGetEvents({ 
    page, 
    limit: 24,
    ...(typeFilter !== 'all' ? { type: typeFilter } : {})
  })

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">AI Events Log</h1>
          <p className="text-muted-foreground mt-1">Smart detections and motion triggers</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 animate-pulse">
          {[1,2,3,4,5,6,7,8].map(i => <div key={i} className="h-48 bg-muted rounded-xl"></div>)}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">AI Events Log</h1>
          <p className="text-muted-foreground mt-1">Smart detections and motion triggers</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setPage(1); }}>
            <SelectTrigger className="w-[180px]">
              <Filter className="w-4 h-4 mr-2 opacity-50" />
              <SelectValue placeholder="All Events" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Events</SelectItem>
              <SelectItem value="person">Person Detection</SelectItem>
              <SelectItem value="vehicle">Vehicle Detection</SelectItem>
              <SelectItem value="face">Face Recognition</SelectItem>
              <SelectItem value="motion">Motion</SelectItem>
              <SelectItem value="tamper">Camera Tamper</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {!events?.length ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center p-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <Activity className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium">No events recorded</h3>
            <p className="text-sm text-muted-foreground mt-1">
              There are no AI or motion events matching your filters.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {events.map(event => (
            <Card key={event.id} className="overflow-hidden border-border/50 shadow-sm hover:shadow-md transition-shadow group">
              <div className="aspect-video relative bg-black/90">
                {event.snapshotUrl ? (
                  <img src={event.snapshotUrl} alt="Event snapshot" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                    <Activity className="w-8 h-8 opacity-20" />
                  </div>
                )}
                <div className="absolute top-2 left-2 flex gap-2">
                  <Badge variant="secondary" className="bg-black/60 text-white hover:bg-black/80 border-transparent backdrop-blur-sm shadow-sm">
                    <EventIcon type={event.type} className="w-3 h-3 mr-1.5" />
                    <span className="capitalize">{event.type}</span>
                  </Badge>
                  {event.confidence && (
                    <Badge variant="secondary" className="bg-black/60 text-white hover:bg-black/80 border-transparent backdrop-blur-sm shadow-sm font-mono">
                      {Math.round(event.confidence * 100)}%
                    </Badge>
                  )}
                </div>
              </div>
              <CardContent className="p-3">
                <div className="flex justify-between items-start">
                  <div className="min-w-0">
                    <div className="font-medium text-sm truncate pr-2">{event.cameraName || `Camera #${event.cameraId}`}</div>
                    <div className="flex items-center text-xs text-muted-foreground mt-1">
                      <Clock className="w-3 h-3 mr-1" />
                      {format(new Date(event.timestamp), "MMM d, HH:mm:ss")}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Simple pagination for events grid */}
      <div className="flex justify-center pt-4">
        <div className="flex gap-2">
          <Button variant="outline" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Newer</Button>
          <Button variant="outline" disabled={events?.length < 24} onClick={() => setPage(p => p + 1)}>Older</Button>
        </div>
      </div>
    </div>
  )
}
