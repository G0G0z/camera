import * as React from "react"
import { Link, useLocation } from "wouter"
import { Camera, LayoutDashboard, Users, Video, Activity, LogOut, UserCircle2, Cpu, UserCog, Wifi } from "lucide-react"
import { useGetMe, useLogout } from "@workspace/api-client-react"
import { useAuthStore } from "@/store/auth"

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/cameras", label: "Cameras", icon: Camera },
  { href: "/recordings", label: "Recordings", icon: Video },
  { href: "/events", label: "Events", icon: Activity },
  { href: "/customers", label: "Customers", icon: Users, roles: ["superadmin"] },
  { href: "/users", label: "Users", icon: UserCircle2, roles: ["superadmin", "admin"] },
  { href: "/firmware", label: "Firmware", icon: Cpu, roles: ["superadmin", "admin"] },
]



export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation()
  const { data: user } = useGetMe()
  const logoutMutation = useLogout()
  const setAuthenticated = useAuthStore((state) => state.setAuthenticated)

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        setAuthenticated(false)
        setLocation("/login")
      }
    })
  }

  const filteredNavItems = navItems.filter(item => 
    !item.roles || (user?.role && item.roles.includes(user.role))
  )

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-sidebar border-r border-sidebar-border flex-shrink-0 flex flex-col">
        <div className="p-6 border-b border-sidebar-border">
          <h2 className="text-lg font-semibold text-sidebar-foreground flex items-center gap-2">
            <Camera className="w-5 h-5 text-primary" />
            OpticSight PTZ
          </h2>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {filteredNavItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href))
            return (
              <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${isActive ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"}`}>
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="p-4 border-t border-sidebar-border text-sm flex items-center justify-between">
          <Link href="/profile" className="flex items-center gap-2 min-w-0 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-medium shrink-0">
              {user?.name?.charAt(0).toUpperCase() || user?.email?.charAt(0).toUpperCase()}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-medium text-sidebar-foreground truncate max-w-[100px]">{user?.name || 'Hesabım'}</span>
              <span className="text-xs text-muted-foreground capitalize">{user?.role}</span>
            </div>
          </Link>
          <button onClick={handleLogout} className="text-muted-foreground hover:text-destructive p-2 rounded-md hover:bg-destructive/10 transition-colors shrink-0" title="Çıkış">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  )
}
