<?php
declare(strict_types=1);

// .env dosyası varsa yükle
if (file_exists(__DIR__ . '/.env')) {
    foreach (file(__DIR__ . '/.env') as $line) {
        $line = trim($line);
        if ($line && !str_starts_with($line, '#') && str_contains($line, '=')) {
            [$k, $v] = explode('=', $line, 2);
            putenv(trim($k) . '=' . trim($v, " \t\n\r\"'"));
        }
    }
}

function env(string $key, mixed $default = null): mixed
{
    $v = getenv($key);
    return $v !== false ? $v : $default;
}

// ─── Veritabanı (JSON dosyaları) ─────────────────────────────────────────────
define('DATA_DIR', env('DATA_DIR', __DIR__ . '/data'));

// ─── Auth ─────────────────────────────────────────────────────────────────────
define('JWT_SECRET', env('JWT_SECRET', 'gizli-anahtar-production-da-degistir'));
define('JWT_TTL',    3600 * 24 * 30); // 30 gün

// ─── MediaMTX (opsiyonel — RTSP→WebRTC relay) ─────────────────────────────────
define('MEDIAMTX_API',   env('MEDIAMTX_API',   'http://localhost:9997'));
define('MEDIAMTX_HLS',   env('MEDIAMTX_HLS',   ''));
define('MEDIAMTX_WEBRTC',env('MEDIAMTX_WEBRTC', ''));

// ─── Kayıtlar ─────────────────────────────────────────────────────────────────
define('RECORDINGS_DIR', env('RECORDINGS_DIR', __DIR__ . '/recordings'));
