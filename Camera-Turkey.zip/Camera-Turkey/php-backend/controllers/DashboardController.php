<?php
declare(strict_types=1);

class DashboardController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function stats(array $user): void
    {
        $cameras    = $user['role'] === 'superadmin'
            ? $this->db->all('cameras')
            : $this->db->where('cameras', ['customer_id' => $user['customer_id']]);

        $cameraIds  = array_column($cameras, 'id');

        $recordings = $this->db->all('recordings');
        $recordings = array_filter($recordings, fn($r) => in_array((int)$r['camera_id'], $cameraIds));

        $events     = $this->db->all('camera_events');
        $events     = array_filter($events, fn($e) => in_array((int)$e['camera_id'], $cameraIds));

        $today      = date('Y-m-d');
        $todayEvents = array_filter($events, fn($e) => str_starts_with($e['timestamp'] ?? '', $today));

        // Son 10 olay
        $recentEvents = array_slice(array_reverse(array_values($events)), 0, 10);
        $ec = new EventController($this->db, $this->auth);

        Response::json([
            'totalCameras'     => count($cameras),
            'onlineCameras'    => count(array_filter($cameras, fn($c) => $c['status'] === 'online')),
            'offlineCameras'   => count(array_filter($cameras, fn($c) => $c['status'] === 'offline')),
            'activeRecordings' => count(array_filter($recordings, fn($r) => $r['status'] === 'recording')),
            'totalRecordings'  => count($recordings),
            'todayEvents'      => count($todayEvents),
            'customers'        => $user['role'] === 'superadmin'
                ? count($this->db->all('customers'))
                : 1,
            'recentEvents'     => array_map(
                fn($e) => [
                    'id'          => (int)$e['id'],
                    'cameraId'    => (int)$e['camera_id'],
                    'cameraName'  => $this->db->find('cameras', (int)$e['camera_id'])['name'] ?? null,
                    'type'        => $e['type'],
                    'confidence'  => isset($e['confidence']) ? (float)$e['confidence'] : null,
                    'snapshotUrl' => $e['snapshot_url'] ?? null,
                    'timestamp'   => $e['timestamp'],
                ],
                $recentEvents
            ),
        ]);
    }
}
