<?php
declare(strict_types=1);

class CameraController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $customerId = Response::query('customerId');

        if ($user['role'] === 'superadmin') {
            $cameras = $customerId
                ? $this->db->where('cameras', ['customer_id' => (int)$customerId])
                : $this->db->all('cameras');
        } else {
            $cameras = $this->db->where('cameras', ['customer_id' => $user['customer_id']]);
        }

        Response::json(array_map([$this, 'format'], $cameras));
    }

    public function store(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $b = Response::body();

        $camera = $this->db->insert('cameras', [
            'customer_id'        => isset($b['customerId']) ? (int)$b['customerId'] : ($user['customer_id'] ?? null),
            'name'               => $b['name'] ?? 'Kamera',
            'ip'                 => $b['ip'] ?? '',
            'onvif_port'         => (int)($b['onvifPort'] ?? 80),
            'rtsp_port'          => (int)($b['rtspPort'] ?? 554),
            'username'           => $b['username'] ?? null,
            'password_encrypted' => isset($b['password']) ? base64_encode($b['password']) : null,
            'rtsp_url'           => $b['rtspUrl'] ?? null,
            'stream_path'        => $b['streamPath'] ?? null,
            'ptz_enabled'        => (bool)($b['ptzEnabled'] ?? false),
            'recording_enabled'  => (bool)($b['recordingEnabled'] ?? false),
            'status'             => 'unknown',
            'location'           => $b['location'] ?? null,
        ]);

        Response::json($this->format($camera), 201);
    }

    public function show(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);
        Response::json($this->format($camera));
    }

    public function update(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $this->findAuthorized($user, $id);
        $b = Response::body();

        $changes = array_filter([
            'name'               => $b['name'] ?? null,
            'ip'                 => $b['ip'] ?? null,
            'onvif_port'         => isset($b['onvifPort']) ? (int)$b['onvifPort'] : null,
            'rtsp_port'          => isset($b['rtspPort']) ? (int)$b['rtspPort'] : null,
            'username'           => $b['username'] ?? null,
            'password_encrypted' => isset($b['password']) ? base64_encode($b['password']) : null,
            'rtsp_url'           => $b['rtspUrl'] ?? null,
            'stream_path'        => $b['streamPath'] ?? null,
            'ptz_enabled'        => isset($b['ptzEnabled']) ? (bool)$b['ptzEnabled'] : null,
            'recording_enabled'  => isset($b['recordingEnabled']) ? (bool)$b['recordingEnabled'] : null,
            'location'           => $b['location'] ?? null,
        ], fn($v) => $v !== null);

        $camera = $this->db->update('cameras', $id, $changes);
        Response::json($this->format($camera));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $this->findAuthorized($user, $id);
        $this->db->delete('cameras', $id);
        $this->db->deleteWhere('ptz_presets', 'camera_id', $id);
        Response::noContent();
    }

    public function status(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);

        // ONVIF ping ile durum kontrolü
        $online = $this->pingCamera($camera['ip'], $camera['onvif_port'] ?? 80);
        $status = $online ? 'online' : 'offline';

        $this->db->update('cameras', $id, ['status' => $status]);

        Response::json([
            'id'        => $id,
            'status'    => $status,
            'checkedAt' => date('c'),
        ]);
    }

    public function snapshot(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);

        // ONVIF üzerinden snapshot URL al
        $pass = $camera['password_encrypted'] ? base64_decode($camera['password_encrypted']) : '';
        $onvif = new Onvif($camera['ip'], (int)($camera['onvif_port'] ?? 80), $camera['username'] ?? 'admin', $pass);
        $profiles = $onvif->getProfiles();
        $snapshotUrl = null;

        if ($profiles && count($profiles) > 0) {
            $snapshotUrl = $onvif->getSnapshotUri($profiles[0]);
        }

        // Fallback: Doğrudan IP kamera URL'si
        if (!$snapshotUrl) {
            $snapshotUrl = "http://{$camera['ip']}/snapshot.jpg";
        }

        Response::json([
            'url'        => $snapshotUrl,
            'capturedAt' => date('c'),
        ]);
    }

    public function stream(array $user, int $id): void
    {
        $camera = $this->findAuthorized($user, $id);

        // RTSP URL oluştur
        if ($camera['rtsp_url']) {
            $rtspUrl = $camera['rtsp_url'];
        } else {
            $user_    = $camera['username'] ? urlencode($camera['username']) : '';
            $pass_    = $camera['password_encrypted'] ? ':' . urlencode(base64_decode($camera['password_encrypted'])) : '';
            $auth     = $user_ ? "{$user_}{$pass_}@" : '';
            $path     = $camera['stream_path'] ?? '/stream';
            $rtspUrl  = "rtsp://{$auth}{$camera['ip']}:{$camera['rtsp_port']}{$path}";
        }

        // MediaMTX üzerinden HLS/WebRTC URL (eğer yapılandırıldıysa)
        $streamName = "cam_{$id}";
        $hlsUrl     = MEDIAMTX_HLS    ? MEDIAMTX_HLS    . "/{$streamName}/index.m3u8" : null;
        $webrtcUrl  = MEDIAMTX_WEBRTC ? MEDIAMTX_WEBRTC . "/{$streamName}" : null;

        Response::json([
            'rtspUrl'   => $rtspUrl,
            'hlsUrl'    => $hlsUrl,
            'webrtcUrl' => $webrtcUrl,
        ]);
    }

    // ── Yardımcılar ──────────────────────────────────────────────────────────

    private function findAuthorized(array $user, int $id): array
    {
        $camera = $this->db->find('cameras', $id);
        if (!$camera) Response::abort(404, 'Kamera bulunamadı');

        if ($user['role'] !== 'superadmin' && $camera['customer_id'] != $user['customer_id']) {
            Response::abort(403, 'Erişim izni yok');
        }

        return $camera;
    }

    private function pingCamera(string $ip, int $port): bool
    {
        $conn = @fsockopen($ip, $port, $errno, $errstr, 2);
        if ($conn) { fclose($conn); return true; }
        return false;
    }

    public function format(array $c): array
    {
        return [
            'id'               => (int)$c['id'],
            'customerId'       => isset($c['customer_id']) ? (int)$c['customer_id'] : null,
            'name'             => $c['name'],
            'ip'               => $c['ip'],
            'onvifPort'        => (int)($c['onvif_port'] ?? 80),
            'rtspPort'         => (int)($c['rtsp_port'] ?? 554),
            'username'         => $c['username'] ?? null,
            'rtspUrl'          => $c['rtsp_url'] ?? null,
            'streamPath'       => $c['stream_path'] ?? null,
            'ptzEnabled'       => (bool)($c['ptz_enabled'] ?? false),
            'recordingEnabled' => (bool)($c['recording_enabled'] ?? false),
            'status'           => $c['status'] ?? 'unknown',
            'location'         => $c['location'] ?? null,
            'createdAt'        => $c['created_at'],
        ];
    }
}
