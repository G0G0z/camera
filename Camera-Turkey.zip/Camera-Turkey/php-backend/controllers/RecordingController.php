<?php
declare(strict_types=1);

class RecordingController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $cameraId = Response::query('cameraId');
        $page     = max(1, (int)Response::query('page', 1));
        $limit    = min(100, max(1, (int)Response::query('limit', 20)));

        $all = $this->db->all('recordings');

        // Yetki filtresi
        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($r) => in_array((int)$r['camera_id'], $myCameras));
        }

        if ($cameraId) {
            $all = array_filter($all, fn($r) => (int)$r['camera_id'] === (int)$cameraId);
        }

        $all   = array_values($all);
        $total = count($all);
        $items = array_slice($all, ($page - 1) * $limit, $limit);

        Response::json([
            'items' => array_map([$this, 'format'], $items),
            'total' => $total,
            'page'  => $page,
        ]);
    }

    public function start(array $user): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $b        = Response::body();
        $cameraId = (int)($b['cameraId'] ?? 0);
        if (!$cameraId) Response::abort(400, 'cameraId gerekli');

        $recording = $this->db->insert('recordings', [
            'camera_id'  => $cameraId,
            'status'     => 'recording',
            'start_time' => date('c'),
            'trigger'    => 'manual',
        ]);

        Response::json($this->format($recording), 201);
    }

    public function show(array $user, int $id): void
    {
        $recording = $this->db->find('recordings', $id);
        if (!$recording) Response::abort(404, 'Kayıt bulunamadı');
        Response::json($this->format($recording));
    }

    public function stop(array $user, int $id): void
    {
        $recording = $this->db->find('recordings', $id);
        if (!$recording) Response::abort(404, 'Kayıt bulunamadı');
        if ($recording['status'] !== 'recording') Response::abort(400, 'Kayıt aktif değil');

        $start    = new DateTime($recording['start_time']);
        $end      = new DateTime();
        $duration = $end->getTimestamp() - $start->getTimestamp();

        $updated = $this->db->update('recordings', $id, [
            'status'   => 'completed',
            'end_time' => date('c'),
            'duration' => $duration,
        ]);

        Response::json($this->format($updated));
    }

    public function destroy(array $user, int $id): void
    {
        $this->auth->requireRole($user, 'superadmin', 'admin');
        $recording = $this->db->find('recordings', $id);
        if (!$recording) Response::abort(404, 'Kayıt bulunamadı');

        // Dosyayı sil (varsa)
        if (!empty($recording['file_path']) && file_exists($recording['file_path'])) {
            @unlink($recording['file_path']);
        }

        $this->db->delete('recordings', $id);
        Response::noContent();
    }

    private function format(array $r): array
    {
        $camera = $this->db->find('cameras', (int)$r['camera_id']);
        return [
            'id'         => (int)$r['id'],
            'cameraId'   => (int)$r['camera_id'],
            'cameraName' => $camera['name'] ?? null,
            'status'     => $r['status'],
            'startTime'  => $r['start_time'],
            'endTime'    => $r['end_time'] ?? null,
            'filePath'   => $r['file_path'] ?? null,
            'fileSize'   => isset($r['file_size']) ? (int)$r['file_size'] : null,
            'duration'   => isset($r['duration']) ? (int)$r['duration'] : null,
            'trigger'    => $r['trigger'] ?? 'manual',
            'createdAt'  => $r['created_at'],
        ];
    }
}
