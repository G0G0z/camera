<?php
declare(strict_types=1);

class EventController
{
    public function __construct(private Database $db, private Auth $auth) {}

    public function index(array $user): void
    {
        $cameraId = Response::query('cameraId');
        $type     = Response::query('type');
        $page     = max(1, (int)Response::query('page', 1));
        $limit    = 20;

        $all = $this->db->all('camera_events');

        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($e) => in_array((int)$e['camera_id'], $myCameras));
        }

        if ($cameraId) $all = array_filter($all, fn($e) => (int)$e['camera_id'] === (int)$cameraId);
        if ($type)     $all = array_filter($all, fn($e) => $e['type'] === $type);

        $all = array_values(array_reverse($all)); // En yeni önce
        $items = array_slice($all, ($page - 1) * $limit, $limit);

        Response::json(array_map([$this, 'format'], $items));
    }

    public function recent(array $user): void
    {
        $all = $this->db->all('camera_events');

        if ($user['role'] !== 'superadmin') {
            $myCameras = array_column(
                $this->db->where('cameras', ['customer_id' => $user['customer_id']]),
                'id'
            );
            $all = array_filter($all, fn($e) => in_array((int)$e['camera_id'], $myCameras));
        }

        $all   = array_values(array_reverse($all));
        $items = array_slice($all, 0, 20);

        Response::json(array_map([$this, 'format'], $items));
    }

    private function format(array $e): array
    {
        $camera = $this->db->find('cameras', (int)$e['camera_id']);
        return [
            'id'          => (int)$e['id'],
            'cameraId'    => (int)$e['camera_id'],
            'cameraName'  => $camera['name'] ?? null,
            'type'        => $e['type'],
            'confidence'  => isset($e['confidence']) ? (float)$e['confidence'] : null,
            'snapshotUrl' => $e['snapshot_url'] ?? null,
            'timestamp'   => $e['timestamp'],
        ];
    }
}
