<?php
declare(strict_types=1);

// ─── Bootstrap ───────────────────────────────────────────────────────────────
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/Database.php';
require_once __DIR__ . '/lib/Response.php';
require_once __DIR__ . '/lib/Auth.php';
require_once __DIR__ . '/lib/Router.php';
require_once __DIR__ . '/lib/Onvif.php';
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/CameraController.php';
require_once __DIR__ . '/controllers/PtzController.php';
require_once __DIR__ . '/controllers/RecordingController.php';
require_once __DIR__ . '/controllers/EventController.php';
require_once __DIR__ . '/controllers/UserController.php';
require_once __DIR__ . '/controllers/CustomerController.php';
require_once __DIR__ . '/controllers/DashboardController.php';
require_once __DIR__ . '/controllers/FirmwareController.php';
require_once __DIR__ . '/controllers/RegisterController.php';
require_once __DIR__ . '/controllers/WifiController.php';

// ─── CORS ────────────────────────────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ─── Router ──────────────────────────────────────────────────────────────────
$router = new Router();
$db     = Database::getInstance();
$auth   = new Auth($db);

// Health
$router->get('/api/healthz', fn() => Response::json(['status' => 'ok']));

// Auth
$ac = new AuthController($db, $auth);
$router->post('/api/auth/login',    [$ac, 'login']);
$router->post('/api/auth/logout',   [$ac, 'logout']);
$router->get('/api/auth/me',        fn() => $ac->me($auth->requireAuth()));

// Kayıt & Profil
$rc2 = new RegisterController($db, $auth);
$router->post('/api/auth/register',        [$rc2, 'register']);
$router->post('/api/auth/profile',         fn() => $rc2->updateProfile($auth->requireAuth()));
$router->post('/api/auth/change-password', fn() => $rc2->changePassword($auth->requireAuth()));
$router->post('/api/auth/delete-account',  fn() => $rc2->deleteAccount($auth->requireAuth()));

// Cameras
$cc = new CameraController($db, $auth);
$router->get('/api/cameras',             fn() => $cc->index($auth->requireAuth()));
$router->post('/api/cameras',            fn() => $cc->store($auth->requireAuth()));
$router->get('/api/cameras/{id}',        fn($p) => $cc->show($auth->requireAuth(), (int)$p['id']));
$router->put('/api/cameras/{id}',        fn($p) => $cc->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/cameras/{id}',     fn($p) => $cc->destroy($auth->requireAuth(), (int)$p['id']));
$router->get('/api/cameras/{id}/status', fn($p) => $cc->status($auth->requireAuth(), (int)$p['id']));
$router->get('/api/cameras/{id}/snapshot', fn($p) => $cc->snapshot($auth->requireAuth(), (int)$p['id']));
$router->get('/api/cameras/{id}/stream', fn($p) => $cc->stream($auth->requireAuth(), (int)$p['id']));

// PTZ
$pc = new PtzController($db, $auth);
$router->post('/api/cameras/{id}/ptz',                              fn($p) => $pc->command($auth->requireAuth(), (int)$p['id']));
$router->get('/api/cameras/{id}/ptz/presets',                       fn($p) => $pc->presets($auth->requireAuth(), (int)$p['id']));
$router->post('/api/cameras/{id}/ptz/presets',                      fn($p) => $pc->savePreset($auth->requireAuth(), (int)$p['id']));
$router->post('/api/cameras/{id}/ptz/presets/{presetId}/goto',      fn($p) => $pc->gotoPreset($auth->requireAuth(), (int)$p['id'], (int)$p['presetId']));

// Recordings
$rc = new RecordingController($db, $auth);
$router->get('/api/recordings',          fn() => $rc->index($auth->requireAuth()));
$router->post('/api/recordings/start',   fn() => $rc->start($auth->requireAuth()));
$router->get('/api/recordings/{id}',     fn($p) => $rc->show($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/recordings/{id}',  fn($p) => $rc->destroy($auth->requireAuth(), (int)$p['id']));
$router->post('/api/recordings/{id}/stop', fn($p) => $rc->stop($auth->requireAuth(), (int)$p['id']));

// Events
$ec = new EventController($db, $auth);
$router->get('/api/events',         fn() => $ec->index($auth->requireAuth()));
$router->get('/api/events/recent',  fn() => $ec->recent($auth->requireAuth()));

// Users
$uc = new UserController($db, $auth);
$router->get('/api/users',       fn() => $uc->index($auth->requireAuth()));
$router->post('/api/users',      fn() => $uc->store($auth->requireAuth()));
$router->put('/api/users/{id}',  fn($p) => $uc->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/users/{id}', fn($p) => $uc->destroy($auth->requireAuth(), (int)$p['id']));

// Customers
$cuc = new CustomerController($db, $auth);
$router->get('/api/customers',              fn() => $cuc->index($auth->requireAuth()));
$router->post('/api/customers',             fn() => $cuc->store($auth->requireAuth()));
$router->get('/api/customers/{id}',         fn($p) => $cuc->show($auth->requireAuth(), (int)$p['id']));
$router->put('/api/customers/{id}',         fn($p) => $cuc->update($auth->requireAuth(), (int)$p['id']));
$router->delete('/api/customers/{id}',      fn($p) => $cuc->destroy($auth->requireAuth(), (int)$p['id']));
$router->get('/api/customers/{id}/cameras', fn($p) => $cuc->cameras($auth->requireAuth(), (int)$p['id']));

// Dashboard
$dc = new DashboardController($db, $auth);
$router->get('/api/dashboard/stats', fn() => $dc->stats($auth->requireAuth()));

// Firmware
$fc = new FirmwareController($db, $auth);
$router->get('/api/firmware/soc',                fn() => $fc->socList($auth->requireAuth()));
$router->post('/api/firmware/flash-commands',    fn() => $fc->flashCommands($auth->requireAuth()));
$router->post('/api/firmware/check-access',      fn() => $fc->checkAccess($auth->requireAuth()));
$router->post('/api/firmware/auto-setup',        fn() => $fc->autoSetup($auth->requireAuth()));
$router->post('/api/firmware/majestic-config',   fn() => $fc->getMajesticConfig($auth->requireAuth()));
$router->post('/api/firmware/majestic-set',      fn() => $fc->setMajesticValue($auth->requireAuth()));
$router->post('/api/firmware/version-check',     fn() => $fc->checkFirmwareVersion($auth->requireAuth()));
$router->post('/api/firmware/update',            fn() => $fc->updateFirmware($auth->requireAuth()));

// WiFi Profilleri
$wc = new WifiController($db, $auth);
$router->get('/api/wifi',               fn() => $wc->index($auth->requireAuth()));
$router->post('/api/wifi',              fn() => $wc->store($auth->requireAuth()));
$router->delete('/api/wifi/{id}',       fn($p) => $wc->destroy($auth->requireAuth(), (int)$p['id']));
$router->post('/api/wifi/qr-string',    fn() => $wc->qrString($auth->requireAuth()));

// ─── Dispatch ────────────────────────────────────────────────────────────────
$router->dispatch($_SERVER['REQUEST_METHOD'], $_SERVER['REQUEST_URI']);
