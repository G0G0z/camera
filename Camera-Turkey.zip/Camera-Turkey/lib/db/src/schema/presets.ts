import { pgTable, serial, integer, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { camerasTable } from "./cameras";

export const ptzPresetsTable = pgTable("ptz_presets", {
  id: serial("id").primaryKey(),
  cameraId: integer("camera_id").notNull().references(() => camerasTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  token: text("token").notNull(),
});

export const insertPtzPresetSchema = createInsertSchema(ptzPresetsTable).omit({ id: true });
export type InsertPtzPreset = z.infer<typeof insertPtzPresetSchema>;
export type PtzPreset = typeof ptzPresetsTable.$inferSelect;
