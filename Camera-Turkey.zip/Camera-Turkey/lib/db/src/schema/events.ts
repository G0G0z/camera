import { pgTable, serial, integer, text, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { camerasTable } from "./cameras";

export const cameraEventsTable = pgTable("camera_events", {
  id: serial("id").primaryKey(),
  cameraId: integer("camera_id").notNull().references(() => camerasTable.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  confidence: real("confidence"),
  snapshotUrl: text("snapshot_url"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertCameraEventSchema = createInsertSchema(cameraEventsTable).omit({ id: true });
export type InsertCameraEvent = z.infer<typeof insertCameraEventSchema>;
export type CameraEvent = typeof cameraEventsTable.$inferSelect;
