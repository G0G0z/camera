import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { customersTable } from "./customers";

export const camerasTable = pgTable("cameras", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  ip: text("ip").notNull(),
  onvifPort: integer("onvif_port").notNull().default(80),
  rtspPort: integer("rtsp_port").notNull().default(554),
  username: text("username"),
  passwordEncrypted: text("password_encrypted"),
  rtspUrl: text("rtsp_url"),
  streamPath: text("stream_path"),
  ptzEnabled: boolean("ptz_enabled").notNull().default(false),
  recordingEnabled: boolean("recording_enabled").notNull().default(false),
  status: text("status").notNull().default("unknown"),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCameraSchema = createInsertSchema(camerasTable).omit({ id: true, createdAt: true });
export type InsertCamera = z.infer<typeof insertCameraSchema>;
export type Camera = typeof camerasTable.$inferSelect;
