import { pgTable, serial, integer, text, timestamp, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { camerasTable } from "./cameras";

export const recordingsTable = pgTable("recordings", {
  id: serial("id").primaryKey(),
  cameraId: integer("camera_id").notNull().references(() => camerasTable.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("recording"),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  filePath: text("file_path"),
  fileSize: bigint("file_size", { mode: "number" }),
  duration: integer("duration"),
  trigger: text("trigger").notNull().default("manual"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertRecordingSchema = createInsertSchema(recordingsTable).omit({ id: true, createdAt: true });
export type InsertRecording = z.infer<typeof insertRecordingSchema>;
export type Recording = typeof recordingsTable.$inferSelect;
